# Phase 17 Wilderness Gate Fix (v5)

Home Wilderness now unlocks whenever the Village Elder dialogue finishes.

Intended opening flow:

1. Childhood Spirit opening dialogue.
2. Speak with the Village Elder.
3. `world.home_wilderness_open` becomes `true`.
4. Use the east exit from Home Village to enter Home Wilderness.

This also makes older saves and the legacy `First Steps` test quest compatible with the Phase 17 story gate.
