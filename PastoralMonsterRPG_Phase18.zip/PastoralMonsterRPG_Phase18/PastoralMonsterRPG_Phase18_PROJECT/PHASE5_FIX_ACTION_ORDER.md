# Phase 5 Runtime Fix — Typed Battle Action Order

Fixed `BattleSession._resolve_action_order()` so every return path returns a true `Array[String]` instead of an untyped Array literal.

This resolves the Godot runtime error:

`Trying to return an array of type "Array" where expected return type is "Array[String]".`

The function now builds one typed `Array[String]` and appends `"player"` / `"enemy"` in the correct priority, speed, or tie-break order.
