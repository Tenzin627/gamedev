# Phase 9 Fixes

- Renamed `placeholder_crop_visual.gd` member `ready` to `is_harvest_ready` to avoid collision with native `Node2D.ready`.
- Hardened Farm HUD node references with `get_node_or_null()` and null guards before assigning `.text`.
