# Pastoral Monster RPG — Phase 0 Foundation

This is the complete Phase 0 Godot foundation package based on the project's GDD v3 / TDD v2 production direction.

## Open

1. Install Godot 4.x.
2. Import this folder by selecting `project.godot`.
3. Run the project.

The project boots into `Main.tscn`, creates default input actions and audio buses, registers the global managers, and loads `tests/scenes/system_test.tscn` into `WorldRoot`.

## Debug Keys

- `F3` — toggle debug overlay
- `F4` — toggle debug logging
- `F5` — reload active world scene
- `F6` — toggle 4x development speed

## Default Gameplay Input

- WASD / Arrow Keys — movement actions
- E / Space — interact
- Enter / Space — confirm
- Escape — cancel / pause
- Tab — menu
- J — journal
- M — map
- P — party
- I — inventory

Controller defaults are also added at runtime.

## Base Resolution

The project currently uses a 1920×1080 design viewport and a 1280×720 initial window. Change these in Project Settings later if the final TDD resolution differs.

## Phase 0 Scope

Included:

- modular folders
- application root
- runtime input bootstrap
- scene manager
- event bus
- game state shell
- save/load shell
- audio manager / buses
- debug manager / overlay
- transitions
- stable content IDs
- runtime ID utility
- base Resource schemas
- data validation
- development test scene
- sample test Resources

Not included yet:

- player controller
- exploration gameplay
- battle gameplay
- farming gameplay
- monster runtime systems
- quests/content implementation
- final art/audio

Those begin in later production phases.
