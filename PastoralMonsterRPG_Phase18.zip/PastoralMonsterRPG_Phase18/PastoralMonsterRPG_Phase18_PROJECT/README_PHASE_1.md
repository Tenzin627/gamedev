# Pastoral Monster RPG — Phase 1 Player Prototype

This project extends the Phase 0 foundation and implements the complete Phase 1 player prototype.

## Included
- CharacterBody2D player scene
- 8-direction movement
- Acceleration/deceleration
- World collision
- Smooth Camera2D follow
- Reusable InteractionComponent
- Nearest-interactable selection
- Interaction prompts
- NPC interaction test
- Object/chest interaction test
- Functional open/close door test
- Keyboard and controller input
- Placeholder animated movement visual
- Drop-in AnimatedSprite2D integration for final art
- Phase 1 test world

## Controls
- Move: WASD / Arrow Keys / Left Stick / D-pad
- Interact: E / Space / controller A/Cross
- F3: Debug overlay
- F4: Toggle logs
- F5: Reload world
- F6: 4x dev speed

## Adding Your Final Player Art
Open:
`res://scenes/characters/player/player.tscn`

1. Select Player and set `use_custom_animated_sprite = true`.
2. Select `Visual/AnimatedSprite2D`.
3. Create/assign SpriteFrames using your sprite sheets.
4. Use the animation names documented in `assets/sprites/player/README.md`.
5. Adjust `CollisionShape2D`, Camera2D offset, and sprite scale/position for your art.

Your movement, interaction, camera, and collision code does not need to change.

## Phase 1 Definition of Done
Run the project and confirm:
1. Player moves in 8 directions.
2. Player smoothly stops/starts.
3. Player collides with walls, NPC, chest, and rock.
4. Camera follows player.
5. Interaction prompt appears near NPC/chest/door.
6. NPC responds.
7. Chest responds.
8. Door opens, removes its blocker, closes, and restores its blocker.
9. Keyboard and controller mappings work.
10. Placeholder visual can be replaced without changing PlayerController.
