# Phase 10 — Time & Weather

Built on Phase 9 FIXED v2.

## Goal

Create one authoritative world clock used by farming, encounters, weather, seasons, schedules, visuals, and saves.

## Core system

Autoload:

`TimeWeatherManager` → `res://scripts/time/time_weather_manager.gd`

State is stored in `GameState.game_time`:

- `day`
- `minute_of_day`
- `season`
- `season_day`
- `weather`

The default development clock starts at Spring 1, Day 1, 08:00, Clear.

### Development time scale

By default, 1 real second advances 2 game minutes (`real_seconds_per_game_minute = 0.5`).

This is intentionally accelerated for prototype testing. Change the exported value later for production pacing.

## Day periods

- Dawn: 05:00–06:59
- Day: 07:00–17:59
- Dusk: 18:00–19:59
- Night: 20:00–04:59

Encounter day/night uses a broader gameplay tag:

- Day encounters: 06:00–19:59
- Night encounters: 20:00–05:59

## Seasons

Each season lasts 28 days:

Spring → Summer → Autumn → Winter → Spring

Crop planting reads each CropData `season_ids`. Existing planted crops are allowed to finish after a season changes; they never die from season rollover.

## Weather

Prototype weather:

- Clear
- Cloudy
- Rain
- Fog

Weather rolls at the start of each new day using season-specific weights.

Rain automatically waters all planted, unfinished crops.

## Farming integration

Phase 9 no longer uses the operating-system/Unix clock for crop growth.

`FarmManager` listens to `EventBus.game_minutes_advanced` and reduces each watered crop's `remaining_minutes`.

Processing jobs also use game minutes.

This means pausing/advancing the game clock affects all time-based farm systems consistently.

## Encounter integration

New dynamic table:

`data/encounters/home_wilderness.tres`

Home Wilderness now uses time/weather context from `TimeWeatherManager`.

Day and night have different weights, and rain adds an additional Brambleaf weighting.

Existing visible monsters are not deleted when weather/time changes. New respawns use the current conditions.

## NPC schedule hook

The Home Village shop now uses opening hours:

08:00–20:00

The Shopkeeper script demonstrates how future NPC schedules can subscribe to `hour_changed` and query `TimeWeatherManager`.

## World visuals

`WorldEnvironmentController` uses a root `CanvasModulate` to apply placeholder tinting for dawn/day/dusk/night and weather.

The UI is on a CanvasLayer, so the world tint does not need to recolor menus/HUD.

## HUD

A global Time & Weather HUD displays:

- Season/day
- Clock
- Weather
- Day period
- Time scale

## Debug controls

- `Ctrl + T` — advance 1 game hour
- `Ctrl + Shift + T` — advance to the next day
- `Ctrl + Alt + T` — advance to the next season
- `Ctrl + Y` — cycle weather
- `F6` — existing engine-wide 4× debug speed

Existing controls remain:

- `F3` debug overlay
- `F7` database viewer
- `Ctrl + M` monster viewer
- `Ctrl + B` debug battle
- `I` inventory

## Save integration

`SAVE_VERSION` is now 2 and `DATA_VERSION` is now 2.

The time/weather state is serialized through `GameState.to_save_dict()`.

Loading a save re-emits time, period, season, and weather signals so dependent systems refresh automatically.

## Phase 10 definition of done

- One authoritative game clock.
- Day rollover works.
- Seasons roll every 28 days.
- Weather rolls daily.
- Clock/weather are saved.
- Crops grow from game minutes.
- Rain waters crops.
- Crop planting checks seasons.
- Processing uses game minutes.
- Encounters read time/weather.
- NPC schedule hook is demonstrated.
- World tint responds to time/weather.
- HUD displays the current world state.
