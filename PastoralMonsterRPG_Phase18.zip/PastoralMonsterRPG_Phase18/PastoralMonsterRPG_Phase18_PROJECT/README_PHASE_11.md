# Phase 11 — Feeding & Development

This project extends Phase 10 with the playable food → monster development loop.

## Test

1. Run the game.
2. The development demo roster is created automatically if the party is empty.
3. Farm/harvest Sunberry or Dewleaf, or cook Root Stew. For fast testing, use existing inventory/farm tools.
4. Press **Ctrl+D** to open Feeding & Development.
5. Select a monster and food, then Feed.
6. Watch tendencies increase and development-gated moves unlock.
7. Equip an unlocked move from the same screen.

## Rules

- Food data owns development values.
- Favorite tags: 1.25× development/recovery.
- Disliked tags: 0.75× development/recovery (never negative progress).
- Individual monsters store development permanently in `MonsterInstance.development`.
- Food history is stored in `favorite_food_memory`.
- Species data owns visible move-unlock thresholds.
- Factory-created monsters begin with non-gated species moves; development-gated moves start locked.
- Saves already serialize development, unlocked moves, equipped moves, and food memory.

## Sample foods

- Root Stew: Resilient +3, Gentle +1, Steady +2.
- Sunberry: Gentle +3, Swift +1.
- Dewleaf: Resilient +3, Focused +1.

## Spriggle sample unlocks

- Soothing Pollen: Gentle 8.
- Root Guard: Resilient 8.

These values are MVP tuning and are isolated in `.tres` data.
