# Phase 12 — Evolution System

Phase 12 connects monster level and Development Tendencies to data-driven evolution.

## Test

Press **Ctrl+E** to open the Evolution screen.

Spriggle sample rules:
- Brambleaf: Level 10+, Resilient 20+
- Bloomtail: Level 10+, Gentle 20+

If only one path qualifies, it resolves automatically. If multiple qualifying tendencies are within 2 points, the player chooses. Otherwise the strongest qualifying tendency wins.

Evolution preserves the monster's unique instance ID, nickname, level, EXP, Trait, development, food memory, capture history, known/equipped moves, and records an evolution-history entry. HP is rescaled proportionally to the evolved species' maximum HP.

The evolved species is added to Journal seen/owned state. The placeholder evolution presentation can be skipped with Confirm, Interact, or Esc.
