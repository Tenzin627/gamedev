# Phase 13 — NPC & Dialogue System

## Goal
Provide reusable NPC actors and a data-driven dialogue engine for story, quests, relationships, Profile Tags, and world-state reactions.

## Test
1. Run the project.
2. In Home Village, approach one of the three placeholder NPCs.
3. Press **E / Space / controller interact**.
4. Use dialogue choices with mouse/controller/keyboard focus.
5. Press **Esc / B** to close dialogue.

## Sample NPCs
- Village Elder — demonstrates conditional greetings, Profile Tag choices, and relationship thresholds.
- Mira — Friendly Rival; choices grant Farmer/Tamer/Explorer Profile Tags and relationship points.
- Toma — Farmer mentor; dialogue reacts to weather and inventory, and is unavailable at night.

## Data
Dialogue lives under `res://data/dialogues/` as `DialogueData` Resources. NPC definitions reference dialogue IDs rather than scene paths.

## Supported Conditions
- Profile Tag / missing Profile Tag
- World state equality
- Relationship minimum / maximum
- Quest state equality
- Time period
- Weather
- Season
- Minimum item count

## Supported Actions
- Add relationship
- Add/remove Profile Tag
- Set world state
- Emit an interaction message

## Architecture
`NPCActor -> DialogueManager -> DialogueData -> DialogueScreen`

The player is frozen while `Game.mode == DIALOGUE`, but the world does not need to be paused globally.
