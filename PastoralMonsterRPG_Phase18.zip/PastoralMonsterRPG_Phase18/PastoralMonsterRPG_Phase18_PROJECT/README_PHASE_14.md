# Phase 14 — Quest System

Phase 14 adds the reusable quest runtime used by story and side content.

## Features
- States: Available → Active/Updated → Resolved / Failed / Alternate Outcome
- Prerequisites and Profile Tag/world-state requirements
- Event-driven objectives
- Branching reward outcomes
- Quest Journal and HUD tracker
- Save-safe quest progress in GameState.quest_state
- Dialogue hooks for start/complete quest actions

## Open Journal
Use the existing Journal input action (default J if mapped by the project input bootstrap).

## Sample Quests
- First Steps — auto-starts in development build
- A Farmer's Help — unlocks after First Steps
- Wild Observation — unlocks after First Steps

## Supported objective types
- dialogue
- item_collect
- gather
- capture
- battle_win
- harvest
- map_enter
- waystone
- profile_tag
- world_state

All quest content is authored as QuestData `.tres` resources under `res://data/quests/`.
