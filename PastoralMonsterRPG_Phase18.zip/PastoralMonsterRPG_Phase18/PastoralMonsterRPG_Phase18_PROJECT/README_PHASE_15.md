# Phase 15 — Profile Tags System

Phase 15 formalizes the player's cumulative identity tags. Tags are achievements/profile markers, not classes: a player may earn Farmer, Tamer, Explorer, Helper, and future tags together.

## Test

- Press **Ctrl+P** to open the Player Profile.
- Harvest 3 crops to earn **Farmer** automatically.
- Capture 1 wild monster to earn **Tamer** automatically.
- Discover 3 distinct maps to earn **Explorer** automatically.
- Dialogue/quest actions can award tags immediately as before.

## Architecture

- `ProfileTagData` — authored display/metadata and optional milestone rule.
- `ProfileTagManager` — single authority for award/removal/check/progress/history.
- `GameState.player_profile["profile_tags"]` — save-safe earned tag keys.
- `GameState.player_profile["profile_tag_progress"]` — milestone counters.
- `GameState.player_profile["profile_tag_history"]` — award history.
- `ProfileScreen` — earned/unearned tags, progress, and award history.

DialogueManager remains backwards compatible: `has_profile_tag`, `add_profile_tag`, and `remove_profile_tag` delegate to ProfileTagManager.
