# Phase 16 — World-State System

Phase 16 centralizes persistent world changes behind `WorldStateManager`.

## What is included

- Data-driven `WorldStateData` defaults.
- Persistent state values stored in `GameState.world_state`.
- State change history stored in the player profile.
- Atomic `set_value()` / `set_many()` APIs.
- Conditional world objects that appear/disappear from state.
- Dialogue and Quest rewards routed through WorldStateManager.
- Quest prerequisites continue to read world state.
- Encounter conditions can now include a `world_state` dictionary.
- Home Village restoration demonstration.
- Debug World State Viewer.

## Test

1. Run the project.
2. In Home Village, walk to the gold restoration marker at the east/southeast side.
3. Interact once.
4. The abandoned patch permanently changes to either a garden or wildlife refuge.
   - A Tamer without the Farmer tag chooses the refuge test outcome.
   - Otherwise the garden test outcome is used.
5. Press `Ctrl+G` to inspect or debug-toggle persistent Boolean world states.
6. Save/load later uses the same `GameState.world_state` dictionary.

## Production rule

Do not directly write `GameState.world_state` from gameplay systems. Use:

```gdscript
WorldStateManager.set_value("world.some_state", true, "source")
```

or:

```gdscript
WorldStateManager.set_many({
    "world.bridge_repaired": true,
    "world.bridge_damaged": false
}, "quest_reward")
```

This ensures signals and state history stay consistent.

## Conditional world object

Attach `conditional_world_object.gd` to a `Node2D`, then configure:

- `state_id`
- `expected_value`
- `invert`

The node will automatically update when the state changes.

## Encounter condition example

```gdscript
"conditions": {
    "world_state": {
        "world.home_wildlife_refuge": true
    }
}
```

This allows permanent player choices to change local monster ecology.
