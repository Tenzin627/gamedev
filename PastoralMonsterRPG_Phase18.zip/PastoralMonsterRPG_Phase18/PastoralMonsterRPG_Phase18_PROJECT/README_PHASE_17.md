# Phase 17 — Story Integration

This build integrates the existing MVP systems into a playable opening chapter.

## Main Story Flow

1. The game opens in Home Village and the Childhood Spirit speaks automatically.
2. Speak with the Village Elder to open the eastern path.
3. Enter Home Wilderness and capture a wild Spriggle with Gya.
4. The Home Farm unlocks. Visit it and harvest Meadow Root.
5. Speak with Mira about strange monster tracks.
6. Return to Home Wilderness and investigate the Humming Spring.
7. Choose one permanent outcome:
   - Restore the old spring channel.
   - Protect the wild refuge.
8. The wilderness changes visually and the Golden Forest trail opens.
9. Follow the trail to `map.golden_forest_edge`.
10. The Childhood Spirit delivers the end-of-slice Golden Forest hook.

## Main Story Quests

- `quest.story.opening` — A Quiet Bell
- `quest.story.first_capture` — A Gentle First Bond
- `quest.story.farm_intro` — Roots at Home
- `quest.story.wilderness_mystery` — The Humming Spring
- `quest.story.golden_forest_hook` — Toward Golden Forest

These quests use `auto_start = true`; `QuestManager` now automatically starts authored auto-start quests when their prerequisites become valid.

## Story NPCs

- `npc.childhood_spirit`
- Village Elder (existing NPC, now has an opening-story branch)
- Mira / Friendly Rival (existing NPC, now participates in the mystery)

The Childhood Spirit remains visible in Home Village as a placeholder NPC. Replace its visual with the final Spirit sprite later.

## Story World States

Phase 17 adds persistent states under `world.story.*`, including:

- `world.story.opening_seen`
- `world.story.gya_received`
- `world.story.first_capture_done`
- `world.story.farm_introduced`
- `world.story.mystery_found`
- `world.story.wilderness_choice`
- `world.story.spring_restored`
- `world.story.refuge_protected`
- `world.story.golden_forest_gate_open`
- `world.story.golden_forest_hook_seen`
- `world.story.chapter1_complete`

Use **Ctrl+G** to inspect these in the World State Viewer.

## Wilderness Choice

The Humming Spring supports two actual player choices rather than an automatic outcome.

### Restore

Sets:

- `world.story.wilderness_choice = "restore"`
- `world.story.spring_restored = true`
- `world.story.refuge_protected = false`

The wilderness displays a restored water channel and the quest gives a currency bonus.

### Protect

Sets:

- `world.story.wilderness_choice = "protect"`
- `world.story.spring_restored = false`
- `world.story.refuge_protected = true`

The wilderness displays a protected thicket/refuge and the quest awards the Helper Profile Tag.

Both choices open the Golden Forest trail and can be referenced by future NPCs, encounters, quests, and postgame logic.

## New Reusable Components

### StoryManager

`res://scripts/story/story_manager.gd`

Handles only chapter-level orchestration such as automatic opening/hook dialogue. Gameplay progression remains in QuestManager and WorldStateManager.

### StoryDialogueTrigger

`res://scripts/story/story_dialogue_trigger.gd`

Reusable interactable for shrines, clues, Spirits, monuments, story props, and other non-NPC dialogue sources. It can be gated by an active quest or world state.

### MapTransition world-state gating

`MapTransition` now supports:

- `required_world_state_id`
- `required_world_state_value`
- `blocked_message`

This is used for the eastern wilderness path, farm lesson gate, and Golden Forest trail.

## Dialogue Actions Added

Phase 17 adds generic dialogue actions:

- `add_item`
- `add_currency`

These join the existing relationship, Profile Tag, quest, and world-state actions.

## New Map

`res://scenes/world/maps/golden_forest_edge.tscn`

This is intentionally a small placeholder endpoint, not the full Golden Forest region. It proves chapter transition and gives Phase 18+ a clean continuation point.

## Debug / Existing Controls

- `J` — Quest Journal
- `Ctrl+G` — World State Viewer
- `Ctrl+P` — Profile screen
- `Ctrl+M` — Monster viewer
- `Ctrl+B` — Debug battle
- `Ctrl+D` — Feeding / Development
- `Ctrl+E` — Evolution
- `I` — Inventory

## Art Replacement

All story visuals are placeholders. The story code does not depend on final sprites. You can replace:

- Childhood Spirit visual
- Humming Spring art
- restored spring / refuge art
- Golden Forest edge environment

without changing the quest, dialogue, or world-state logic.
