# Phase 18 — Content Pass

This project implements the user-provided **Sample Content Database — Vertical Slice v0.1** as the primary Phase 18 content set.

## Added / updated
- 3 base monsters: Spriggle, Pebblit, Brookit.
- 6 evolution forms: Bloomtail, Bramblekin, Flintusk, Mossback, Torrentail, Mistfin.
- 12 core moves.
- 6 species Traits.
- 5 crops and raw-food definitions.
- 4 cooked foods and recipes.
- Gya + Herbal Wrap + Field Satchel + Old Bell Fragment + Waystone Shard.
- Existing story NPC identities updated to Elder Sela, Rowan, and Taro; added Nemi and Ilya.
- TrainerData schema and 3 trainer definitions.
- Home Village Fields and Village Stream encounter tables.
- 5 new history-based Profile Tags: Fieldhand, Gentle Tamer, Battle Tested, Forager, Careful Observer.

## Development / evolution tuning
Active Phase 18 Development Tendencies are **Vigor, Resilience, Insight**. Base-species evolution is Level 16+, requires at least 20 points in the winning tendency, and exact ties wait until broken.

## Compatibility note
The older Farmer/Tamer/Explorer/Helper Profile Tags remain registered because Phase 13–17 story/dialogue/quest content references those keys. The five Phase 18 tags are additive and are the preferred vertical-slice identity content going forward.

## Asset note
All player/monster/NPC/environment art remains placeholder. Replace visuals under `assets/` and scene Visual nodes without changing the data IDs.
