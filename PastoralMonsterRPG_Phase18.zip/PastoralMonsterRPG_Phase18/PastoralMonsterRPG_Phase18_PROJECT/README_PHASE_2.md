# Pastoral Monster RPG — Phase 2: TileMapLayer World Prototype

This package extends the Phase 1 player prototype into the first reusable overworld/map architecture.

## Godot version

Use **Godot 4.3 or newer**. Phase 2 intentionally uses the `TileMapLayer` node introduced for modern Godot 4 TileMap workflows.

## What Phase 2 adds

- Home Village map scene.
- Home Wilderness map scene.
- Five-layer `TileMapLayer` map architecture.
- Runtime placeholder TileSet and placeholder atlas.
- TileMap physics collision demonstration.
- Named player spawn points.
- Map-to-map transitions with fade.
- Persistent current-map/spawn state.
- Map discovery state.
- Gathering-node placeholder.
- Waystone discovery placeholder.
- Encounter-zone placeholder.
- Reusable blank map template.
- Phase 1 player movement/interaction remains intact.

## Run the project

Open `project.godot` and press **F6/F5/Run Project** normally in Godot.

The project starts in:

`Home Village -> walk east -> Home Wilderness -> walk west -> Home Village`

## Map scene structure

Every gameplay map follows this structure:

```text
MapRoot (MapBase)
├── TileLayers
│   ├── Ground            TileMapLayer
│   ├── GroundDetail      TileMapLayer
│   ├── ObjectsBelow      TileMapLayer
│   ├── Collision         TileMapLayer
│   └── ObjectsAbove      TileMapLayer
├── Entities
│   ├── PlayerContainer
│   ├── NPCs
│   └── WildMonsters
├── Interactables
├── WorldObjects
├── EncounterZones
├── SpawnPoints
└── Transitions
```

### Ground
Main walkable floor: grass, soil, roads, water-edge base tiles, etc.

### GroundDetail
Non-blocking visual variation: flowers, leaves, pebbles, grass marks, dirt variation.

### ObjectsBelow
Visual portions that should render below the player.

### Collision
Tiles whose TileSet physics polygons block movement. Keep gameplay collision isolated here when practical.

### ObjectsAbove
Tree canopies, roofs, arches and other foreground pieces that should cover the player.

This split is intentional. Do not make one giant TileMapLayer for the entire map.

## Placeholder TileSet

The Phase 2 demo uses:

`assets/tilesets/placeholder/phase2_placeholder_tiles.png`

and creates a temporary TileSet at runtime through:

`scripts/world/placeholder_tilemap_builder.gd`

The placeholder tiles are 64x64 and exist only so Phase 2 works before final environment art is available.

## Replacing the placeholder with your own tileset

When your Art Bible tiles are ready:

1. Import your tileset texture(s) into `assets/tilesets/`.
2. Create a normal Godot `TileSet` resource in the editor.
3. Configure atlas tiles, terrains and physics polygons.
4. Assign the TileSet to each appropriate `TileMapLayer`.
5. Paint the map in the Godot TileMap editor.
6. Remove the `PlaceholderTilemapBuilder` child from the map scene.
7. Keep the layer names and map root architecture unchanged.

The player, transition, spawn, Waystone and encounter systems do not depend on the placeholder art.

## Tile size

The development placeholder uses **64x64 px cells**.

You can replace this with the final Environment/Tileset Guide dimensions later. If the final art uses a different logical grid, update the actual TileSet and map painting; gameplay code does not assume a 64-pixel tile size.

## Spawn system

Each `Marker2D` under `SpawnPoints` has metadata:

```text
spawn_id = "default"
spawn_id = "from_wilderness"
spawn_id = "from_village"
```

A map transition supplies the destination scene and destination spawn ID.

Example:

```text
Home Village ToWilderness
    target_scene    = home_wilderness.tscn
    target_spawn_id = from_village
```

`SceneManager` carries that ID into the newly loaded map. `MapBase` creates the player at the matching `Marker2D`.

Use the same approach later for:

- Building doors.
- Cave entrances.
- Region borders.
- Dungeon floors.
- Fast travel.
- Waystones.

## Creating a new map

Duplicate:

`scenes/world/maps/map_template.tscn`

Then:

1. Rename the root.
2. Give it a unique `map_id`.
3. Set `display_name`.
4. Create/assign a TileSet.
5. Paint the TileMapLayers.
6. Place spawn markers.
7. Add transitions.
8. Add interactables/encounter zones as needed.

Do not place the player manually. `MapBase` spawns it.

## Included reusable scenes

```text
scenes/world/components/
├── encounter_zone.tscn
├── gathering_node.tscn
├── map_transition.tscn
└── waystone.tscn
```

## Included map scripts

```text
scripts/world/
├── map_base.gd
├── map_transition.gd
└── placeholder_tilemap_builder.gd
```

## Gathering node

The current gathering node proves interaction and emits:

`EventBus.resource_gathered(resource_id, amount)`

Inventory is still a later production phase, so it currently displays feedback rather than permanently adding items.

## Waystone

Interacting with the Waystone stores:

`GameState.discovered_waystones[waystone_id] = true`

Fast travel is intentionally not implemented yet.

## Encounter zone

The wilderness contains an `EncounterZone` that emits enter/exit events with an encounter-table ID. Wild monster spawning and encounter tables will be implemented in their later production phases.

## Map persistence foundation

Phase 2 adds these values to `GameState`:

```text
current_map_id
current_spawn_id
discovered_waystones
map_discovery
```

They are already included in the save-state dictionary.

## Phase 2 definition of done

Phase 2 is complete when you can:

1. Run the project.
2. Move around Home Village.
3. Collide with TileMap collision boundaries and test world objects.
4. Interact with gathering nodes.
5. Discover the Waystone.
6. Walk east into the map transition.
7. Spawn correctly in Home Wilderness.
8. Walk through the encounter-zone placeholder.
9. Gather wilderness resources.
10. Walk west and return to the correct Home Village spawn point.

## Your art

You can replace only the visual TileSet and player SpriteFrames. The Phase 2 map and gameplay architecture can remain unchanged.
