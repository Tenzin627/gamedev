# Pastoral Monster RPG — Phase 3: Data Architecture

Built on Phase 2. This phase separates authored game content from gameplay logic.

## What is new

- `DataRegistry` autoload recursively loads all `.tres` / `.res` definitions from `res://data/`.
- Stable content IDs and category prefixes.
- Duplicate-ID detection.
- Cross-reference validation for monsters, moves, traits, evolutions, crops, recipes, encounters, and quest prerequisites.
- Typed lookup helpers (`get_monster`, `get_move`, `get_item`, etc.).
- Debug database viewer: **F7**.
- Reload + Validate button for rapid content iteration.
- Expanded Resource schemas ready for later gameplay phases.
- A small coherent sample database centered on Spriggle and Home Village.

## Data folders

```text
res://data/
├── monsters/
├── moves/
├── traits/
├── items/
├── food/
├── crops/
├── recipes/
├── npcs/
├── encounters/
├── quests/
└── world/
```

## ID rules

Use stable IDs, never display names:

- `monster.spriggle`
- `move.leaf_nudge`
- `trait.gentle_growth`
- `item.gya_basic`
- `food.root_stew`
- `crop.meadow_root`
- `recipe.root_stew`
- `npc.village_elder`
- `encounter.home_wilderness_day`
- `quest.home_first_steps`
- `world.home_wilderness_open`

Display names can change without breaking code or saves.

## How systems consume data

```gdscript
var species := DataRegistry.get_monster("monster.spriggle")
var move := DataRegistry.get_move("move.leaf_nudge")
var gya := DataRegistry.get_item("item.gya_basic")
```

Use `require_definition(id)` during development when missing data should be treated as a hard error.

## Database viewer

Press **F7** while running the game.

The viewer shows:

- category counts,
- every registered ID,
- display names,
- source paths,
- tags,
- validation errors/warnings.

Use **Reload + Validate** after editing `.tres` files during development.

## Definition data vs runtime data

These Resources are immutable definitions describing what a species/item/quest *is*.

Do not store individual monster HP, player inventory counts, active quest progress, etc. inside these Resources. Those belong to runtime/save-state classes introduced in their respective phases.

## Phase 3 sample content

The sample data includes:

- Spriggle
- Brambleaf
- Bloomtail
- 4 moves
- 2 traits
- Gya
- Meadow Root + seed
- Root Stew
- Meadow Root crop definition
- Root Stew recipe
- Village Elder
- Home Wilderness encounter table
- First Steps quest
- Home Wilderness world-state definition

This content exists to test architecture and can later be replaced/expanded by the real databases.
