# Phase 4 — Monster System

Built on Phase 3 Data Architecture.

## What is implemented

- `MonsterInstance` runtime Resource separate from immutable `MonsterSpeciesData`.
- Unique runtime monster IDs.
- Deterministic level-based stat growth.
- HP / damage / healing / fainted state.
- EXP and level-up processing (max level 100).
- One Trait assigned from the species' allowed Trait list.
- Up to four equipped moves plus an unlocked-move list.
- Party management (Phase 4 default max party size: 4).
- Farm/storage collection for monsters outside the active party.
- Move between party and farm.
- Party slot swapping API.
- JSON-save-safe serialization through `GameState`.
- Full-roster healing foundation.
- Placeholder monster visual scene.
- Ctrl+M Monster Viewer / test panel.
- Phase 4 gameplay events on `EventBus`.

## Runtime vs definition data

`MonsterSpeciesData` describes a species and is never mutated for an individual monster.

`MonsterInstance` stores one individual monster:

- `instance_id`
- `species_id`
- nickname
- level
- current EXP
- current HP
- assigned Trait
- equipped moves
- unlocked moves
- development values
- capture metadata
- food-reaction memory

This makes multiple monsters of the same species independent and safe to serialize.

## Main files

```text
scripts/monsters/
├── monster_instance.gd
├── monster_factory.gd
├── monster_manager.gd
└── monster_placeholder_visual.gd

scenes/monsters/
└── monster_placeholder.tscn

scenes/ui/monster/
└── monster_viewer.tscn

scripts/ui/
└── monster_viewer.gd
```

`MonsterManager` is an Autoload registered after `DataRegistry`.

## Party rules

Phase 4 uses:

```gdscript
MonsterManager.MAX_PARTY_SIZE == 4
```

This is one constant and can be changed later without restructuring the collection system.

Adding a monster with destination `"auto"` sends it to the party if a slot is open, otherwise to farm storage. This is already suitable for Phase 6 capture overflow handling.

## Creating monsters

```gdscript
var spriggle := MonsterManager.create_monster("monster.spriggle", 5)
```

Specific Trait:

```gdscript
var spriggle := MonsterManager.create_monster(
    "monster.spriggle",
    5,
    "trait.gentle_growth"
)
```

Direct factory use is also available:

```gdscript
var monster := MonsterFactory.create("monster.spriggle", 5)
```

## Stat growth

Phase 4 uses a deliberately transparent placeholder balance formula:

```text
normal stat = base + floor(base × 0.05 × (level - 1))
HP          = base + floor(base × 0.05 × (level - 1)) + (level - 1)
```

The architecture is final; the numerical growth formula can be rebalanced later from one function:

`MonsterInstance.calculate_stat()`

## Experience

EXP is stored as progress inside the current level.

Required EXP:

```text
40 + (level² × 10)
```

`add_experience()` handles multiple level-ups from one reward and preserves the monster's missing HP while increasing max HP.

## Traits

Each new individual receives exactly one Trait from the species' `trait_ids` list unless a valid Trait is explicitly requested.

No hidden quality/rarity value is created.

## Moves

Each monster has:

- `unlocked_move_ids`
- `equipped_move_ids`
- maximum four equipped move slots

Phase 4 initializes the monster with its species' currently-authored move list, up to four equipped moves. Later food-development move unlocking can call `unlock_move()` and `equip_move()` without replacing this system.

## Healing / recovery

Implemented APIs:

```gdscript
MonsterManager.damage_monster(id, amount)
MonsterManager.heal_monster(id, amount)
MonsterManager.heal_all()
```

The final inn/farm/sleep recovery trigger can call these APIs in later phases.

## Save-safe data

The manager keeps runtime `MonsterInstance` Resources while playing, but synchronizes them into plain dictionaries in:

```text
GameState.party
GameState.monster_storage
```

This means the existing JSON `SaveManager` can serialize the monster roster without attempting to serialize scene nodes or live Resources.

## Test the system

Run the project and press:

**Ctrl+M — Monster Viewer**

Then select **Create Demo Roster**.

It creates:

- Lv. 5 Spriggle — party
- Lv. 8 Brambleaf — party
- Lv. 10 Bloomtail — farm/storage

The viewer lets you test:

- selection
- current/max HP
- stats
- Trait
- four-move structure
- runtime ID
- +100 EXP
- level ups
- damage
- healing
- move between party/farm
- heal entire roster

Existing shortcuts remain:

- F3 — debug overlay
- F7 — data registry viewer
- Ctrl+M — monster viewer

## Placeholder art

Phase 4 includes a code-drawn placeholder:

`scenes/monsters/monster_placeholder.tscn`

Your production monster sprites can be added under:

`assets/sprites/monsters/<species>/`

Monster instance logic has no dependency on the placeholder visual, so replacing art does not require changes to progression, party, saving, battle, capture, or evolution systems.

## Phase 4 definition of done

- Species data loads through `DataRegistry`.
- An individual monster can be created from a species ID.
- Every individual gets a unique runtime ID.
- Stats scale by level.
- Current/max HP work.
- Damage/healing/fainting work.
- EXP and level ups work.
- Trait generation works.
- Move slots work.
- Party works.
- Overflow/farm storage works.
- Party ↔ farm movement works.
- Monster data synchronizes to `GameState`.
- Saved dictionaries can reconstruct `MonsterInstance` objects.
- Monster Viewer exposes the system for testing.

## Next phase

Phase 5 can consume `MonsterInstance` directly to build the battle prototype without duplicating monster stats, moves, Traits, HP, or party logic.
