# Phase 5 — Battle Prototype

Built on the corrected Phase 4 v2 project.

## What is included

- 1v1 active-monster battles.
- Player party support with switching.
- Wild enemy creation from the Phase 3 DataRegistry.
- Turn order using move Priority, then Speed, then random tie-break.
- Move Power, Accuracy and Cooldowns.
- Damage calculation using runtime Attack and Defense.
- Support move effects for `Root Guard` and `Soothing Pollen`.
- Temporary stat stages (-6 to +6).
- Trait hook architecture ready for future battle Traits.
- KO / forced replacement / victory / defeat.
- Simple enemy AI.
- World pause while battle UI is open.
- Persistent party HP after battle.
- Return to overworld after battle.
- Placeholder battle visuals that can be replaced with your own art later.
- A wild Spriggle battle trigger in Home Wilderness.
- Ctrl+B debug battle shortcut.

## Run the battle

The development build automatically creates the Phase 4 demo party if the roster is empty.

### Normal test

1. Run the project.
2. Walk east from Home Village into Home Wilderness.
3. Find the green placeholder Spriggle.
4. Walk close and press Interact (`E` / `Space` / controller confirm).
5. Choose a move or switch party monsters.
6. After victory/defeat, select `Return to World`.

### Debug test

Press **Ctrl+B** anywhere in the overworld.

Unlike F8, Ctrl+B does not conflict with Godot Editor's Stop Running shortcut.

## Battle files

```text
scripts/battle/
├── battle_combatant.gd
├── battle_session.gd
├── battle_manager.gd
├── battle_screen.gd
└── wild_battle_trigger.gd

scenes/battle/
├── battle_screen.tscn
└── wild_battle_trigger.tscn
```

## Runtime architecture

```text
MonsterManager Party
        ↓
BattleManager
        ↓
BattleSession
   ├── BattleCombatant (player)
   └── BattleCombatant (enemy)
        ↓
BattleScreen
        ↓
Battle result
        ↓
MonsterManager sync
        ↓
Return to World
```

`BattleCombatant` does not replace `MonsterInstance`. It only stores temporary battle state such as stat stages and cooldowns. HP damage is applied to the underlying `MonsterInstance`, so it persists after battle.

## Current damage formula

Phase 5 intentionally uses a simple transparent prototype formula:

```text
raw = move_power × (Attack / Defense) × (1 + level × 0.035)
final = raw × random variance (0.92–1.08)
minimum damage = 1
```

This formula is isolated inside `BattleSession._calculate_damage()` so balancing later does not require rewriting the battle architecture.

## Cooldowns

A move with cooldown 1 cannot be used on the next turn after it is used. Cooldowns tick at the end of each round.

## Temporary stat stages

Phase 5 supports Attack, Defense and Speed stages from -6 to +6.

- Positive stage: +25% per stage.
- Negative stage: inverse 25% scaling.

Current sample effects:

- `Root Guard` → raises the user's Defense by 1 stage.
- `Soothing Pollen` → lowers the target's Attack by 1 stage.

## Enemy AI

The prototype AI:

- Selects only moves that are off cooldown.
- Prefers damaging moves about 80% of the time.
- Can use support moves.
- Uses Priority and Speed through the same turn-order system as the player.

## Art replacement

The colored rectangles in `battle_screen.tscn` are only placeholders.

You can later replace:

- `PlayerVisual`
- `EnemyVisual`
- battle background
- move buttons
- HP bars

with Art Bible assets without touching `BattleSession` or `BattleManager`.

## Not included yet

Phase 5 intentionally does not implement:

- Capture — Phase 6.
- Overworld wild-monster spawning/AI — Phase 7.
- Items in battle — later integration.
- Status conditions beyond temporary stat changes.
- Element effectiveness table.
- Battle VFX/animation sequencing.
- Trainer teams with multiple enemy monsters in authored encounters.
- PvP/networking.

The session architecture already supports multiple enemy combatants, even though the Phase 5 wild trigger uses one enemy.
