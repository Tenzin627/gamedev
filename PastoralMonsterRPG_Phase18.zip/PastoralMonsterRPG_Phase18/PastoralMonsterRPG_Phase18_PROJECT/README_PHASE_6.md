# Phase 6 — Capture System

Built on the corrected Phase 5 battle prototype.

## What Phase 6 adds

- Gya inventory stock and consumption.
- Wild-battle Capture command.
- HP-based non-guaranteed capture probability.
- Capture presentation with skip input.
- Failed capture consumes the turn; the enemy acts.
- Successful capture ends the battle.
- Captured MonsterInstance is preserved exactly.
- Automatic party-full routing to farm storage.
- Capture metadata on the monster instance.
- Journal seen/captured species hooks.
- Capture events for future quests/tutorial/UI.

## MVP Capture Formula

The Phase 6 prototype uses a simple readable rule:

- Full HP: 20%
- As HP decreases, chance rises linearly.
- Near 0 HP: up to 85%
- Capture is never guaranteed.

Formula:

```text
chance = 20% + missing_hp_ratio × 65%
```

This is isolated in `CaptureManager.calculate_capture_probability()` so balancing can change later without touching battle code.

## Gya

Development builds start with 10 basic Gya if the inventory has never been initialized.

Item ID:

```text
item.gya_basic
```

The temporary stock exists only so Phase 6 can be tested immediately. Later inventory/shop/tutorial phases can replace the source of Gya.

## Capture Battle Flow

```text
Wild Battle
  ↓
Lower enemy HP
  ↓
Use Gya
  ↓
Consume 1 Gya
  ↓
Roll capture chance
  ├─ Failure → enemy acts → next turn
  └─ Success → preserve enemy MonsterInstance
                ↓
             Party has room?
              ├─ Yes → Party
              └─ No  → Farm
                ↓
             Update Journal
                ↓
             End Battle
```

## Capture Presentation

The included panel is a placeholder. During the short presentation, Confirm / Interact / Cancel can be used as skip input.

Replace the panel later with the Art Bible Gya animation/VFX without changing capture logic.

## Captured Monster Data

A successful capture keeps the same runtime monster object and adds capture metadata:

```text
method
gya item id
map id
game day
battle type
```

Level, HP, Trait and moves are not rerolled.

## Journal Foundation

Phase 6 stores:

```text
GameState.player_profile["seen_species"]
GameState.player_profile["captured_species"]
```

The future Journal UI can read these directly or move them into a dedicated journal system later.

## Testing

1. Run the game.
2. Enter Home Wilderness and interact with the wild Spriggle, or use Ctrl+B.
3. Use attacks to reduce its HP.
4. Watch the capture percentage increase.
5. Press `Use Gya`.
6. Test both capture success and failure.
7. Use Ctrl+M to inspect the captured monster after returning to the world.
8. Fill the four party slots and capture again to verify farm routing.

## Existing Debug Controls

- F3 — Debug overlay
- F7 — Database viewer
- Ctrl+M — Monster viewer
- Ctrl+B — Start debug battle

## Important Production Rule

Only eligible wild encounters use standard Gya capture. Trainer-owned monsters are not capture targets. Special/boss-like wild encounters can later explicitly set capture eligibility while still using this same capture calculation.
