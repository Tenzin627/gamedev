# Phase 7 — Encounter System

Built on Phase 6.

## What Phase 7 adds

- Reusable weighted encounter-table resolver.
- Visible roaming wild monsters in the overworld.
- Monster contact starts a wild battle.
- Spawn zones maintain a configurable active population.
- Defeated/captured monsters are removed and respawn after a delay.
- Failed/defeated-player battles return the existing wild monster to the map.
- Encounter table min/max level rolls.
- Weighted species selection.
- Hooks for time, season, weather, map and per-entry conditions.
- Existing Phase 6 capture flow remains intact.

## Home Wilderness sample

`home_wilderness_day.tres` currently rolls:

- Spriggle — 65%, Lv. 2–4
- Brambleaf — 25%, Lv. 3–5
- Bloomtail — 10%, Lv. 4–6

The Meadow spawn zone keeps up to 4 visible monsters active. A defeated or captured monster respawns after approximately 8 seconds.

## Key files

- `scripts/exploration/encounter_resolver.gd`
- `scripts/exploration/encounter_spawn_zone.gd`
- `scripts/exploration/wild_monster_actor.gd`
- `scenes/world/components/encounter_spawn_zone.tscn`
- `scenes/world/components/wild_monster_actor.tscn`
- `data/encounters/home_wilderness_day.tres`

## How to test

1. Run the project.
2. Walk east from Home Village into Home Wilderness.
3. Several green placeholder monsters should appear and wander locally.
4. Touch a monster to start battle.
5. Defeat or capture it to remove it from the map.
6. Wait briefly and a replacement is selected from the encounter table.
7. If your party loses, that wild monster reappears instead of being consumed.

## Replacing placeholders

Replace the `Visual` node of `wild_monster_actor.tscn` with your own species-aware sprite/animation presentation later. Encounter logic is independent of final monster art.

## Future hooks

Phase 10 can provide authoritative time/weather values. The resolver already reads:

- `time`
- `season`
- `weather`
- `map_id`

Encounter entries can also carry their own `conditions` dictionaries.
