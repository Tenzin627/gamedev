# Phase 8 — Inventory & Items

Built on Phase 7.

## Added
- InventoryManager autoload
- Stack limits enforced from ItemData
- Add/remove/consume APIs
- Currency with save support
- Buy/sell APIs
- Inventory UI (I / controller inventory action)
- Item-use routing
- Field Balm sample medicine
- World item pickup
- Gathering nodes now award real ItemData
- Village shopkeeper and shop UI
- CaptureManager now consumes Gya through InventoryManager

## Test
1. Run the game.
2. Press **I** to open Inventory.
3. Interact with the gold-marked shopkeeper in Home Village and buy Gya, Field Balm, or Meadow Root Seed.
4. Pick up the gold Field Balm pickup.
5. Gather green resource nodes; they now add real inventory items.
6. Damage a party monster in battle or Monster Viewer, then use Field Balm from Inventory to heal 20 HP.
7. Capture attempts use the same central inventory stock of Gya.

## Starting development stock
- 250 coins
- 10 Gya
- 5 Meadow Root Seeds
- 2 Field Balms

These are development conveniences and can be removed when progression/shop balancing is implemented.
