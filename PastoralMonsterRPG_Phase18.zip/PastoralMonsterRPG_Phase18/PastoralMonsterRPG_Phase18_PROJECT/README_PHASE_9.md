# Phase 9 — Dual-Grid Farming Prototype

This phase builds the MVP farming loop on top of Phase 8 and uses the dual-grid technique researched from jess::codes' **Draw fewer tiles - by using a Dual-Grid system!**.

## Dual-grid architecture

The farm intentionally separates two concerns:

- `LogicalGrid` (`TileMapLayer`) represents normal farm cells.
- `DisplayGrid` (`TileMapLayer`) is shifted by half a tile and chooses one of 16 visual combinations from the four surrounding logical cells.
- `GameState.farm_state` remains the save/source-of-truth. TileMapLayers are a visual projection of that state.

This means farming rules never depend on decorative terrain edges.

For each display cell the renderer checks four neighboring logical cells:

```text
TL  TR
BL  BR
```

Each occupied/tilled neighbor contributes one bit, producing a mask from `0..15`. The mask selects a tile from the 4×4 placeholder atlas.

```text
World / logical grid        Offset display grid
[soil][soil][grass]    ->   smooth soil/grass boundaries
[soil][grass][grass]
```

The included atlas is development-only:

`assets/tilesets/placeholder/dual_grid_soil_placeholder.png`

Replace it with your hand-painted Art Bible dual-grid soil/grass atlas later. The farm logic does not change.

## Farm map

`scenes/world/maps/home_farm.tscn`

Home Village has a new interact travel point near the south side that leads to the Home Farm.

## Controls

- `1` — Hoe
- `2` — Plant
- `3` — Water
- `4` — Harvest
- `E` / `Space` / controller interact — use the selected farm tool on the cell under the player

The Farm HUD also exposes buttons and a crop dropdown.

## Farming loop

```text
Grass
 ↓ Hoe
Tilled Soil
 ↓ Plant (consumes seed)
Planted Crop
 ↓ Water
Growing
 ↓ timer
Ready
 ↓ Harvest
Crop yield + 1 recovered seed
 ↓
Tilled Soil remains
```

Crops never wither and do not punish the player for returning late.

## Crops included

- Meadow Root — 30 authored growth minutes, yield 2
- Sunberry — 20 authored growth minutes, yield 3
- Dewleaf — 45 authored growth minutes, yield 2

For development testing, one authored growth minute is currently `0.25` real seconds. This keeps a 20-minute crop testable in about five seconds. Phase 10 can replace this scale with the unified game-time rules.

## Watering

For Phase 9, watering is required once after planting. Growth pauses until watered, then continues to completion. The unified day/time system in Phase 10 can expand this into any final watering-frequency rule without changing crop data or farm saves.

## Expansion

Starter field:

`4 × 3 = 12 plots`

Expanded field:

`6 × 4 = 24 plots`

Interact with the expansion sign and spend `150 coins` to permanently unlock the remaining plots.

## Processing / Cooking

A placeholder Cooking Pot uses the existing `recipe.root_stew` definition.

Interact once to start processing (ingredients are consumed), then interact again after the timer to collect the result. Processing state is stored in `GameState.farm_state`, so it is save-safe.

## Save data

All farm state lives under:

`GameState.farm_state`

including:

- plot tilled state
- crop ID
- remaining growth time
- watering state
- ready state
- farm expansion
- active processing job

## Important design rule

**Logical data owns gameplay. Dual-grid owns presentation.**

Do not store crop state in the display TileMap. This prevents art/tile changes from breaking saves or farm mechanics.
