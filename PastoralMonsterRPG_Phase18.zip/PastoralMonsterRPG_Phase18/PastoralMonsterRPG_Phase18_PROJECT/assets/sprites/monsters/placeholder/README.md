# Monster Sprite Placeholder

Phase 4 uses a code-drawn placeholder so the project has no dependency on final monster art.

Put production sprites under `assets/sprites/monsters/<species_id>/` and assign them to the appropriate future `AnimatedSprite2D`/SpriteFrames scenes. Monster gameplay data does not depend on the visual node.
