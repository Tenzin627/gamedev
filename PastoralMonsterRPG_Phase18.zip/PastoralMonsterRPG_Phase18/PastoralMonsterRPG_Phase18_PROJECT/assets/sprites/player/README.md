# Replace the Player Placeholder Here

Put your final player sprite/animation assets in this folder.

The Player scene is:
`res://scenes/characters/player/player.tscn`

Select `Player` and enable `use_custom_animated_sprite`.
Then select `Visual/AnimatedSprite2D` and assign your SpriteFrames.

Recommended animation names:

Idle:
- idle_down
- idle_down_right
- idle_right
- idle_up_right
- idle_up
- idle_up_left
- idle_left
- idle_down_left

Walk:
- walk_down
- walk_down_right
- walk_right
- walk_up_right
- walk_up
- walk_up_left
- walk_left
- walk_down_left

The movement controller automatically chooses these animations from movement direction.
If an animation is missing, it falls back to down animations when possible.
