# Tilesets

Phase 2 uses Godot `TileMapLayer` map scenes.

- Development placeholder: `placeholder/phase2_placeholder_tiles.png`
- Placeholder logical cell size: 64x64 px.
- Final Art Bible environment TileSets should be placed in this directory.
- Use Godot TileSet resources with atlas/terrain/physics data for production maps.
- Keep gameplay map layers separated: Ground, GroundDetail, ObjectsBelow, Collision, ObjectsAbove.
