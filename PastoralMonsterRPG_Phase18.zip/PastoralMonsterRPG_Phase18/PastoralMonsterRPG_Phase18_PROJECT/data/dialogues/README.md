# Dialogue Data

Phase 13 dialogue is authored as `DialogueData` Resources.

Each node may contain:
- `id`
- `speaker`
- `text`
- `next`
- `conditions`
- `actions`
- `choices`

Supported conditions include Profile Tags, world state, relationships, quest state, time period, weather, season, and inventory quantities.
