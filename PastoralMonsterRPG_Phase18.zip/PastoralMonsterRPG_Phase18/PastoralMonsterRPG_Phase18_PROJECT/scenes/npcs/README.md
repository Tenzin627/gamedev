# NPC Scenes

`npc_actor.tscn` is the reusable Phase 13 NPC scene. Assign an `npc_id`; display name and default dialogue are read from DataRegistry.
