extends RefCounted
class_name BattleCombatant

var monster: MonsterInstance
var side: String = "player"
var stat_stages: Dictionary = {"attack": 0, "defense": 0, "speed": 0}
var cooldowns: Dictionary = {}

func _init(source_monster: MonsterInstance = null, combat_side: String = "player") -> void:
	monster = source_monster
	side = combat_side

func is_valid() -> bool:
	return monster != null and monster.get_species() != null

func is_fainted() -> bool:
	return monster == null or monster.is_fainted()

func get_name() -> String:
	return monster.get_display_name() if monster != null else "Unknown"

func get_level() -> int:
	return monster.level if monster != null else 1

func get_hp() -> int:
	return monster.current_hp if monster != null else 0

func get_max_hp() -> int:
	return monster.get_max_hp() if monster != null else 1

func get_stat(stat_name: String) -> int:
	if monster == null:
		return 1
	var base_value := monster.get_stat(stat_name)
	var stage := int(stat_stages.get(stat_name, 0))
	return maxi(1, int(round(float(base_value) * _stage_multiplier(stage))))

func change_stage(stat_name: String, amount: int) -> int:
	if not stat_stages.has(stat_name):
		return 0
	var before := int(stat_stages[stat_name])
	var after := clampi(before + amount, -6, 6)
	stat_stages[stat_name] = after
	return after - before

func can_use_move(move_id: String) -> bool:
	if monster == null or move_id.is_empty() or move_id not in monster.equipped_move_ids:
		return false
	return int(cooldowns.get(move_id, 0)) <= 0

func set_move_cooldown(move_id: String, turns: int) -> void:
	if turns <= 0:
		cooldowns.erase(move_id)
		return
	# +1 because cooldowns are ticked at the end of the round in which the move is used.
	cooldowns[move_id] = turns + 1

func get_move_cooldown(move_id: String) -> int:
	return maxi(0, int(cooldowns.get(move_id, 0)))

func tick_cooldowns() -> void:
	var keys := cooldowns.keys()
	for move_id in keys:
		var remaining := int(cooldowns.get(move_id, 0)) - 1
		if remaining <= 0:
			cooldowns.erase(move_id)
		else:
			cooldowns[move_id] = remaining

func reset_temporary_state() -> void:
	stat_stages = {"attack": 0, "defense": 0, "speed": 0}
	cooldowns.clear()

func _stage_multiplier(stage: int) -> float:
	# Simple readable stage curve for the prototype: +/-25% per stage.
	if stage >= 0:
		return 1.0 + (0.25 * float(stage))
	return 1.0 / (1.0 + (0.25 * float(abs(stage))))
