extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")
const BATTLE_SCREEN := preload("res://scenes/battle/battle_screen.tscn")

var _ui_root: Node = null
var _world_root: Node = null
var _battle_screen: BattleScreen = null
var _battle_active: bool = false

func register_host(ui_root: Node, world_root: Node) -> void:
	_ui_root = ui_root
	_world_root = world_root

func is_battle_active() -> bool:
	return _battle_active

func start_wild_battle(species_id: String, level: int = 3) -> bool:
	if _battle_active:
		return false
	if _ui_root == null:
		DevLog.error("BATTLE", "BattleManager has no registered UI host.")
		return false
	var available_party: Array[MonsterInstance] = []
	for monster in MonsterManager.get_party():
		if not monster.is_fainted():
			available_party.append(monster)
	if available_party.is_empty():
		DevLog.warn("BATTLE", "Cannot start battle: no healthy party monsters.")
		EventBus.interaction_message.emit("You need a healthy monster in your party.")
		return false

	var enemy := MonsterFactory.create(species_id, level)
	if enemy == null:
		return false

	_battle_screen = BATTLE_SCREEN.instantiate()
	_ui_root.add_child(_battle_screen)
	_battle_screen.battle_closed.connect(_on_battle_closed)
	_set_world_paused(true)
	_battle_active = true
	EventBus.battle_started.emit()
	var enemy_party: Array[MonsterInstance] = [enemy]
	Game.mode = Game.GameMode.BATTLE
	CaptureManager.record_seen_species(species_id)
	_battle_screen.start_battle(available_party, enemy_party, "wild")
	DevLog.info("BATTLE", "Started wild battle against %s Lv.%d." % [species_id, level])
	return true

func start_debug_battle() -> bool:
	if MonsterManager.get_party().is_empty():
		MonsterManager.seed_phase4_demo_roster()
	return start_wild_battle("monster.spriggle", 4)

func _on_battle_closed(result: Dictionary) -> void:
	_battle_active = false
	Game.mode = Game.GameMode.WORLD
	MonsterManager.sync_to_game_state()
	_set_world_paused(false)
	_battle_screen = null
	EventBus.battle_finished.emit(result)
	DevLog.info("BATTLE", "Battle finished: %s" % str(result))

func _set_world_paused(paused: bool) -> void:
	if _world_root == null:
		return
	_world_root.process_mode = Node.PROCESS_MODE_DISABLED if paused else Node.PROCESS_MODE_INHERIT
