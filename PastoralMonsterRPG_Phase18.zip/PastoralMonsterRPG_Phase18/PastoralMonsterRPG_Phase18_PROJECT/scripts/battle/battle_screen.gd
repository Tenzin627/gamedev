extends Control
class_name BattleScreen

signal battle_closed(result: Dictionary)

var session: BattleSession
var battle_type: String = "wild"
var _closing: bool = false
var _log_lines: Array[String] = []
var _capture_presentation_active: bool = false
var _capture_skip_requested: bool = false
var _pending_battle_result: Dictionary = {}

@onready var enemy_name: Label = %EnemyName
@onready var enemy_hp: ProgressBar = %EnemyHP
@onready var enemy_hp_text: Label = %EnemyHPText
@onready var player_name: Label = %PlayerName
@onready var player_hp: ProgressBar = %PlayerHP
@onready var player_hp_text: Label = %PlayerHPText
@onready var turn_label: Label = %TurnLabel
@onready var move_grid: GridContainer = %MoveGrid
@onready var switch_box: VBoxContainer = %SwitchBox
@onready var capture_button: Button = %CaptureButton
@onready var capture_chance_label: Label = %CaptureChanceLabel
@onready var log_label: Label = %LogLabel
@onready var result_panel: PanelContainer = %ResultPanel
@onready var result_label: Label = %ResultLabel
@onready var continue_button: Button = %ContinueButton
@onready var capture_panel: PanelContainer = %CapturePanel
@onready var capture_label: Label = %CaptureLabel

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	result_panel.visible = false
	capture_panel.visible = false
	continue_button.pressed.connect(_close_battle)
	capture_button.pressed.connect(_on_capture_pressed)

func start_battle(player_monsters: Array[MonsterInstance], enemy_monsters: Array[MonsterInstance], kind: String = "wild") -> void:
	battle_type = kind
	session = BattleSession.new()
	session.log_message.connect(_on_log_message)
	session.hp_changed.connect(_on_hp_changed)
	session.active_changed.connect(_on_active_changed)
	session.battle_ended.connect(_on_battle_ended)
	if not session.setup(player_monsters, enemy_monsters):
		_on_battle_ended({"outcome": "invalid", "turns": 0})
		return
	_on_log_message("A wild %s appeared!" % session.get_enemy_active().get_name())
	_refresh_all()

func _refresh_all() -> void:
	if session == null:
		return
	_refresh_combatant_panels()
	_refresh_move_buttons()
	_refresh_switch_buttons()
	_refresh_capture_controls()
	turn_label.text = "Turn %d" % session.turn_number

func _refresh_combatant_panels() -> void:
	var player := session.get_player_active()
	var enemy := session.get_enemy_active()
	if player != null:
		player_name.text = "%s  Lv.%d" % [player.get_name(), player.get_level()]
		player_hp.max_value = player.get_max_hp()
		player_hp.value = player.get_hp()
		player_hp_text.text = "%d / %d" % [player.get_hp(), player.get_max_hp()]
	if enemy != null:
		enemy_name.text = "%s  Lv.%d" % [enemy.get_name(), enemy.get_level()]
		enemy_hp.max_value = enemy.get_max_hp()
		enemy_hp.value = enemy.get_hp()
		enemy_hp_text.text = "%d / %d" % [enemy.get_hp(), enemy.get_max_hp()]

func _refresh_move_buttons() -> void:
	_clear_children(move_grid)
	var active := session.get_player_active()
	if active == null or active.monster == null:
		return
	for move_id in active.monster.equipped_move_ids:
		var move_data := DataRegistry.get_move(move_id)
		if move_data == null:
			continue
		var button := Button.new()
		var cooldown := active.get_move_cooldown(move_id)
		button.text = "%s\nPwr %d  CD %d%s" % [
			move_data.display_name,
			move_data.power,
			move_data.cooldown_turns,
			"  [%d left]" % cooldown if cooldown > 0 else ""
		]
		button.custom_minimum_size = Vector2(260, 78)
		button.disabled = cooldown > 0 or session.finished or _capture_presentation_active
		button.pressed.connect(_on_move_pressed.bind(move_id))
		move_grid.add_child(button)

func _refresh_switch_buttons() -> void:
	_clear_children(switch_box)
	var header := Label.new()
	header.text = "Switch"
	switch_box.add_child(header)
	for i in range(session.player_party.size()):
		var combatant := session.player_party[i]
		var button := Button.new()
		button.text = "%s Lv.%d  %d/%d HP%s" % [
			combatant.get_name(), combatant.get_level(), combatant.get_hp(), combatant.get_max_hp(),
			"  (Active)" if i == session.player_active_index else ""
		]
		button.disabled = i == session.player_active_index or combatant.is_fainted() or session.finished or _capture_presentation_active
		button.pressed.connect(_on_switch_pressed.bind(i))
		switch_box.add_child(button)

func _refresh_capture_controls() -> void:
	var count := CaptureManager.get_item_count()
	var enemy := session.get_enemy_active()
	var chance := CaptureManager.calculate_capture_probability(enemy.monster) if enemy != null else 0.0
	capture_button.text = "Use Gya (%d)" % count
	capture_button.disabled = battle_type != "wild" or count <= 0 or session.finished or enemy == null or enemy.is_fainted() or _capture_presentation_active
	capture_chance_label.text = "Capture chance: %d%%" % int(round(chance * 100.0))

func _on_move_pressed(move_id: String) -> void:
	_set_commands_enabled(false)
	session.process_player_move(move_id)
	_refresh_all()

func _on_switch_pressed(index: int) -> void:
	_set_commands_enabled(false)
	session.process_player_switch(index)
	_refresh_all()

func _on_capture_pressed() -> void:
	if battle_type != "wild" or session == null or session.finished:
		return
	if CaptureManager.get_item_count() <= 0:
		_on_log_message("You have no Gya left.")
		_refresh_capture_controls()
		return
	_set_commands_enabled(false)
	_capture_presentation_active = true
	_capture_skip_requested = false
	capture_panel.visible = true
	capture_label.text = "You cast a Gya..."
	await _capture_delay(0.45)
	if not is_inside_tree():
		return
	capture_label.text = "The Gya trembles..."
	await _capture_delay(0.45)
	if not is_inside_tree():
		return
	var capture_result := session.process_capture_attempt()
	if bool(capture_result.get("success", false)):
		capture_label.text = "The Gya settles..."
	else:
		match str(capture_result.get("reason", "")):
			"escaped": capture_label.text = "It broke free!"
			"no_gya": capture_label.text = "No Gya remaining."
			_: capture_label.text = "Capture failed."
	await _capture_delay(0.65)
	capture_panel.visible = false
	_capture_presentation_active = false
	if not _pending_battle_result.is_empty():
		var pending_result: Dictionary = _pending_battle_result.duplicate(true)
		_pending_battle_result.clear()
		_show_battle_result(pending_result)
	_refresh_all()

func _capture_delay(seconds: float) -> void:
	if _capture_skip_requested:
		_capture_skip_requested = false
		return
	await get_tree().create_timer(seconds, true, false, true).timeout

func _on_log_message(message: String) -> void:
	_log_lines.append(message)
	while _log_lines.size() > 7:
		_log_lines.pop_front()
	log_label.text = "\n".join(_log_lines)

func _on_hp_changed(_side: String, _current_hp: int, _max_hp: int) -> void:
	_refresh_combatant_panels()
	_refresh_capture_controls()

func _on_active_changed(_side: String, _combatant: BattleCombatant) -> void:
	_refresh_all()

func _on_battle_ended(result: Dictionary) -> void:
	_set_commands_enabled(false)
	var outcome: String = str(result.get("outcome", "unknown"))
	if outcome == "captured" and _capture_presentation_active:
		_pending_battle_result = result.duplicate(true)
		return
	_show_battle_result(result)

func _show_battle_result(result: Dictionary) -> void:
	result_panel.visible = true
	var outcome: String = str(result.get("outcome", "unknown"))
	if outcome == "victory":
		result_label.text = "Victory!\nThe wild monster was defeated."
	elif outcome == "defeat":
		result_label.text = "Defeat\nYour party has no monsters able to battle."
	elif outcome == "captured":
		var destination: String = str(result.get("destination", "party"))
		result_label.text = "Captured!\nThe monster joined %s." % ("your party" if destination == "party" else "your farm")
	else:
		result_label.text = "Battle ended."
	continue_button.grab_focus()

func _set_commands_enabled(enabled: bool) -> void:
	for child in move_grid.get_children():
		if child is Button:
			child.disabled = not enabled
	for child in switch_box.get_children():
		if child is Button:
			child.disabled = not enabled
	if is_instance_valid(capture_button):
		capture_button.disabled = not enabled

func _close_battle() -> void:
	if _closing:
		return
	_closing = true
	var final_result := session.result.duplicate(true) if session != null else {"outcome": "unknown"}
	battle_closed.emit(final_result)
	queue_free()

func _unhandled_input(event: InputEvent) -> void:
	if _capture_presentation_active and (event.is_action_pressed("confirm") or event.is_action_pressed("interact") or event.is_action_pressed("cancel")):
		_capture_skip_requested = true
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("cancel") and session != null and session.finished:
		_close_battle()
		get_viewport().set_input_as_handled()

func _clear_children(container: Node) -> void:
	for child in container.get_children():
		child.queue_free()
