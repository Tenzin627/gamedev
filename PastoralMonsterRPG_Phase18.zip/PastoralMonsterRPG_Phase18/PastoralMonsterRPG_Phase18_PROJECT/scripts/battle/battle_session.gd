extends RefCounted
class_name BattleSession

signal log_message(message: String)
signal hp_changed(side: String, current_hp: int, max_hp: int)
signal active_changed(side: String, combatant: BattleCombatant)
signal battle_ended(result: Dictionary)

var player_party: Array[BattleCombatant] = []
var enemy_party: Array[BattleCombatant] = []
var player_active_index: int = 0
var enemy_active_index: int = 0
var turn_number: int = 1
var finished: bool = false
var result: Dictionary = {}

func setup(player_monsters: Array[MonsterInstance], enemy_monsters: Array[MonsterInstance]) -> bool:
	player_party.clear()
	enemy_party.clear()
	for monster in player_monsters:
		if monster != null:
			player_party.append(BattleCombatant.new(monster, "player"))
	for monster in enemy_monsters:
		if monster != null:
			enemy_party.append(BattleCombatant.new(monster, "enemy"))
	player_active_index = _first_alive_index(player_party)
	enemy_active_index = _first_alive_index(enemy_party)
	turn_number = 1
	finished = false
	result.clear()
	return player_active_index >= 0 and enemy_active_index >= 0

func get_player_active() -> BattleCombatant:
	if player_active_index < 0 or player_active_index >= player_party.size():
		return null
	return player_party[player_active_index]

func get_enemy_active() -> BattleCombatant:
	if enemy_active_index < 0 or enemy_active_index >= enemy_party.size():
		return null
	return enemy_party[enemy_active_index]

func get_available_player_switches() -> Array[int]:
	var result_indices: Array[int] = []
	for i in range(player_party.size()):
		if i != player_active_index and not player_party[i].is_fainted():
			result_indices.append(i)
	return result_indices

func process_player_move(move_id: String) -> void:
	if finished:
		return
	var player := get_player_active()
	var enemy := get_enemy_active()
	if player == null or enemy == null:
		_finish_if_needed()
		return
	if not player.can_use_move(move_id):
		_emit_log("That move is not ready.")
		return

	var enemy_move_id := _choose_enemy_move(enemy)
	var player_move := DataRegistry.get_move(move_id)
	var enemy_move := DataRegistry.get_move(enemy_move_id)
	var order := _resolve_action_order(player, player_move, enemy, enemy_move)

	for side_name in order:
		if finished:
			break
		if side_name == "player":
			if not player.is_fainted() and not enemy.is_fainted():
				_execute_move(player, enemy, move_id)
		else:
			if not enemy.is_fainted() and not player.is_fainted() and not enemy_move_id.is_empty():
				_execute_move(enemy, player, enemy_move_id)
		_check_faints()

	_end_round()


func process_capture_attempt(item_id: String = "item.gya_basic") -> Dictionary:
	if finished:
		return {"success": false, "reason": "battle_finished"}
	var enemy := get_enemy_active()
	var player := get_player_active()
	if enemy == null or enemy.monster == null or player == null:
		return {"success": false, "reason": "invalid"}

	var capture_result := CaptureManager.attempt_capture(enemy.monster, item_id, {"battle_type": "wild"})
	if bool(capture_result.get("success", false)):
		finished = true
		result = {
			"outcome": "captured",
			"turns": turn_number,
			"enemy_species_id": enemy.monster.species_id,
			"monster_instance_id": str(capture_result.get("monster_instance_id", "")),
			"destination": str(capture_result.get("destination", "")),
			"capture_chance": float(capture_result.get("chance", 0.0))
		}
		_emit_log("The wild %s was captured!" % enemy.get_name())
		battle_ended.emit(result)
		return capture_result

	if str(capture_result.get("reason", "")) == "escaped":
		_emit_log("The wild %s broke free!" % enemy.get_name())
		var enemy_move_id := _choose_enemy_move(enemy)
		if not enemy_move_id.is_empty() and not player.is_fainted():
			_execute_move(enemy, player, enemy_move_id)
			_check_faints()
		_end_round()
	return capture_result

func process_player_switch(target_index: int) -> void:
	if finished:
		return
	if target_index < 0 or target_index >= player_party.size() or target_index == player_active_index:
		return
	if player_party[target_index].is_fainted():
		return

	var previous := get_player_active()
	player_active_index = target_index
	var current := get_player_active()
	_emit_log("%s, come back! Go, %s!" % [previous.get_name(), current.get_name()])
	active_changed.emit("player", current)

	var enemy := get_enemy_active()
	if enemy != null and not enemy.is_fainted():
		var enemy_move_id := _choose_enemy_move(enemy)
		if not enemy_move_id.is_empty():
			_execute_move(enemy, current, enemy_move_id)
			_check_faints()
	_end_round()

func _execute_move(user: BattleCombatant, target: BattleCombatant, move_id: String) -> void:
	var move_data := DataRegistry.get_move(move_id)
	if move_data == null or not user.can_use_move(move_id):
		return

	_emit_log("%s used %s!" % [user.get_name(), move_data.display_name])
	if randf() > clampf(move_data.accuracy, 0.0, 1.0):
		_emit_log("It missed.")
		user.set_move_cooldown(move_id, move_data.cooldown_turns)
		return

	if move_data.power > 0:
		var damage := _calculate_damage(user, target, move_data.power)
		var dealt := target.monster.take_damage(damage)
		_emit_log("%s took %d damage." % [target.get_name(), dealt])
		hp_changed.emit(target.side, target.get_hp(), target.get_max_hp())

	_apply_move_effect(user, target, move_data)
	_apply_trait_hook(user, target, "after_move")
	user.set_move_cooldown(move_id, move_data.cooldown_turns)

func _calculate_damage(attacker: BattleCombatant, defender: BattleCombatant, power: int) -> int:
	var attack_value := float(attacker.get_stat("attack"))
	var defense_value := float(maxi(1, defender.get_stat("defense")))
	var level_term := 1.0 + (float(attacker.get_level()) * 0.035)
	var raw := (float(power) * attack_value / defense_value) * level_term
	var variance := randf_range(0.92, 1.08)
	return maxi(1, int(round(raw * variance)))

func _apply_move_effect(user: BattleCombatant, target: BattleCombatant, move_data: MoveData) -> void:
	match move_data.effect_id:
		"effect.raise_defense":
			var stages := int(move_data.effect_parameters.get("stages", 1))
			var changed := user.change_stage("defense", stages)
			if changed != 0:
				_emit_log("%s's Defense rose." % user.get_name())
		"effect.lower_attack":
			var stages := int(move_data.effect_parameters.get("stages", 1))
			var changed := target.change_stage("attack", -stages)
			if changed != 0:
				_emit_log("%s's Attack fell." % target.get_name())
		"effect.lower_speed":
			var speed_stages := int(move_data.effect_parameters.get("stages", 1))
			var speed_changed := target.change_stage("speed", -speed_stages)
			if speed_changed != 0:
				_emit_log("%s's Speed fell." % target.get_name())
		"effect.raise_attack":
			var attack_stages := int(move_data.effect_parameters.get("stages", 1))
			var attack_changed := user.change_stage("attack", attack_stages)
			if attack_changed != 0:
				_emit_log("%s rallied and its Attack rose." % user.get_name())
		"effect.heal_self":
			var heal_amount := maxi(1, int(move_data.effect_parameters.get("amount", 8)))
			var healed_amount := user.monster.heal(heal_amount)
			if healed_amount > 0:
				_emit_log("%s recovered %d HP." % [user.get_name(), healed_amount])
				hp_changed.emit(user.side, user.get_hp(), user.get_max_hp())
		"effect.current_pull":
			_emit_log("Current Pull disrupted the target's positioning.")
		_:
			pass

func _apply_trait_hook(user: BattleCombatant, target: BattleCombatant, trigger_name: String) -> void:
	# Phase 5 establishes the hook. Existing Phase 3 traits are exploration/support traits,
	# so they intentionally do not alter combat yet.
	if user == null or user.monster == null or user.monster.trait_id.is_empty():
		return
	var trait_data := DataRegistry.get_trait(user.monster.trait_id)
	if trait_data == null:
		return
	var _unused_target := target
	var _unused_trigger := trigger_name

func _resolve_action_order(player: BattleCombatant, player_move: MoveData, enemy: BattleCombatant, enemy_move: MoveData) -> Array[String]:
	var order: Array[String] = []

	if enemy_move == null:
		order.append("player")
		return order

	var player_priority := player_move.priority if player_move != null else 0
	var enemy_priority := enemy_move.priority

	if player_priority != enemy_priority:
		if player_priority > enemy_priority:
			order.append("player")
			order.append("enemy")
		else:
			order.append("enemy")
			order.append("player")
		return order

	var player_speed := player.get_stat("speed")
	var enemy_speed := enemy.get_stat("speed")

	if player_speed == enemy_speed:
		if randf() < 0.5:
			order.append("player")
			order.append("enemy")
		else:
			order.append("enemy")
			order.append("player")
		return order

	if player_speed > enemy_speed:
		order.append("player")
		order.append("enemy")
	else:
		order.append("enemy")
		order.append("player")
	return order

func _choose_enemy_move(enemy: BattleCombatant) -> String:
	if enemy == null or enemy.monster == null:
		return ""
	var usable: Array[String] = []
	for move_id in enemy.monster.equipped_move_ids:
		if enemy.can_use_move(move_id) and DataRegistry.get_move(move_id) != null:
			usable.append(move_id)
	if usable.is_empty():
		return ""
	# Prefer a damaging move most of the time, but occasionally use support moves.
	var damaging: Array[String] = []
	for move_id in usable:
		var move_data := DataRegistry.get_move(move_id)
		if move_data != null and move_data.power > 0:
			damaging.append(move_id)
	if not damaging.is_empty() and (randf() < 0.8 or damaging.size() == usable.size()):
		return damaging[randi() % damaging.size()]
	return usable[randi() % usable.size()]

func _check_faints() -> void:
	var player := get_player_active()
	var enemy := get_enemy_active()
	if enemy != null and enemy.is_fainted():
		_emit_log("%s fainted!" % enemy.get_name())
		var next_enemy := _first_alive_index(enemy_party)
		if next_enemy >= 0:
			enemy_active_index = next_enemy
			active_changed.emit("enemy", get_enemy_active())
		else:
			_finish("victory")
			return

	if player != null and player.is_fainted() and not finished:
		_emit_log("%s fainted!" % player.get_name())
		var next_player := _first_alive_index(player_party)
		if next_player >= 0:
			player_active_index = next_player
			_emit_log("Go, %s!" % get_player_active().get_name())
			active_changed.emit("player", get_player_active())
		else:
			_finish("defeat")

func _finish_if_needed() -> void:
	if _first_alive_index(enemy_party) < 0:
		_finish("victory")
	elif _first_alive_index(player_party) < 0:
		_finish("defeat")

func _finish(outcome: String) -> void:
	if finished:
		return
	finished = true
	result = {
		"outcome": outcome,
		"turns": turn_number,
		"enemy_species_id": enemy_party[0].monster.species_id if not enemy_party.is_empty() else ""
	}
	_emit_log("Victory!" if outcome == "victory" else "Your party was defeated.")
	battle_ended.emit(result)

func _end_round() -> void:
	for combatant in player_party:
		combatant.tick_cooldowns()
	for combatant in enemy_party:
		combatant.tick_cooldowns()
	turn_number += 1

func _first_alive_index(collection: Array[BattleCombatant]) -> int:
	for i in range(collection.size()):
		if not collection[i].is_fainted():
			return i
	return -1

func _emit_log(message: String) -> void:
	log_message.emit(message)
