extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

const DEFAULT_GYA_ID := "item.gya_basic"
const STARTING_GYA := 10
const MIN_CAPTURE_CHANCE := 0.20
const MAX_CAPTURE_CHANCE := 0.85

func _ready() -> void:
	pass

func get_item_count(item_id: String = DEFAULT_GYA_ID) -> int:
	return InventoryManager.get_count(item_id)

func has_item(item_id: String = DEFAULT_GYA_ID, amount: int = 1) -> bool:
	return InventoryManager.has_item(item_id, amount)

func add_item(item_id: String, amount: int) -> int:
	return InventoryManager.add_item(item_id, amount)

func consume_item(item_id: String, amount: int = 1) -> bool:
	return InventoryManager.consume_item(item_id, amount)

func calculate_capture_probability(monster: MonsterInstance) -> float:
	if monster == null:
		return 0.0
	var max_hp := maxi(1, monster.get_max_hp())
	var hp_ratio := clampf(float(monster.current_hp) / float(max_hp), 0.0, 1.0)
	var missing_hp_ratio := 1.0 - hp_ratio
	return clampf(MIN_CAPTURE_CHANCE + (MAX_CAPTURE_CHANCE - MIN_CAPTURE_CHANCE) * missing_hp_ratio, MIN_CAPTURE_CHANCE, MAX_CAPTURE_CHANCE)

func attempt_capture(monster: MonsterInstance, item_id: String = DEFAULT_GYA_ID, context: Dictionary = {}) -> Dictionary:
	var result := {
		"success": false,
		"reason": "invalid",
		"chance": 0.0,
		"roll": 1.0,
		"destination": "",
		"monster_instance_id": "",
		"species_id": ""
	}
	if monster == null or monster.is_fainted():
		result.reason = "ineligible"
		return result
	if not consume_item(item_id, 1):
		result.reason = "no_gya"
		return result

	var chance := calculate_capture_probability(monster)
	var roll := randf()
	result.chance = chance
	result.roll = roll
	result.species_id = monster.species_id
	EventBus.capture_attempted.emit(monster.species_id, chance)

	if roll >= chance:
		result.reason = "escaped"
		DevLog.info("CAPTURE", "Capture failed for %s (%.1f%%, roll %.3f)." % [monster.species_id, chance * 100.0, roll])
		return result

	monster.capture_data = {
		"method": "gya",
		"item_id": item_id,
		"map_id": GameState.current_map_id,
		"game_day": int(GameState.game_time.get("day", 1)),
		"battle_type": str(context.get("battle_type", "wild"))
	}
	var destination := MonsterManager.add_monster(monster, "auto")
	result.success = destination == "party" or destination == "farm"
	result.reason = "captured" if result.success else "roster_failed"
	result.destination = destination
	result.monster_instance_id = monster.instance_id

	if result.success:
		_record_journal_capture(monster.species_id)
		EventBus.monster_captured.emit(monster.instance_id)
		DevLog.info("CAPTURE", "Captured %s -> %s." % [monster.species_id, destination])
	return result

func record_seen_species(species_id: String) -> void:
	var seen_value: Variant = GameState.player_profile.get("seen_species", {})
	var seen: Dictionary = seen_value if seen_value is Dictionary else {}
	if not bool(seen.get(species_id, false)):
		seen[species_id] = true
		GameState.player_profile["seen_species"] = seen
		EventBus.journal_monster_updated.emit(species_id)

func _record_journal_capture(species_id: String) -> void:
	var captured_value: Variant = GameState.player_profile.get("captured_species", {})
	var captured: Dictionary = captured_value if captured_value is Dictionary else {}
	captured[species_id] = int(captured.get(species_id, 0)) + 1
	GameState.player_profile["captured_species"] = captured

	record_seen_species(species_id)
