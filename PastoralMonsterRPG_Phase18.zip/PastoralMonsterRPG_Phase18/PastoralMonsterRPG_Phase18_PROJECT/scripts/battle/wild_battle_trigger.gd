extends Interactable
class_name WildBattleTrigger

@export var species_id: String = "monster.spriggle"
@export_range(1, 100, 1) var level: int = 3
@export var disable_after_victory: bool = false

var _resolved: bool = false

func _ready() -> void:
	interaction_prompt = "Battle"
	EventBus.battle_finished.connect(_on_battle_finished)

func can_interact(_interactor: Node) -> bool:
	return enabled and not _resolved and not BattleManager.is_battle_active()

func interact(_interactor: Node) -> void:
	if not can_interact(_interactor):
		return
	BattleManager.start_wild_battle(species_id, level)

func _on_battle_finished(result: Dictionary) -> void:
	if not disable_after_victory:
		return
	if str(result.get("outcome", "")) == "victory":
		_resolved = true
		visible = false
		monitorable = false
