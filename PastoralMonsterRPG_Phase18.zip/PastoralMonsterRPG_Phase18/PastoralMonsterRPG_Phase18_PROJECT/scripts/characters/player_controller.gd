extends CharacterBody2D
class_name PlayerController

@export_category("Movement")
@export var move_speed: float = 320.0
@export var acceleration: float = 2200.0
@export var deceleration: float = 2600.0

@export_category("Animation")
@export var use_custom_animated_sprite: bool = false

@onready var interaction_component: InteractionComponent = $InteractionComponent
@onready var animated_sprite: AnimatedSprite2D = $Visual/AnimatedSprite2D
@onready var placeholder_visual: Node2D = $Visual/PlaceholderVisual
@onready var prompt_panel: Control = $PlayerUI/PromptPanel
@onready var prompt_label: Label = $PlayerUI/PromptPanel/PromptLabel
@onready var feedback_label: Label = $PlayerUI/FeedbackLabel

var facing_direction := Vector2.DOWN
var _feedback_time := 0.0

func _ready() -> void:
	EventBus.interaction_message.connect(_on_interaction_message)
	_update_visual_mode()

func _physics_process(delta: float) -> void:
	if Game.mode != Game.GameMode.WORLD:
		velocity = velocity.move_toward(Vector2.ZERO, deceleration * delta)
		move_and_slide()
		_update_animation(Vector2.ZERO)
		prompt_panel.visible = false
		return

	var input_vector := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if input_vector.length_squared() > 1.0:
		input_vector = input_vector.normalized()

	var target_velocity := input_vector * move_speed
	var rate := acceleration if input_vector.length_squared() > 0.001 else deceleration
	velocity = velocity.move_toward(target_velocity, rate * delta)

	if input_vector.length_squared() > 0.001:
		facing_direction = input_vector.normalized()

	move_and_slide()
	_update_animation(input_vector)
	_update_interaction_prompt()

	if _feedback_time > 0.0:
		_feedback_time -= delta
		if _feedback_time <= 0.0:
			feedback_label.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if Game.mode != Game.GameMode.WORLD:
		return
	if event.is_action_pressed("interact"):
		var target := interaction_component.get_best_interactable()
		if target != null and target.can_interact(self):
			target.interact(self)
			get_viewport().set_input_as_handled()

func _update_visual_mode() -> void:
	var custom_ready := use_custom_animated_sprite and animated_sprite.sprite_frames != null and not animated_sprite.sprite_frames.get_animation_names().is_empty()
	animated_sprite.visible = custom_ready
	placeholder_visual.visible = not custom_ready

func _update_animation(input_vector: Vector2) -> void:
	var moving := input_vector.length_squared() > 0.001
	if placeholder_visual.visible and placeholder_visual.has_method("set_motion_state"):
		placeholder_visual.set_motion_state(facing_direction, moving)
	if not animated_sprite.visible:
		return

	var suffix := _direction_suffix(facing_direction)
	var animation := StringName(("walk_" if moving else "idle_") + suffix)
	if animated_sprite.sprite_frames.has_animation(animation):
		if animated_sprite.animation != animation:
			animated_sprite.play(animation)
	elif moving and animated_sprite.sprite_frames.has_animation("walk_down"):
		animated_sprite.play("walk_down")
	elif animated_sprite.sprite_frames.has_animation("idle_down"):
		animated_sprite.play("idle_down")

func _direction_suffix(direction: Vector2) -> String:
	var angle := fposmod(direction.angle() + PI * 2.0, PI * 2.0)
	var octant := int(round(angle / (PI / 4.0))) % 8
	match octant:
		0: return "right"
		1: return "down_right"
		2: return "down"
		3: return "down_left"
		4: return "left"
		5: return "up_left"
		6: return "up"
		_: return "up_right"

func _update_interaction_prompt() -> void:
	var target := interaction_component.get_best_interactable()
	prompt_panel.visible = target != null
	if target != null:
		prompt_label.text = "[E / A]  %s" % target.interaction_prompt

func _on_interaction_message(message: String) -> void:
	feedback_label.text = message
	feedback_label.visible = true
	_feedback_time = 2.5
