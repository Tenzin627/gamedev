extends Node2D

var facing := Vector2.DOWN
var moving := false
var _time := 0.0

@onready var body: Polygon2D = $Body
@onready var head: Polygon2D = $Head
@onready var marker: Polygon2D = $DirectionMarker

func set_motion_state(direction: Vector2, is_moving: bool) -> void:
	if direction.length_squared() > 0.001:
		facing = direction.normalized()
	moving = is_moving
	marker.rotation = facing.angle() - PI / 2.0

func _process(delta: float) -> void:
	if moving:
		_time += delta * 10.0
		position.y = sin(_time) * 3.0
		rotation = sin(_time * 0.5) * 0.025
	else:
		_time = 0.0
		position.y = lerp(position.y, 0.0, min(delta * 10.0, 1.0))
		rotation = lerp(rotation, 0.0, min(delta * 10.0, 1.0))
