extends Area2D
class_name InteractionComponent

var nearby_interactables: Array[Interactable] = []

func _ready() -> void:
	area_entered.connect(_on_area_entered)
	area_exited.connect(_on_area_exited)

func get_best_interactable() -> Interactable:
	var best: Interactable = null
	var best_distance := INF
	for candidate in nearby_interactables:
		if not is_instance_valid(candidate) or not candidate.enabled:
			continue
		var distance := global_position.distance_squared_to(candidate.global_position)
		if distance < best_distance:
			best = candidate
			best_distance = distance
	return best

func _on_area_entered(area: Area2D) -> void:
	if area is Interactable:
		var candidate := area as Interactable
		if not nearby_interactables.has(candidate):
			nearby_interactables.append(candidate)

func _on_area_exited(area: Area2D) -> void:
	if area is Interactable:
		nearby_interactables.erase(area as Interactable)
