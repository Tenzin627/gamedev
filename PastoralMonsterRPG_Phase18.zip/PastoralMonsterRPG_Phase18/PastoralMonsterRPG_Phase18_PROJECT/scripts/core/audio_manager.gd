extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")
const REQUIRED_BUSES := ["Music", "Ambient", "SFX", "UI"]

func _ready() -> void:
	ensure_default_buses()

func ensure_default_buses() -> void:
	for bus_name in REQUIRED_BUSES:
		if AudioServer.get_bus_index(bus_name) == -1:
			AudioServer.add_bus()
			var index := AudioServer.bus_count - 1
			AudioServer.set_bus_name(index, bus_name)
			DevLog.info("AUDIO", "Created audio bus '%s'." % bus_name)

func set_bus_volume(bus_name: String, linear_value: float) -> void:
	var index := AudioServer.get_bus_index(bus_name)
	if index == -1:
		return
	var clamped := clampf(linear_value, 0.0, 1.0)
	var db := -80.0 if clamped <= 0.0001 else linear_to_db(clamped)
	AudioServer.set_bus_volume_db(index, db)

func set_bus_muted(bus_name: String, muted: bool) -> void:
	var index := AudioServer.get_bus_index(bus_name)
	if index != -1:
		AudioServer.set_bus_mute(index, muted)
