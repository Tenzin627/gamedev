extends Node

# Application / scene events.
signal game_started
signal game_loaded
signal world_scene_loading(scene_path: String)
signal world_scene_loaded(scene_path: String)
signal world_scene_unloaded(scene_path: String)
signal map_entered(map_id: String, display_name: String)
signal map_exited(map_id: String)
signal player_spawned(player: Node)
signal interaction_message(message: String)

# Phase 2 world events.
signal resource_gathered(resource_id: String, amount: int)
signal waystone_discovered(waystone_id: String)
signal encounter_zone_entered(zone_id: String, encounter_table_id: String)
signal encounter_zone_exited(zone_id: String)
signal wild_monster_spawned(zone_id: String, species_id: String, level: int)

# Future gameplay events. Systems can subscribe without direct dependencies.
signal item_added(item_id: String, amount: int)
signal item_removed(item_id: String, amount: int)
signal inventory_changed
signal currency_changed(new_amount: int)
signal item_used(item_id: String, result: Dictionary)
signal shop_requested(shop_name: String, stock_ids: Array[String])
signal monster_captured(monster_instance_id: String)
signal capture_attempted(species_id: String, probability: float)
signal journal_monster_updated(species_id: String)
signal monster_evolved(monster_instance_id: String, new_species_id: String)
signal quest_updated(quest_id: String)
signal quest_started(quest_id: String)
signal quest_objective_updated(quest_id: String, objective_id: String, current: int, required: int)
signal quest_resolved(quest_id: String, outcome_id: String)
signal quest_list_changed
signal world_state_changed(state_id: String, value: Variant)
signal battle_started
signal battle_finished(result: Dictionary)
signal battle_turn_started(turn_number: int)
signal battle_log(message: String)

# Phase 10 unified time / weather events.
signal game_minutes_advanced(minutes: int)
signal time_changed(day_index: int, minute_of_day: int)
signal hour_changed(hour: int)
signal day_changed(day_index: int)
signal season_changed(season_id: String, season_day: int)
signal time_period_changed(period_id: String)
signal weather_changed(weather_id: String)
signal time_scale_changed(multiplier: float)

# Phase 9 farming events.
signal farm_tool_changed(tool_id: String, crop_id: String)
signal farm_plot_changed(cell_key: String)
signal crop_planted(cell_key: String, crop_id: String)
signal crop_watered(cell_key: String, crop_id: String)
signal crop_ready(cell_key: String, crop_id: String)
signal crop_harvested(cell_key: String, crop_id: String, amount: int)
signal farm_expanded
signal processing_started(recipe_id: String, duration_seconds: float)
signal processing_collected(recipe_id: String, item_id: String, amount: int)


# Phase 4 monster-system events.
signal monster_added(monster_instance_id: String, destination: String)
signal monster_party_changed
signal monster_storage_changed
signal monster_leveled_up(monster_instance_id: String, new_level: int)
signal monster_hp_changed(monster_instance_id: String, current_hp: int, max_hp: int)
signal monster_roster_healed

# Phase 3 data architecture events.
signal data_registry_loaded(definition_count: int)
signal data_validation_finished(report: Dictionary)

# Phase 11 feeding / development events.
signal monster_fed(monster_instance_id: String, food_id: String, reaction: String, development_gained: Dictionary)
signal monster_move_unlocked(monster_instance_id: String, move_id: String)
signal monster_moves_changed(monster_instance_id: String)

# Phase 13 NPC / dialogue events.
signal dialogue_started(dialogue_id: String, npc_id: String)
signal dialogue_line_shown(dialogue_id: String, node_id: String, speaker: String, text: String)
signal dialogue_choice_selected(dialogue_id: String, node_id: String, choice_text: String)
signal dialogue_finished(dialogue_id: String)
signal relationship_changed(npc_id: String, new_value: int)
signal profile_tag_changed(tag_id: String, added: bool)
signal profile_tag_progress_changed(progress_id: String, current: int, required: int)
