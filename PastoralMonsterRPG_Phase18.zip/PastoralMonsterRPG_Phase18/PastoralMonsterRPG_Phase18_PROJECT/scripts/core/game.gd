extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

const GAME_VERSION := "0.17.0-phase17"

enum GameMode {
	BOOT,
	TITLE,
	WORLD,
	BATTLE,
	DIALOGUE
}

var mode: GameMode = GameMode.BOOT

func start_new_game(initial_world_scene: String) -> bool:
	GameState.reset()
	MonsterManager.load_from_game_state()
	mode = GameMode.WORLD
	var loaded := await SceneManager.load_world_scene(initial_world_scene, true)
	if loaded:
		EventBus.game_started.emit()
		DevLog.info("GAME", "Started new game.")
	return loaded

func return_to_boot_mode() -> void:
	mode = GameMode.BOOT
