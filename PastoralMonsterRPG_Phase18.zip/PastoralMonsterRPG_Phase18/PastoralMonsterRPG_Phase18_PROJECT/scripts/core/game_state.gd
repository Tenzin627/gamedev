extends Node

const DATA_VERSION := 2

var player_profile: Dictionary = {}
var party: Array = []
var monster_storage: Array = []
var inventory: Dictionary = {}
var currency: int = 0
var quest_state: Dictionary = {}
var world_state: Dictionary = {}
var farm_state: Dictionary = {}
var current_map_id: String = "map.home_village"
var current_spawn_id: String = "default"
var discovered_waystones: Dictionary = {}
var map_discovery: Dictionary = {}
var game_time: Dictionary = {
	"day": 1,
	"minute_of_day": 480,
	"season": "spring",
	"season_day": 1,
	"weather": "clear"
}

func reset() -> void:
	player_profile.clear()
	party.clear()
	monster_storage.clear()
	inventory.clear()
	currency = 0
	quest_state.clear()
	world_state.clear()
	farm_state.clear()
	current_map_id = "map.home_village"
	current_spawn_id = "default"
	discovered_waystones.clear()
	map_discovery.clear()
	game_time = {
		"day": 1,
		"minute_of_day": 480,
		"season": "spring",
		"season_day": 1,
		"weather": "clear"
	}

func to_save_dict() -> Dictionary:
	return {
		"data_version": DATA_VERSION,
		"player_profile": player_profile.duplicate(true),
		"party": party.duplicate(true),
		"monster_storage": monster_storage.duplicate(true),
		"inventory": inventory.duplicate(true),
		"currency": currency,
		"quest_state": quest_state.duplicate(true),
		"world_state": world_state.duplicate(true),
		"farm_state": farm_state.duplicate(true),
		"current_map_id": current_map_id,
		"current_spawn_id": current_spawn_id,
		"discovered_waystones": discovered_waystones.duplicate(true),
		"map_discovery": map_discovery.duplicate(true),
		"game_time": game_time.duplicate(true)
	}

func load_from_dict(data: Dictionary) -> void:
	player_profile = _dict_or_empty(data.get("player_profile", {}))
	party = _array_or_empty(data.get("party", []))
	monster_storage = _array_or_empty(data.get("monster_storage", []))
	inventory = _dict_or_empty(data.get("inventory", {}))
	currency = maxi(0, int(data.get("currency", 0)))
	quest_state = _dict_or_empty(data.get("quest_state", {}))
	world_state = _dict_or_empty(data.get("world_state", {}))
	farm_state = _dict_or_empty(data.get("farm_state", {}))
	current_map_id = String(data.get("current_map_id", "map.home_village"))
	current_spawn_id = String(data.get("current_spawn_id", "default"))
	discovered_waystones = _dict_or_empty(data.get("discovered_waystones", {}))
	map_discovery = _dict_or_empty(data.get("map_discovery", {}))
	game_time = _dict_or_empty(data.get("game_time", {}))
	if game_time.is_empty():
		game_time = {"day": 1, "minute_of_day": 480, "season": "spring", "season_day": 1, "weather": "clear"}

func _dict_or_empty(value: Variant) -> Dictionary:
	return value.duplicate(true) if value is Dictionary else {}

func _array_or_empty(value: Variant) -> Array:
	return value.duplicate(true) if value is Array else []
