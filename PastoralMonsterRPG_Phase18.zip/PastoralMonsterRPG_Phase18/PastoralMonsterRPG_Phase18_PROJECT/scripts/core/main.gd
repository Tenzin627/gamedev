extends Node

const InputBootstrap = preload("res://scripts/utilities/input_bootstrap.gd")
const DevLog = preload("res://scripts/utilities/dev_log.gd")

const DEVELOPMENT_WORLD := "res://scenes/world/maps/home_village.tscn"

@onready var world_root: Node = $WorldRoot
@onready var ui_root: CanvasLayer = $UIRoot
@onready var transition_layer: CanvasLayer = $TransitionLayer
@onready var debug_overlay: Control = $DebugLayer/DebugOverlay

func _ready() -> void:
	InputBootstrap.ensure_default_actions()
	AudioManager.ensure_default_buses()
	SceneManager.register_host(world_root, transition_layer)
	BattleManager.register_host(ui_root, world_root)
	DialogueManager.register_screen(ui_root.get_node_or_null("DialogueScreen"))
	DebugManager.register_overlay(debug_overlay)

	DevLog.info("GAME", "Pastoral Monster RPG %s" % Game.GAME_VERSION)
	DevLog.info("GAME", "Phase 17 Story Integration initialized.")

	QuestManager.refresh_availability()

	# Development build convenience: Phase 5 needs a party immediately for battle testing.
	if MonsterManager.get_party().is_empty():
		MonsterManager.seed_phase4_demo_roster()

	await SceneManager.load_world_scene(DEVELOPMENT_WORLD, false, "default")
	Game.mode = Game.GameMode.WORLD

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.ctrl_pressed and event.keycode == KEY_B:
			BattleManager.start_debug_battle()
			get_viewport().set_input_as_handled()
		elif event.ctrl_pressed and event.shift_pressed and event.keycode == KEY_T:
			TimeWeatherManager.advance_day()
			get_viewport().set_input_as_handled()
		elif event.ctrl_pressed and event.alt_pressed and event.keycode == KEY_T:
			TimeWeatherManager.advance_to_next_season()
			get_viewport().set_input_as_handled()
		elif event.ctrl_pressed and event.keycode == KEY_T:
			TimeWeatherManager.advance_hours(1)
			get_viewport().set_input_as_handled()
		elif event.ctrl_pressed and event.keycode == KEY_D:
			var development_screen := ui_root.get_node_or_null("DevelopmentScreen")
			if development_screen != null:
				development_screen.toggle()
			get_viewport().set_input_as_handled()
		elif event.ctrl_pressed and event.keycode == KEY_E:
			var evolution_screen := ui_root.get_node_or_null("EvolutionScreen")
			if evolution_screen != null:
				evolution_screen.toggle()
			get_viewport().set_input_as_handled()
		elif event.ctrl_pressed and event.keycode == KEY_Y:
			TimeWeatherManager.cycle_weather_debug()
			get_viewport().set_input_as_handled()
		elif event.ctrl_pressed and event.keycode == KEY_G:
			var world_state_viewer := ui_root.get_node_or_null("WorldStateViewer")
			if world_state_viewer != null:
				world_state_viewer.toggle()
			get_viewport().set_input_as_handled()
