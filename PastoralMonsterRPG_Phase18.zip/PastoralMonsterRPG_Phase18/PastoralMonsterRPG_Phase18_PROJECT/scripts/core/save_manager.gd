extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

const SAVE_VERSION := 2
const SAVE_FILE_PREFIX := "save_"

func save_game(slot: int = 0) -> bool:
	var payload := {
		"save_version": SAVE_VERSION,
		"game_state": GameState.to_save_dict()
	}

	var file := FileAccess.open(_get_save_path(slot), FileAccess.WRITE)
	if file == null:
		DevLog.error("SAVE", "Could not open save slot %d for writing." % slot)
		return false

	file.store_string(JSON.stringify(payload, "\t"))
	file.close()
	DevLog.info("SAVE", "Saved slot %d." % slot)
	return true

func load_game(slot: int = 0) -> bool:
	var path := _get_save_path(slot)
	if not FileAccess.file_exists(path):
		DevLog.warn("SAVE", "Save slot %d does not exist." % slot)
		return false

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		DevLog.error("SAVE", "Could not open save slot %d for reading." % slot)
		return false

	var text := file.get_as_text()
	file.close()

	var parsed: Variant = JSON.parse_string(text)
	if not parsed is Dictionary:
		DevLog.error("SAVE", "Save slot %d contains invalid JSON." % slot)
		return false

	var payload := parsed as Dictionary
	var save_version := int(payload.get("save_version", 0))
	if save_version != SAVE_VERSION:
		DevLog.warn("SAVE", "Save version %d differs from expected %d." % [save_version, SAVE_VERSION])

	var state_data: Variant = payload.get("game_state", {})
	if not state_data is Dictionary:
		DevLog.error("SAVE", "Save slot %d has no valid game_state." % slot)
		return false

	GameState.load_from_dict(state_data)
	EventBus.game_loaded.emit()
	DevLog.info("SAVE", "Loaded slot %d." % slot)
	return true

func save_exists(slot: int = 0) -> bool:
	return FileAccess.file_exists(_get_save_path(slot))

func delete_save(slot: int = 0) -> bool:
	var path := _get_save_path(slot)
	if not FileAccess.file_exists(path):
		return true
	return DirAccess.remove_absolute(ProjectSettings.globalize_path(path)) == OK

func _get_save_path(slot: int) -> String:
	return "user://%s%d.json" % [SAVE_FILE_PREFIX, max(slot, 0)]
