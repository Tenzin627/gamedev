extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

var _world_root: Node = null
var _transition: Node = null
var _current_world: Node = null
var _current_scene_path: String = ""
var _pending_spawn_id: String = "default"

func register_host(world_root: Node, transition: Node = null) -> void:
	_world_root = world_root
	_transition = transition

func load_world_scene(scene_path: String, with_fade: bool = true, spawn_id: String = "default") -> bool:
	if _world_root == null:
		DevLog.error("WORLD", "SceneManager has no registered WorldRoot.")
		return false

	_pending_spawn_id = spawn_id
	EventBus.world_scene_loading.emit(scene_path)

	if with_fade and _transition != null and _transition.has_method("fade_out"):
		await _transition.fade_out()

	var packed := load(scene_path) as PackedScene
	if packed == null:
		DevLog.error("WORLD", "Could not load scene '%s'." % scene_path)
		if with_fade and _transition != null and _transition.has_method("fade_in"):
			await _transition.fade_in()
		return false

	if is_instance_valid(_current_world):
		var old_path := _current_scene_path
		_current_world.queue_free()
		_current_world = null
		_current_scene_path = ""
		EventBus.world_scene_unloaded.emit(old_path)
		await get_tree().process_frame

	_current_world = packed.instantiate()
	_current_scene_path = scene_path
	_world_root.add_child(_current_world)
	EventBus.world_scene_loaded.emit(scene_path)
	DevLog.info("WORLD", "Loaded '%s' at spawn '%s'." % [scene_path, spawn_id])

	if with_fade and _transition != null and _transition.has_method("fade_in"):
		await _transition.fade_in()

	return true

func reload_world_scene() -> bool:
	if _current_scene_path.is_empty():
		return false
	return await load_world_scene(_current_scene_path, true, GameState.current_spawn_id)

func unload_world_scene(with_fade: bool = true) -> void:
	if not is_instance_valid(_current_world):
		return
	if with_fade and _transition != null and _transition.has_method("fade_out"):
		await _transition.fade_out()
	var old_path := _current_scene_path
	_current_world.queue_free()
	_current_world = null
	_current_scene_path = ""
	EventBus.world_scene_unloaded.emit(old_path)
	await get_tree().process_frame
	if with_fade and _transition != null and _transition.has_method("fade_in"):
		await _transition.fade_in()

func consume_pending_spawn_id(fallback: String = "default") -> String:
	var result := _pending_spawn_id if not _pending_spawn_id.is_empty() else fallback
	_pending_spawn_id = ""
	return result

func get_current_scene_path() -> String:
	return _current_scene_path

func get_current_world() -> Node:
	return _current_world
