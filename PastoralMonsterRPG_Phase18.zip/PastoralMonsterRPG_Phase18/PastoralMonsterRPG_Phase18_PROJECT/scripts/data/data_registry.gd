extends Node

const ResourceValidator = preload("res://scripts/utilities/resource_validator.gd")
const DevLog = preload("res://scripts/utilities/dev_log.gd")

signal data_loaded(definition_count: int)
signal validation_finished(report: Dictionary)

const CATEGORY_PATHS := {
	"monsters": "res://data/monsters",
	"moves": "res://data/moves",
	"traits": "res://data/traits",
	"items": "res://data/items",
	"food": "res://data/food",
	"crops": "res://data/crops",
	"recipes": "res://data/recipes",
	"npcs": "res://data/npcs",
	"dialogues": "res://data/dialogues",
	"encounters": "res://data/encounters",
	"quests": "res://data/quests",
	"profile_tags": "res://data/profile_tags",
	"trainers": "res://data/trainers",
	"world": "res://data/world"
}

const CATEGORY_PREFIXES := {
	"monsters": "monster.",
	"moves": "move.",
	"traits": "trait.",
	"items": "item.",
	"food": "food.",
	"crops": "crop.",
	"recipes": "recipe.",
	"npcs": "npc.",
	"dialogues": "dialogue.",
	"encounters": "encounter.",
	"quests": "quest.",
	"profile_tags": "profile_tag.",
	"trainers": "trainer.",
	"world": "world."
}

var _by_id: Dictionary = {}
var _by_category: Dictionary = {}
var _source_path_by_id: Dictionary = {}
var _last_report: Dictionary = {"ok": true, "errors": [], "warnings": [], "count": 0}

func _ready() -> void:
	reload_all()

func reload_all() -> Dictionary:
	_by_id.clear()
	_by_category.clear()
	_source_path_by_id.clear()

	for category in CATEGORY_PATHS.keys():
		_by_category[category] = []
		_scan_directory(category, CATEGORY_PATHS[category])

	_last_report = validate_all()
	data_loaded.emit(_by_id.size())
	validation_finished.emit(_last_report)
	EventBus.data_registry_loaded.emit(_by_id.size())
	EventBus.data_validation_finished.emit(_last_report)

	if _last_report.get("ok", false):
		DevLog.info("DATA", "Loaded %d definitions across %d categories." % [_by_id.size(), CATEGORY_PATHS.size()])
	else:
		DevLog.error("DATA", "Data validation failed with %d error(s)." % _last_report.get("errors", []).size())

	for warning in _last_report.get("warnings", []):
		DevLog.warn("DATA", str(warning))
	for error in _last_report.get("errors", []):
		DevLog.error("DATA", str(error))

	return _last_report

func _scan_directory(category: String, directory_path: String) -> void:
	var dir := DirAccess.open(directory_path)
	if dir == null:
		DevLog.warn("DATA", "Missing data directory: %s" % directory_path)
		return

	dir.list_dir_begin()
	var entry := dir.get_next()
	while not entry.is_empty():
		if not entry.begins_with("."):
			var full_path := directory_path.path_join(entry)
			if dir.current_is_dir():
				_scan_directory(category, full_path)
			elif entry.get_extension().to_lower() in ["tres", "res"]:
				_register_resource(category, full_path)
		entry = dir.get_next()
	dir.list_dir_end()

func _register_resource(category: String, path: String) -> void:
	var definition := ResourceLoader.load(path)
	if definition == null:
		DevLog.error("DATA", "Could not load data resource: %s" % path)
		return
	if not definition is GameDataDefinition:
		DevLog.warn("DATA", "Ignoring non-GameDataDefinition resource: %s" % path)
		return

	var content_id := str(definition.id)
	_by_category[category].append(definition)

	# Keep the first duplicate in the registry. Validation still reports all duplicates.
	if not content_id.is_empty() and not _by_id.has(content_id):
		_by_id[content_id] = definition
		_source_path_by_id[content_id] = path

func validate_all() -> Dictionary:
	var errors: Array[String] = []
	var warnings: Array[String] = []
	var all_definitions: Array = []
	var seen_ids: Dictionary = {}

	for category in _by_category.keys():
		for definition in _by_category[category]:
			all_definitions.append(definition)
			for error in ResourceValidator.validate_definition(definition):
				errors.append("%s: %s" % [definition.resource_path, error])

			var content_id := str(definition.id)
			if not content_id.is_empty():
				if seen_ids.has(content_id):
					errors.append("Duplicate ID '%s': %s and %s" % [content_id, seen_ids[content_id], definition.resource_path])
				else:
					seen_ids[content_id] = definition.resource_path

				var expected_prefix := str(CATEGORY_PREFIXES.get(category, ""))
				if not expected_prefix.is_empty() and not content_id.begins_with(expected_prefix):
					errors.append("%s uses ID '%s'; expected prefix '%s'." % [definition.resource_path, content_id, expected_prefix])

			_validate_definition_references(definition, errors, warnings)

	return {
		"ok": errors.is_empty(),
		"errors": errors,
		"warnings": warnings,
		"count": all_definitions.size(),
		"category_counts": get_category_counts()
	}

func _validate_definition_references(definition: GameDataDefinition, errors: Array[String], warnings: Array[String]) -> void:
	if definition is MonsterSpeciesData:
		for move_id in definition.move_ids:
			_require_reference(definition, move_id, "move.", errors)
		for trait_id in definition.trait_ids:
			_require_reference(definition, trait_id, "trait.", errors)
		for evolution_id in definition.evolution_species_ids:
			_require_reference(definition, evolution_id, "monster.", errors)
		for rule in definition.evolution_rules:
			var evolution_target := str(rule.get("target", ""))
			if evolution_target.is_empty():
				errors.append("%s has an evolution rule without target." % definition.id)
			else:
				_require_reference(definition, evolution_target, "monster.", errors)
			if str(rule.get("tendency", "")).is_empty():
				errors.append("%s evolution to '%s' has no tendency." % [definition.id, evolution_target])
			if int(rule.get("threshold", 0)) <= 0:
				errors.append("%s evolution to '%s' has an invalid threshold." % [definition.id, evolution_target])
			if int(rule.get("min_level", 1)) <= 0:
				errors.append("%s evolution to '%s' has an invalid min_level." % [definition.id, evolution_target])
		for rule in definition.move_unlock_rules:
			var unlock_move_id := str(rule.get("move_id", ""))
			if unlock_move_id.is_empty():
				errors.append("%s has a move unlock rule without move_id." % definition.id)
			else:
				_require_reference(definition, unlock_move_id, "move.", errors)
			if str(rule.get("tendency", "")).is_empty():
				errors.append("%s move unlock '%s' has no tendency." % [definition.id, unlock_move_id])
			if int(rule.get("threshold", 0)) <= 0:
				errors.append("%s move unlock '%s' has an invalid threshold." % [definition.id, unlock_move_id])

	elif definition is FoodData:
		if definition.item_id.is_empty():
			errors.append("%s has no item_id." % definition.id)
		else:
			_require_reference(definition, definition.item_id, "item.", errors)

	elif definition is CropData:
		if not definition.seed_item_id.is_empty():
			_require_reference(definition, definition.seed_item_id, "item.", errors)
		if not definition.harvest_item_id.is_empty():
			_require_reference(definition, definition.harvest_item_id, "item.", errors)

	elif definition is RecipeData:
		if not definition.output_item_id.is_empty():
			_require_reference(definition, definition.output_item_id, "item.", errors)
		for ingredient_id in definition.ingredients.keys():
			_require_reference(definition, str(ingredient_id), "item.", errors)

	elif definition is EncounterData:
		for entry in definition.entries:
			var monster_id := str(entry.get("monster_id", ""))
			if monster_id.is_empty():
				errors.append("%s contains an encounter entry without monster_id." % definition.resource_path)
			else:
				_require_reference(definition, monster_id, "monster.", errors)
			if float(entry.get("weight", 0.0)) <= 0.0:
				warnings.append("%s encounter '%s' has non-positive weight." % [definition.id, monster_id])

	elif definition is NPCData:
		if not definition.default_dialogue_id.is_empty():
			_require_reference(definition, definition.default_dialogue_id, "dialogue.", errors)

	elif definition is TrainerData:
		if not definition.npc_id.is_empty():
			_require_reference(definition, definition.npc_id, "npc.", errors)
		for team_entry in definition.team:
			var trainer_monster_id := str(team_entry.get("monster_id", ""))
			if trainer_monster_id.is_empty():
				errors.append("%s contains a trainer team entry without monster_id." % definition.id)
			else:
				_require_reference(definition, trainer_monster_id, "monster.", errors)
			if int(team_entry.get("level", 0)) <= 0:
				errors.append("%s trainer entry '%s' has invalid level." % [definition.id, trainer_monster_id])

	elif definition is DialogueData:
		_validate_dialogue(definition, errors, warnings)

	elif definition is ProfileTagData:
		if definition.tag_key.is_empty():
			errors.append("%s has no tag_key." % definition.id)
		if not definition.milestone_type.is_empty() and definition.milestone_threshold <= 0:
			errors.append("%s has milestone_type but invalid milestone_threshold." % definition.id)

	elif definition is QuestData:
		for prerequisite_id in definition.prerequisite_ids:
			_require_reference(definition, prerequisite_id, "quest.", errors)
		var objective_ids: Dictionary = {}
		for objective_value in definition.objectives:
			if not objective_value is Dictionary:
				errors.append("%s contains a non-dictionary objective." % definition.id)
				continue
			var objective: Dictionary = objective_value
			var objective_id := str(objective.get("id", ""))
			if objective_id.is_empty(): errors.append("%s contains an objective without id." % definition.id)
			elif objective_ids.has(objective_id): errors.append("%s contains duplicate objective id '%s'." % [definition.id, objective_id])
			objective_ids[objective_id] = true
			if str(objective.get("type", "")).is_empty(): errors.append("%s objective '%s' has no type." % [definition.id, objective_id])
			if int(objective.get("amount", 1)) <= 0: errors.append("%s objective '%s' has invalid amount." % [definition.id, objective_id])


func _validate_dialogue(dialogue: DialogueData, errors: Array[String], warnings: Array[String]) -> void:
	var ids: Dictionary = {}
	for node_value in dialogue.nodes:
		var node_data: Dictionary = node_value
		var node_id := str(node_data.get("id", ""))
		if node_id.is_empty():
			errors.append("%s contains a dialogue node without id." % dialogue.id)
			continue
		if ids.has(node_id):
			errors.append("%s contains duplicate node id '%s'." % [dialogue.id, node_id])
		ids[node_id] = true
	if not ids.has(dialogue.start_node_id):
		errors.append("%s start node '%s' does not exist." % [dialogue.id, dialogue.start_node_id])
	for rule_value in dialogue.start_rules:
		var rule: Dictionary = rule_value
		var rule_node := str(rule.get("node_id", ""))
		if not rule_node.is_empty() and not ids.has(rule_node):
			errors.append("%s start rule references missing node '%s'." % [dialogue.id, rule_node])
	for node_value in dialogue.nodes:
		var node_data: Dictionary = node_value
		var next_id := str(node_data.get("next", ""))
		if not next_id.is_empty() and next_id != "end" and not ids.has(next_id):
			errors.append("%s node '%s' references missing next node '%s'." % [dialogue.id, str(node_data.get("id", "")), next_id])
		var choices: Array = node_data.get("choices", []) as Array
		if choices is Array:
			for choice_value in choices:
				if choice_value is Dictionary:
					var choice_next := str((choice_value as Dictionary).get("next", ""))
					if not choice_next.is_empty() and choice_next != "end" and not ids.has(choice_next):
						errors.append("%s node '%s' choice references missing node '%s'." % [dialogue.id, str(node_data.get("id", "")), choice_next])

func _require_reference(owner: GameDataDefinition, reference_id: String, prefix: String, errors: Array[String]) -> void:
	if reference_id.is_empty():
		return
	if not reference_id.begins_with(prefix):
		errors.append("%s references '%s'; expected %s ID." % [owner.id, reference_id, prefix])
		return
	if not _by_id.has(reference_id):
		errors.append("%s references missing ID '%s'." % [owner.id, reference_id])

func has_definition(content_id: String) -> bool:
	return _by_id.has(content_id)

func get_definition(content_id: String) -> GameDataDefinition:
	return _by_id.get(content_id) as GameDataDefinition

func require_definition(content_id: String) -> GameDataDefinition:
	var definition := get_definition(content_id)
	assert(definition != null, "Missing game data definition: %s" % content_id)
	return definition

func get_category(category: String) -> Array:
	return (_by_category.get(category, []) as Array).duplicate()

func get_category_counts() -> Dictionary:
	var result := {}
	for category in CATEGORY_PATHS.keys():
		result[category] = (_by_category.get(category, []) as Array).size()
	return result

func get_source_path(content_id: String) -> String:
	return str(_source_path_by_id.get(content_id, ""))

func get_last_report() -> Dictionary:
	return _last_report.duplicate(true)

func get_monster(monster_id: String) -> MonsterSpeciesData:
	return get_definition(monster_id) as MonsterSpeciesData

func get_move(move_id: String) -> MoveData:
	return get_definition(move_id) as MoveData

func get_trait(trait_id: String) -> TraitData:
	return get_definition(trait_id) as TraitData

func get_item(item_id: String) -> ItemData:
	return get_definition(item_id) as ItemData

func get_food(food_id: String) -> FoodData:
	return get_definition(food_id) as FoodData

func get_crop(crop_id: String) -> CropData:
	return get_definition(crop_id) as CropData

func get_recipe(recipe_id: String) -> RecipeData:
	return get_definition(recipe_id) as RecipeData

func get_npc(npc_id: String) -> NPCData:
	return get_definition(npc_id) as NPCData

func get_encounter(encounter_id: String) -> EncounterData:
	return get_definition(encounter_id) as EncounterData

func get_quest(quest_id: String) -> QuestData:
	return get_definition(quest_id) as QuestData

func get_world_state(world_state_id: String) -> WorldStateData:
	return get_definition(world_state_id) as WorldStateData

func get_profile_tag(profile_tag_id: String) -> ProfileTagData:
	return get_definition(profile_tag_id) as ProfileTagData

func get_dialogue(dialogue_id: String) -> DialogueData:
	return get_definition(dialogue_id) as DialogueData

func get_trainer(trainer_id: String) -> TrainerData:
	return get_definition(trainer_id) as TrainerData
