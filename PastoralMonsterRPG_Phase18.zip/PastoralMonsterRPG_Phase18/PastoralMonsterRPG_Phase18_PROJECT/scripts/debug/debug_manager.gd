extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

var overlay_visible: bool = false
var fast_mode_enabled: bool = false
var _overlay: Control = null

func register_overlay(overlay: Control) -> void:
	_overlay = overlay
	_apply_overlay_visibility()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("debug_toggle"):
		overlay_visible = not overlay_visible
		_apply_overlay_visibility()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("debug_console"):
		DevLog.enabled = not DevLog.enabled
		print("[DEBUG] Logging %s" % ("enabled" if DevLog.enabled else "disabled"))
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("debug_reload_scene"):
		SceneManager.reload_world_scene()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("debug_speed"):
		fast_mode_enabled = not fast_mode_enabled
		Engine.time_scale = 4.0 if fast_mode_enabled else 1.0
		DevLog.info("DEBUG", "Time scale: %.1fx" % Engine.time_scale)
		get_viewport().set_input_as_handled()

func _apply_overlay_visibility() -> void:
	if is_instance_valid(_overlay):
		_overlay.visible = overlay_visible
