extends Node2D

const DevLog = preload("res://scripts/utilities/dev_log.gd")

func _ready() -> void:
	var report := DataRegistry.get_last_report()
	if bool(report.get("ok", false)):
		DevLog.info("DATA", "Phase 3 registry validated %d definitions." % int(report.get("count", 0)))
	else:
		for message in report.get("errors", []):
			DevLog.error("DATA", str(message))
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(-960.0, -540.0, 1920.0, 1080.0), Color("d9d4b9"), true)
	for x in range(-960, 961, 120):
		draw_line(Vector2(x, -540), Vector2(x, 540), Color(0.35, 0.33, 0.25, 0.14), 1.0)
	for y in range(-540, 541, 120):
		draw_line(Vector2(-960, y), Vector2(960, y), Color(0.35, 0.33, 0.25, 0.14), 1.0)
	draw_circle(Vector2(-360, 80), 90.0, Color("91a36d"))
	draw_circle(Vector2(290, -110), 130.0, Color("7f9660"))
	draw_rect(Rect2(-170, -110, 340, 220), Color("b9a57c"), true)
	draw_rect(Rect2(-150, -90, 300, 180), Color("e4d9b7"), true)
