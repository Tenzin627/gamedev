extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")
const FAVORITE_MULTIPLIER := 1.25
const DISLIKED_MULTIPLIER := 0.75

func _ready() -> void:
	EventBus.game_loaded.connect(_on_game_loaded)
	EventBus.game_started.connect(_on_game_loaded)

func _on_game_loaded() -> void:
	for monster in _all_monsters():
		_normalize_monster_development(monster)
		check_move_unlocks(monster)
	MonsterManager.sync_to_game_state()

func get_food_for_item(item_id: String) -> FoodData:
	for definition in DataRegistry.get_category("food"):
		var food := definition as FoodData
		if food != null and food.item_id == item_id:
			return food
	return null

func get_available_food_item_ids() -> Array[String]:
	var result: Array[String] = []
	for definition in DataRegistry.get_category("food"):
		var food := definition as FoodData
		if food == null or food.item_id.is_empty():
			continue
		if DataRegistry.get_item(food.item_id) != null and InventoryManager.get_count(food.item_id) > 0:
			result.append(food.item_id)
	result.sort()
	return result

func feed_monster(instance_id: String, item_id: String) -> Dictionary:
	var result := {
		"success": false,
		"reason": "invalid",
		"message": "That food cannot be used.",
		"reaction": "neutral",
		"development_gained": {},
		"moves_unlocked": [],
		"healed": 0
	}
	var monster := MonsterManager.find_monster(instance_id)
	if monster == null:
		result.reason = "missing_monster"
		result.message = "Monster not found."
		return result
	var food := get_food_for_item(item_id)
	if food == null:
		result.reason = "not_food"
		result.message = "That item has no monster food data."
		return result
	if not InventoryManager.has_item(item_id, 1):
		result.reason = "none_owned"
		result.message = "You do not have that food."
		return result

	_normalize_monster_development(monster)
	var reaction := get_food_reaction(monster, food)
	var multiplier := _reaction_multiplier(reaction)
	var gained := _calculate_development_gain(food, multiplier)
	if not InventoryManager.consume_item(item_id, 1):
		result.reason = "inventory_changed"
		result.message = "The food was no longer available."
		return result

	for tendency in gained.keys():
		monster.development[tendency] = maxi(0, int(monster.development.get(tendency, 0))) + int(gained[tendency])

	var recovery := food.recovery_amount
	if reaction == "favorite":
		recovery = int(ceil(float(recovery) * FAVORITE_MULTIPLIER))
	elif reaction == "disliked":
		recovery = int(floor(float(recovery) * DISLIKED_MULTIPLIER))
	var healed := monster.heal(maxi(0, recovery))
	_record_food_memory(monster, food, reaction)
	var unlocked := check_move_unlocks(monster)
	MonsterManager.sync_to_game_state()

	result.success = true
	result.reason = "fed"
	result.reaction = reaction
	result.development_gained = gained
	result.moves_unlocked = unlocked
	result.healed = healed
	result.message = _build_feed_message(monster, food, reaction, gained, unlocked, healed)
	EventBus.monster_fed.emit(monster.instance_id, food.id, reaction, gained)
	for move_id in unlocked:
		EventBus.monster_move_unlocked.emit(monster.instance_id, move_id)
	return result

func get_food_reaction(monster: MonsterInstance, food: FoodData) -> String:
	var species := monster.get_species()
	if species == null:
		return "neutral"
	var food_tags: Array[String] = []
	for tag in food.tags:
		food_tags.append(str(tag))
	for tag in food.reaction_tags:
		if str(tag) not in food_tags:
			food_tags.append(str(tag))
	for disliked in species.disliked_food_tags:
		if str(disliked) in food_tags:
			return "disliked"
	for favorite in species.favorite_food_tags:
		if str(favorite) in food_tags:
			return "favorite"
	return "neutral"

func get_development(instance_id: String) -> Dictionary:
	var monster := MonsterManager.find_monster(instance_id)
	if monster == null:
		return {}
	_normalize_monster_development(monster)
	return monster.development.duplicate(true)

func get_dominant_tendency(monster: MonsterInstance) -> Dictionary:
	_normalize_monster_development(monster)
	var best_name := ""
	var best_value := -1
	var tied: Array[String] = []
	for key in monster.development.keys():
		var value := int(monster.development.get(key, 0))
		if value > best_value:
			best_name = str(key)
			best_value = value
			tied.clear()
			tied.append(best_name)
		elif value == best_value:
			tied.append(str(key))
	return {"tendency": best_name, "value": maxi(0, best_value), "tied": tied.size() > 1, "ties": tied}

func get_move_progress(monster: MonsterInstance) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var species := monster.get_species()
	if species == null:
		return result
	for rule in species.move_unlock_rules:
		var move_id := str(rule.get("move_id", ""))
		var tendency := str(rule.get("tendency", ""))
		var threshold := maxi(1, int(rule.get("threshold", 1)))
		if move_id.is_empty() or tendency.is_empty():
			continue
		result.append({
			"move_id": move_id,
			"tendency": tendency,
			"threshold": threshold,
			"current": maxi(0, int(monster.development.get(tendency, 0))),
			"unlocked": monster.knows_move(move_id)
		})
	return result

func check_move_unlocks(monster: MonsterInstance) -> Array[String]:
	var unlocked: Array[String] = []
	var species := monster.get_species()
	if species == null:
		return unlocked
	_normalize_monster_development(monster)
	for rule in species.move_unlock_rules:
		var move_id := str(rule.get("move_id", ""))
		var tendency := str(rule.get("tendency", ""))
		var threshold := maxi(1, int(rule.get("threshold", 1)))
		if move_id.is_empty() or tendency.is_empty() or monster.knows_move(move_id):
			continue
		if int(monster.development.get(tendency, 0)) >= threshold and monster.unlock_move(move_id):
			unlocked.append(move_id)
	return unlocked

func equip_unlocked_move(instance_id: String, move_id: String, slot: int = -1) -> Dictionary:
	var result := {"success": false, "reason": "invalid", "message": "Move could not be equipped."}
	var monster := MonsterManager.find_monster(instance_id)
	if monster == null:
		return result
	if not monster.knows_move(move_id):
		result.reason = "locked"
		result.message = "That move has not been developed yet."
		return result
	if slot < 0 and monster.equipped_move_ids.size() >= MonsterInstance.MAX_MOVE_SLOTS and move_id not in monster.equipped_move_ids:
		result.reason = "choose_slot"
		result.message = "All four move slots are full. Choose a slot to replace."
		return result
	if not monster.equip_move(move_id, slot):
		result.reason = "equip_failed"
		return result
	MonsterManager.sync_to_game_state()
	EventBus.monster_moves_changed.emit(monster.instance_id)
	result.success = true
	result.reason = "equipped"
	var move := DataRegistry.get_move(move_id)
	result.message = "%s equipped %s." % [monster.get_display_name(), move.display_name if move else move_id]
	return result

func _normalize_monster_development(monster: MonsterInstance) -> void:
	for tendency in ["vigor", "resilience", "insight"]:
		if not monster.development.has(tendency):
			monster.development[tendency] = 0

func _calculate_development_gain(food: FoodData, multiplier: float) -> Dictionary:
	var result := {}
	for key in food.development_properties.keys():
		var base := maxi(0, int(food.development_properties[key]))
		if base <= 0:
			continue
		result[str(key)] = maxi(1, int(round(float(base) * multiplier)))
	return result

func _reaction_multiplier(reaction: String) -> float:
	match reaction:
		"favorite": return FAVORITE_MULTIPLIER
		"disliked": return DISLIKED_MULTIPLIER
		_: return 1.0

func _record_food_memory(monster: MonsterInstance, food: FoodData, reaction: String) -> void:
	var entry: Dictionary = monster.favorite_food_memory.get(food.id, {})
	entry["times_fed"] = int(entry.get("times_fed", 0)) + 1
	entry["last_reaction"] = reaction
	monster.favorite_food_memory[food.id] = entry

func _build_feed_message(monster: MonsterInstance, food: FoodData, reaction: String, gained: Dictionary, unlocked: Array[String], healed: int) -> String:
	var reaction_text := "ate"
	if reaction == "favorite": reaction_text = "loved"
	elif reaction == "disliked": reaction_text = "reluctantly ate"
	var parts: Array[String] = []
	for key in gained.keys():
		parts.append("%s +%d" % [str(key).capitalize(), int(gained[key])])
	var message := "%s %s %s." % [monster.get_display_name(), reaction_text, food.display_name]
	if not parts.is_empty(): message += " Development: %s." % ", ".join(parts)
	if healed > 0: message += " Recovered %d HP." % healed
	if not unlocked.is_empty():
		var names: Array[String] = []
		for move_id in unlocked:
			var move := DataRegistry.get_move(move_id)
			names.append(move.display_name if move else move_id)
		message += " New move unlocked: %s!" % ", ".join(names)
	return message

func _all_monsters() -> Array[MonsterInstance]:
	var result: Array[MonsterInstance] = []
	result.append_array(MonsterManager.get_party())
	result.append_array(MonsterManager.get_farm_storage())
	return result
