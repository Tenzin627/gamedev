extends Node

signal dialogue_opened(dialogue_id: String)
signal dialogue_closed(dialogue_id: String)

var _screen: Control = null
var _dialogue: DialogueData = null
var _dialogue_id: String = ""
var _current_node_id: String = ""
var _context: Dictionary = {}
var _previous_mode: int = 0
var _is_active: bool = false

func register_screen(screen: Control) -> void:
	_screen = screen
	if _screen != null and _screen.has_method("bind_manager"):
		_screen.bind_manager(self)

func is_active() -> bool:
	return _is_active

func start_dialogue(dialogue_id: String, context: Dictionary = {}) -> bool:
	if _is_active:
		close_dialogue()
	var definition := DataRegistry.get_dialogue(dialogue_id)
	if definition == null:
		EventBus.interaction_message.emit("Missing dialogue: %s" % dialogue_id)
		return false
	if _screen == null:
		EventBus.interaction_message.emit("Dialogue UI is not registered.")
		return false

	_dialogue = definition
	_dialogue_id = dialogue_id
	_context = context.duplicate(true)
	_previous_mode = int(Game.mode)
	Game.mode = Game.GameMode.DIALOGUE
	_is_active = true
	_current_node_id = _resolve_start_node(definition)
	if _current_node_id.is_empty():
		close_dialogue()
		return false

	_screen.visible = true
	dialogue_opened.emit(dialogue_id)
	EventBus.dialogue_started.emit(dialogue_id, str(_context.get("npc_id", "")))
	_render_current_node()
	return true

func advance() -> void:
	if not _is_active or _dialogue == null:
		return
	var node_data := _dialogue.get_node_data(_current_node_id)
	if node_data.is_empty():
		close_dialogue()
		return
	var choices := _get_available_choices(node_data)
	if not choices.is_empty():
		return
	var next_id := str(node_data.get("next", ""))
	if next_id.is_empty() or next_id == "end":
		close_dialogue()
		return
	_go_to_node(next_id)

func choose(choice_index: int) -> void:
	if not _is_active or _dialogue == null:
		return
	var node_data := _dialogue.get_node_data(_current_node_id)
	var choices := _get_available_choices(node_data)
	if choice_index < 0 or choice_index >= choices.size():
		return
	var choice: Dictionary = choices[choice_index]
	_apply_actions(choice.get("actions", []) as Array)
	EventBus.dialogue_choice_selected.emit(_dialogue_id, _current_node_id, str(choice.get("text", "")))
	var next_id := str(choice.get("next", ""))
	if next_id.is_empty() or next_id == "end":
		close_dialogue()
	else:
		_go_to_node(next_id)

func close_dialogue() -> void:
	if not _is_active:
		return
	var closing_id := _dialogue_id
	_is_active = false
	_dialogue = null
	_dialogue_id = ""
	_current_node_id = ""
	_context.clear()
	if _screen != null:
		_screen.visible = false
	match _previous_mode:
		Game.GameMode.BOOT: Game.mode = Game.GameMode.BOOT
		Game.GameMode.TITLE: Game.mode = Game.GameMode.TITLE
		Game.GameMode.BATTLE: Game.mode = Game.GameMode.BATTLE
		_: Game.mode = Game.GameMode.WORLD
	dialogue_closed.emit(closing_id)
	EventBus.dialogue_finished.emit(closing_id)

func get_relationship(npc_id: String) -> int:
	var relationships := _get_relationships()
	return int(relationships.get(npc_id, 0))

func add_relationship(npc_id: String, amount: int) -> int:
	if npc_id.is_empty() or amount == 0:
		return get_relationship(npc_id)
	var relationships := _get_relationships()
	var new_value := clampi(int(relationships.get(npc_id, 0)) + amount, -100, 100)
	relationships[npc_id] = new_value
	GameState.player_profile["relationships"] = relationships
	EventBus.relationship_changed.emit(npc_id, new_value)
	return new_value

func has_profile_tag(tag_id: String) -> bool:
	return ProfileTagManager.has_tag(tag_id)

func add_profile_tag(tag_id: String) -> void:
	ProfileTagManager.award_tag(tag_id, "dialogue", {"dialogue_id": _dialogue_id, "npc_id": str(_context.get("npc_id", ""))})

func remove_profile_tag(tag_id: String) -> void:
	ProfileTagManager.revoke_tag(tag_id)

func conditions_met(conditions: Array) -> bool:
	for condition_value in conditions:
		if not condition_value is Dictionary:
			continue
		if not _condition_met(condition_value as Dictionary):
			return false
	return true

func _go_to_node(node_id: String) -> void:
	var node_data := _dialogue.get_node_data(node_id)
	if node_data.is_empty():
		close_dialogue()
		return
	if not conditions_met(node_data.get("conditions", []) as Array):
		var fallback := str(node_data.get("fallback", ""))
		if fallback.is_empty() or fallback == "end":
			close_dialogue()
		else:
			_go_to_node(fallback)
		return
	_current_node_id = node_id
	_render_current_node()

func _render_current_node() -> void:
	if _dialogue == null or _screen == null:
		return
	var node_data := _dialogue.get_node_data(_current_node_id)
	if node_data.is_empty():
		close_dialogue()
		return
	_apply_actions(node_data.get("actions", []) as Array)
	var speaker := str(node_data.get("speaker", ""))
	if speaker.is_empty():
		speaker = str(_context.get("speaker_name", ""))
	if speaker.is_empty():
		var npc_id := str(_context.get("npc_id", ""))
		var npc_data := DataRegistry.get_npc(npc_id)
		if npc_data != null:
			speaker = npc_data.display_name
	if speaker.is_empty():
		speaker = "..."
	var text := str(node_data.get("text", ""))
	var choices := _get_available_choices(node_data)
	if _screen.has_method("show_dialogue_node"):
		_screen.show_dialogue_node(speaker, text, choices)
	EventBus.dialogue_line_shown.emit(_dialogue_id, _current_node_id, speaker, text)

func _resolve_start_node(dialogue: DialogueData) -> String:
	var best_id := ""
	var best_priority := -2147483648
	for rule_value in dialogue.start_rules:
		var rule: Dictionary = rule_value
		if conditions_met(rule.get("conditions", []) as Array):
			var priority := int(rule.get("priority", 0))
			if priority > best_priority:
				best_priority = priority
				best_id = str(rule.get("node_id", ""))
	return best_id if not best_id.is_empty() else dialogue.start_node_id

func _get_available_choices(node_data: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var raw_choices: Array = node_data.get("choices", []) as Array
	if not raw_choices is Array:
		return result
	for choice_value in raw_choices:
		if not choice_value is Dictionary:
			continue
		var choice: Dictionary = choice_value
		if conditions_met(choice.get("conditions", []) as Array):
			result.append(choice)
	return result

func _condition_met(condition: Dictionary) -> bool:
	var condition_type := str(condition.get("type", ""))
	match condition_type:
		"profile_tag":
			return has_profile_tag(str(condition.get("tag", "")))
		"not_profile_tag":
			return not has_profile_tag(str(condition.get("tag", "")))
		"profile_tag_all":
			var required_all: Array[String] = []
			var raw_all: Variant = condition.get("tags", [])
			if raw_all is Array:
				for tag_value in raw_all:
					required_all.append(str(tag_value))
			return ProfileTagManager.meets_all(required_all)
		"profile_tag_any":
			var required_any: Array[String] = []
			var raw_any: Variant = condition.get("tags", [])
			if raw_any is Array:
				for tag_value in raw_any:
					required_any.append(str(tag_value))
			return ProfileTagManager.meets_any(required_any)
		"world_state":
			var state_id := str(condition.get("id", ""))
			return WorldStateManager.get_value(state_id, null) == condition.get("equals", true)
		"relationship_min":
			return get_relationship(_resolve_npc_id(condition)) >= int(condition.get("value", 0))
		"relationship_max":
			return get_relationship(_resolve_npc_id(condition)) <= int(condition.get("value", 0))
		"quest_state":
			return QuestManager.get_state_id(str(condition.get("id", ""))) == str(condition.get("equals", ""))
		"time_period":
			return TimeWeatherManager.get_time_period() == str(condition.get("equals", ""))
		"weather":
			return TimeWeatherManager.get_weather_id() == str(condition.get("equals", ""))
		"season":
			return TimeWeatherManager.get_season_id() == str(condition.get("equals", ""))
		"item_min":
			return InventoryManager.get_count(str(condition.get("id", ""))) >= int(condition.get("amount", 1))
		"always", "":
			return true
		_:
			return false

func _apply_actions(actions: Array) -> void:
	for action_value in actions:
		if not action_value is Dictionary:
			continue
		var action: Dictionary = action_value
		match str(action.get("type", "")):
			"relationship_add":
				add_relationship(_resolve_npc_id(action), int(action.get("amount", 0)))
			"add_profile_tag":
				add_profile_tag(str(action.get("tag", "")))
			"remove_profile_tag":
				remove_profile_tag(str(action.get("tag", "")))
			"set_world_state":
				var state_id := str(action.get("id", ""))
				var value: Variant = action.get("value", true)
				if not state_id.is_empty():
					WorldStateManager.set_value(state_id, value, "dialogue")
			"interaction_message":
				EventBus.interaction_message.emit(str(action.get("text", "")))
			"start_quest":
				QuestManager.start_quest(str(action.get("id", "")))
			"complete_quest":
				QuestManager.complete_quest(str(action.get("id", "")), str(action.get("outcome", "default")))
			"add_item":
				InventoryManager.add_item(str(action.get("id", "")), maxi(1, int(action.get("amount", 1))))
			"add_currency":
				InventoryManager.add_currency(maxi(0, int(action.get("amount", 0))))

func _resolve_npc_id(data: Dictionary) -> String:
	var explicit := str(data.get("npc_id", ""))
	return explicit if not explicit.is_empty() else str(_context.get("npc_id", ""))

func _get_relationships() -> Dictionary:
	var value: Variant = GameState.player_profile.get("relationships", {})
	return value.duplicate(true) if value is Dictionary else {}

func _get_profile_tags() -> Array[String]:
	var result: Array[String] = []
	var value: Variant = GameState.player_profile.get("profile_tags", [])
	if value is Array:
		for item in value:
			result.append(str(item))
	return result
