extends Node

const NEAR_TIE_DELTA := 0

func get_evolution_status(monster: MonsterInstance) -> Dictionary:
	var result := {
		"can_evolve": false,
		"requires_choice": false,
		"reason": "no_evolution",
		"message": "This monster has no available evolution.",
		"candidates": [],
		"qualified": []
	}
	if monster == null:
		result.reason = "missing_monster"
		result.message = "Monster not found."
		return result
	var species := monster.get_species()
	if species == null or species.evolution_rules.is_empty():
		return result

	var qualified: Array[Dictionary] = []
	var candidates: Array[Dictionary] = []
	for raw_rule in species.evolution_rules:
		var rule: Dictionary = raw_rule
		var target_id := str(rule.get("target", ""))
		var tendency := str(rule.get("tendency", ""))
		var threshold := maxi(0, int(rule.get("threshold", 0)))
		var min_level := maxi(1, int(rule.get("min_level", 1)))
		var current := maxi(0, int(monster.development.get(tendency, 0)))
		var target := DataRegistry.get_monster(target_id)
		if target == null:
			continue
		var entry := {
			"target_id": target_id,
			"target_name": target.display_name,
			"tendency": tendency,
			"threshold": threshold,
			"current": current,
			"min_level": min_level,
			"level_ready": monster.level >= min_level,
			"development_ready": current >= threshold
		}
		candidates.append(entry)
		if bool(entry.get("level_ready", false)) and bool(entry.get("development_ready", false)):
			qualified.append(entry)

	result.candidates = candidates
	result.qualified = qualified
	if qualified.is_empty():
		result.reason = "requirements"
		result.message = "Evolution requirements are not met yet."
		return result

	if qualified.size() == 1:
		result.can_evolve = true
		result.reason = "ready"
		result.message = "Evolution is ready."
		return result

	qualified.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a.get("current", 0)) > int(b.get("current", 0)))
	var first_value := int(qualified[0].get("current", 0))
	var second_value := int(qualified[1].get("current", 0))
	result.can_evolve = true
	if abs(first_value - second_value) <= NEAR_TIE_DELTA:
		result.can_evolve = false
		result.requires_choice = false
		result.reason = "tie"
		result.message = "The top Development Tendencies are tied. Feed the monster until one path becomes dominant."
	else:
		result.reason = "dominant"
		result.message = "%s is the dominant evolution path." % str(qualified[0].tendency).capitalize()
	return result

func get_resolved_target(monster: MonsterInstance) -> String:
	var status := get_evolution_status(monster)
	if not bool(status.get("can_evolve", false)) or bool(status.get("requires_choice", false)):
		return ""
	var qualified: Array = status.get("qualified", [])
	if qualified.is_empty():
		return ""
	if qualified.size() == 1:
		return str(qualified[0].get("target_id", ""))
	qualified.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a.get("current", 0)) > int(b.get("current", 0)))
	return str(qualified[0].get("target_id", ""))

func evolve_monster(instance_id: String, chosen_target_id: String = "") -> Dictionary:
	var result := {
		"success": false,
		"reason": "invalid",
		"message": "Evolution could not begin.",
		"old_species_id": "",
		"new_species_id": "",
		"old_name": "",
		"new_name": ""
	}
	var monster := MonsterManager.find_monster(instance_id)
	if monster == null:
		result.reason = "missing_monster"
		result.message = "Monster not found."
		return result
	var status := get_evolution_status(monster)
	if not bool(status.get("can_evolve", false)):
		result.reason = str(status.get("reason", "requirements"))
		result.message = str(status.get("message", "Evolution requirements are not met."))
		return result

	var target_id := chosen_target_id
	if target_id.is_empty():
		target_id = get_resolved_target(monster)
	if target_id.is_empty():
		result.reason = "choice_required"
		result.message = "Choose an evolution path."
		return result

	var matching_rule: Dictionary = {}
	for entry in status.get("qualified", []):
		if str(entry.get("target_id", "")) == target_id:
			matching_rule = entry
			break
	if matching_rule.is_empty():
		result.reason = "invalid_target"
		result.message = "That evolution path is not currently available."
		return result

	var target_species := DataRegistry.get_monster(target_id)
	var old_species := monster.get_species()
	if target_species == null or old_species == null:
		result.reason = "missing_data"
		result.message = "Evolution data is missing."
		return result

	var old_id := monster.species_id
	var old_name := old_species.display_name
	var old_max_hp := maxi(1, monster.get_max_hp())
	var was_fainted := monster.current_hp <= 0
	var hp_ratio := clampf(float(monster.current_hp) / float(old_max_hp), 0.0, 1.0)

	monster.evolution_history.append({
		"from_species_id": old_id,
		"to_species_id": target_id,
		"level": monster.level,
		"day": int(GameState.game_time.get("day", 1)),
		"season": str(GameState.game_time.get("season", "spring")),
		"tendency": str(matching_rule.get("tendency", "")),
		"development": monster.development.duplicate(true)
	})
	monster.species_id = target_id
	_unlock_target_starter_moves(monster, target_species)
	DevelopmentManager.check_move_unlocks(monster)
	if was_fainted:
		monster.current_hp = 0
	else:
		monster.current_hp = clampi(int(round(float(monster.get_max_hp()) * hp_ratio)), 1, monster.get_max_hp())

	_update_journal(target_id)
	MonsterManager.sync_to_game_state()
	EventBus.monster_evolved.emit(monster.instance_id, target_id)
	EventBus.monster_moves_changed.emit(monster.instance_id)
	EventBus.monster_hp_changed.emit(monster.instance_id, monster.current_hp, monster.get_max_hp())

	result.success = true
	result.reason = "evolved"
	result.old_species_id = old_id
	result.new_species_id = target_id
	result.old_name = old_name
	result.new_name = target_species.display_name
	result.message = "%s evolved into %s!" % [old_name, target_species.display_name]
	return result

func _unlock_target_starter_moves(monster: MonsterInstance, species: MonsterSpeciesData) -> void:
	var gated: Dictionary = {}
	for rule in species.move_unlock_rules:
		gated[str(rule.get("move_id", ""))] = true
	for move_id in species.move_ids:
		if not gated.has(move_id):
			monster.unlock_move(move_id)
	while monster.equipped_move_ids.size() < MonsterInstance.MAX_MOVE_SLOTS:
		var added := false
		for move_id in monster.unlocked_move_ids:
			if move_id not in monster.equipped_move_ids:
				monster.equipped_move_ids.append(move_id)
				added = true
				break
		if not added:
			break

func _update_journal(species_id: String) -> void:
	var seen: Dictionary = GameState.player_profile.get("seen_species", {})
	seen[species_id] = true
	GameState.player_profile["seen_species"] = seen
	var owned: Dictionary = GameState.player_profile.get("owned_species", {})
	owned[species_id] = true
	GameState.player_profile["owned_species"] = owned
	EventBus.journal_monster_updated.emit(species_id)
