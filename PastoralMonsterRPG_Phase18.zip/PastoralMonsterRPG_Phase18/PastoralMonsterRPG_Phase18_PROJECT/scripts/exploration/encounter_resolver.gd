extends RefCounted
class_name EncounterResolver

static func choose_encounter(encounter_table_id: String, context: Dictionary = {}) -> Dictionary:
	var table = DataRegistry.get_encounter(encounter_table_id)
	if table == null:
		return {}
	if not _conditions_match(table.conditions, context):
		return {}

	var eligible: Array[Dictionary] = []
	var total_weight := 0.0
	for raw_entry in table.entries:
		var entry: Dictionary = raw_entry
		if not _conditions_match(entry.get("conditions", {}), context):
			continue
		var species_id := String(entry.get("monster_id", ""))
		if DataRegistry.get_monster(species_id) == null:
			continue
		var weight := maxf(float(entry.get("weight", 1.0)), 0.0)
		if weight <= 0.0:
			continue
		eligible.append(entry)
		total_weight += weight

	if eligible.is_empty() or total_weight <= 0.0:
		return {}

	var roll := randf() * total_weight
	var running := 0.0
	for entry in eligible:
		running += float(entry.get("weight", 1.0))
		if roll <= running:
			return _resolved_entry(entry)
	return _resolved_entry(eligible.back())

static func build_world_context() -> Dictionary:
	var context := TimeWeatherManager.get_context()
	context["map_id"] = GameState.current_map_id
	context["world_state"] = WorldStateManager.get_all_states()
	return context

static func _resolved_entry(entry: Dictionary) -> Dictionary:
	var min_level := maxi(int(entry.get("min_level", 1)), 1)
	var max_level := maxi(int(entry.get("max_level", min_level)), min_level)
	return {
		"monster_id": String(entry.get("monster_id", "")),
		"level": randi_range(min_level, max_level),
		"entry": entry.duplicate(true)
	}

static func _conditions_match(raw_conditions: Variant, context: Dictionary) -> bool:
	if not raw_conditions is Dictionary:
		return true
	var conditions: Dictionary = raw_conditions
	for key in conditions.keys():
		var expected = conditions[key]
		if str(key) == "world_state":
			if expected is Dictionary and not WorldStateManager.requirements_met(expected):
				return false
			continue
		if not context.has(key):
			continue
		var actual = context[key]
		if expected is Array:
			if not expected.has(actual):
				return false
		elif actual != expected:
			return false
	return true
