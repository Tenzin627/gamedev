extends Node2D
class_name EncounterSpawnZone

const EncounterResolverClass = preload("res://scripts/exploration/encounter_resolver.gd")
const WILD_MONSTER_SCENE := preload("res://scenes/world/components/wild_monster_actor.tscn")

@export var zone_id: String = "zone.default"
@export var encounter_table_id: String = "encounter.home_wilderness"
@export_range(0, 12, 1) var max_active_monsters: int = 3
@export var spawn_radius: float = 280.0
@export var monster_wander_radius: float = 110.0
@export var respawn_seconds: float = 8.0
@export var initial_spawn_delay: float = 0.15

var _respawn_queue := 0
var _respawn_clock := 0.0

func _ready() -> void:
	EventBus.weather_changed.connect(_on_context_changed)
	EventBus.time_period_changed.connect(_on_context_changed)
	EventBus.season_changed.connect(_on_season_changed)
	await get_tree().create_timer(initial_spawn_delay).timeout
	_fill_initial_population()

func _process(delta: float) -> void:
	if _respawn_queue <= 0:
		return
	_respawn_clock -= delta
	if _respawn_clock <= 0.0:
		_respawn_queue -= 1
		_spawn_one()
		_respawn_clock = respawn_seconds

func _fill_initial_population() -> void:
	for index in range(max_active_monsters):
		_spawn_one()

func _spawn_one() -> void:
	if _active_count() >= max_active_monsters:
		return
	var resolved := EncounterResolverClass.choose_encounter(encounter_table_id, EncounterResolverClass.build_world_context())
	if resolved.is_empty():
		return
	var actor := WILD_MONSTER_SCENE.instantiate() as WildMonsterActor
	if actor == null:
		return
	add_child(actor)
	var offset := Vector2.from_angle(randf() * TAU) * randf_range(30.0, spawn_radius)
	actor.global_position = global_position + offset
	actor.configure(String(resolved.get("monster_id", "monster.spriggle")), int(resolved.get("level", 1)), actor.global_position, monster_wander_radius)
	actor.encounter_consumed.connect(_on_actor_consumed)
	EventBus.wild_monster_spawned.emit(zone_id, actor.species_id, actor.level)

func _on_actor_consumed(_actor: WildMonsterActor) -> void:
	_respawn_queue += 1
	if _respawn_clock <= 0.0:
		_respawn_clock = respawn_seconds

func _active_count() -> int:
	var count := 0
	for child in get_children():
		if child is WildMonsterActor and not child.is_queued_for_deletion():
			count += 1
	return count

func _on_context_changed(_value: String) -> void:
	_fill_missing_population()

func _on_season_changed(_season_id: String, _season_day: int) -> void:
	_fill_missing_population()

func _fill_missing_population() -> void:
	var missing := maxi(0, max_active_monsters - _active_count())
	for _index in range(missing):
		_spawn_one()
