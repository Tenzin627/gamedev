extends Area2D
class_name EncounterZone

@export var encounter_table_id: String = "encounter.home_wilderness"
@export var zone_id: String = "zone.default"

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body: Node) -> void:
	if body is PlayerController:
		EventBus.encounter_zone_entered.emit(zone_id, encounter_table_id)

func _on_body_exited(body: Node) -> void:
	if body is PlayerController:
		EventBus.encounter_zone_exited.emit(zone_id)
