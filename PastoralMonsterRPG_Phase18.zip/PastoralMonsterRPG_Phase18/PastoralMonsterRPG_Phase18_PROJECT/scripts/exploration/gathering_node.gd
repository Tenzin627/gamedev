extends Interactable
class_name GatheringNode

@export var resource_id: String = "item.sunroot"
@export var amount: int = 1
@export var one_shot: bool = false

var _gathered := false

func can_interact(_actor: Node) -> bool:
	return not _gathered and enabled

func interact(_actor: Node) -> void:
	if not can_interact(_actor):
		return
	var item := DataRegistry.get_item(resource_id)
	if item == null:
		EventBus.interaction_message.emit("Missing item data: %s" % resource_id)
		return
	var accepted := InventoryManager.add_item(resource_id, amount)
	if accepted <= 0:
		EventBus.interaction_message.emit("Your %s stack is full." % item.display_name)
		return
	EventBus.resource_gathered.emit(resource_id, accepted)
	EventBus.interaction_message.emit("Gathered %d × %s." % [accepted, item.display_name])
	if one_shot:
		_gathered = true
		visible = false
		monitorable = false
