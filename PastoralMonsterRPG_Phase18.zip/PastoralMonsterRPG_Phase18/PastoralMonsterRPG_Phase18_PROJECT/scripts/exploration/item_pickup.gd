extends Interactable
class_name ItemPickup

@export var item_id: String = "item.herbal_wrap"
@export var amount: int = 1
@export var remove_when_collected: bool = true

func _ready() -> void:
	_refresh_prompt()

func interact(_actor: Node) -> void:
	var item := DataRegistry.get_item(item_id)
	if item == null:
		EventBus.interaction_message.emit("Missing item data: %s" % item_id)
		return
	var accepted := InventoryManager.add_item(item_id, amount)
	if accepted <= 0:
		EventBus.interaction_message.emit("Your %s stack is full." % item.display_name)
		return
	EventBus.interaction_message.emit("Picked up %d × %s." % [accepted, item.display_name])
	if remove_when_collected and accepted == amount:
		queue_free()

func _refresh_prompt() -> void:
	var item := DataRegistry.get_item(item_id)
	interaction_prompt = "Pick up %s" % item.display_name if item else "Pick up item"
