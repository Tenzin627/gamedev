extends Interactable
class_name Shopkeeper

@export var shop_name: String = "Village Supply"
@export var stock_ids: Array[String] = ["item.gya_basic", "item.herbal_wrap", "item.sunroot_seed"]
@export_range(0, 23, 1) var open_hour: int = 8
@export_range(1, 24, 1) var close_hour: int = 20

func _ready() -> void:
	EventBus.hour_changed.connect(_on_hour_changed)
	_refresh_prompt()

func interact(_actor: Node) -> void:
	if not _is_open():
		EventBus.interaction_message.emit("%s is closed. Hours: %02d:00–%02d:00." % [shop_name, open_hour, close_hour])
		return
	EventBus.shop_requested.emit(shop_name, stock_ids)

func _is_open() -> bool:
	var hour := TimeWeatherManager.get_hour()
	return hour >= open_hour and hour < close_hour

func _refresh_prompt() -> void:
	interaction_prompt = "Shop" if _is_open() else "Shop (Closed)"

func _on_hour_changed(_hour: int) -> void:
	_refresh_prompt()
