extends Interactable

@export var starts_open: bool = false
var is_open: bool = false

@onready var blocker: CollisionShape2D = get_parent().get_node("Blocker/CollisionShape2D")
@onready var door_visual: Polygon2D = get_parent().get_node("DoorVisual")

func _ready() -> void:
	is_open = starts_open
	_apply_state()

func interact(interactor: Node) -> void:
	if not can_interact(interactor):
		return
	interaction_started.emit(interactor)
	is_open = not is_open
	_apply_state()
	EventBus.interaction_message.emit("Door opened." if is_open else "Door closed.")
	interaction_finished.emit(interactor)

func _apply_state() -> void:
	blocker.set_deferred("disabled", is_open)
	door_visual.rotation = -1.15 if is_open else 0.0
	interaction_prompt = "Close Door" if is_open else "Open Door"
