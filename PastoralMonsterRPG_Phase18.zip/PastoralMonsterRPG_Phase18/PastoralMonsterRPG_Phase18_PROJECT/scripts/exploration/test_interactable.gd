extends Interactable

@export_multiline var response_text: String = "Interaction works."
@export var one_shot: bool = false

func interact(interactor: Node) -> void:
	if not can_interact(interactor):
		return
	interaction_started.emit(interactor)
	EventBus.interaction_message.emit(response_text)
	if one_shot:
		enabled = false
	interaction_finished.emit(interactor)
