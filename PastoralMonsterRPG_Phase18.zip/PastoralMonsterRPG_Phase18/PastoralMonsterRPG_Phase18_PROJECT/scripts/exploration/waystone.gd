extends Interactable
class_name Waystone

@export var waystone_id: String = "waystone.home_village"

func can_interact(_actor: Node) -> bool:
	return true

func interact(_actor: Node) -> void:
	GameState.discovered_waystones[waystone_id] = true
	EventBus.waystone_discovered.emit(waystone_id)
	EventBus.interaction_message.emit("Waystone discovered: %s" % waystone_id)
