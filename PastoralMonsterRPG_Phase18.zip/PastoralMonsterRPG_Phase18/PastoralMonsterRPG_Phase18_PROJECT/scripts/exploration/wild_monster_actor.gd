extends CharacterBody2D
class_name WildMonsterActor

signal encounter_consumed(actor: WildMonsterActor)

@export var species_id: String = "monster.spriggle"
@export_range(1, 100, 1) var level: int = 3
@export var wander_radius: float = 150.0
@export var move_speed: float = 42.0
@export var idle_min_seconds: float = 0.7
@export var idle_max_seconds: float = 1.8

var _home_position: Vector2
var _target_position: Vector2
var _state_time := 0.0
var _moving := false
var _battle_started := false

@onready var body_visual: Polygon2D = $Visual/Body
@onready var label: Label = $Visual/Label
@onready var contact_area: Area2D = $ContactArea

func _ready() -> void:
	_home_position = global_position
	_target_position = global_position
	label.text = _display_name()
	contact_area.body_entered.connect(_on_body_entered)
	_choose_idle()

func configure(new_species_id: String, new_level: int, center: Vector2, radius: float) -> void:
	species_id = new_species_id
	level = new_level
	_home_position = center
	wander_radius = radius
	if is_node_ready():
		label.text = _display_name()

func _physics_process(delta: float) -> void:
	if _battle_started:
		velocity = Vector2.ZERO
		return
	_state_time -= delta
	if _moving:
		var to_target := _target_position - global_position
		if to_target.length() < 8.0 or _state_time <= 0.0:
			_choose_idle()
		else:
			velocity = to_target.normalized() * move_speed
			move_and_slide()
	else:
		velocity = Vector2.ZERO
		if _state_time <= 0.0:
			_choose_wander_target()

func _choose_idle() -> void:
	_moving = false
	_state_time = randf_range(idle_min_seconds, idle_max_seconds)

func _choose_wander_target() -> void:
	_moving = true
	var angle := randf() * TAU
	var distance := randf_range(wander_radius * 0.25, wander_radius)
	_target_position = _home_position + Vector2.from_angle(angle) * distance
	_state_time = maxf(distance / maxf(move_speed, 1.0) * 1.6, 1.0)

func _on_body_entered(body: Node) -> void:
	if _battle_started or not body is PlayerController or BattleManager.is_battle_active():
		return
	_battle_started = BattleManager.start_wild_battle(species_id, level)
	if not _battle_started:
		return
	visible = false
	contact_area.set_deferred("monitoring", false)
	EventBus.battle_finished.connect(_on_battle_finished, CONNECT_ONE_SHOT)

func _on_battle_finished(result: Dictionary) -> void:
	var outcome := String(result.get("outcome", "unknown"))
	if outcome == "victory" or outcome == "captured":
		encounter_consumed.emit(self)
		queue_free()
		return
	_battle_started = false
	visible = true
	contact_area.set_deferred("monitoring", true)
	_choose_idle()

func _display_name() -> String:
	var species = DataRegistry.get_monster(species_id)
	if species != null:
		return "%s  Lv.%d" % [species.display_name, level]
	return "%s  Lv.%d" % [species_id, level]
