extends Interactable
class_name DualGridFarm

@export var tile_size: int = 64
@export var field_width: int = 6
@export var field_height: int = 4
@export var placeholder_texture: Texture2D = preload("res://assets/tilesets/placeholder/dual_grid_soil_placeholder.png")

@onready var logical_grid: TileMapLayer = $LogicalGrid
@onready var display_grid: TileMapLayer = $DisplayGrid
@onready var crop_visuals: Node2D = $CropVisuals
@onready var highlight: Polygon2D = $TargetHighlight

var _target_cell := Vector2i.ZERO
var _player: Node2D = null
var _crop_nodes: Dictionary = {}

func _ready() -> void:
	add_to_group("farm_grid")
	interaction_prompt = "Farm"
	_build_runtime_tileset()
	EventBus.farm_plot_changed.connect(_on_plot_changed)
	EventBus.farm_expanded.connect(_refresh_all)
	EventBus.farm_tool_changed.connect(_on_tool_changed)
	_refresh_all()

func _process(_delta: float) -> void:
	FarmManager.update_all_plots()
	if _player != null and is_instance_valid(_player):
		_target_cell = _cell_from_world_position(_player.global_position)
		_update_highlight()
		_refresh_crop_visuals()

func can_interact(interactor: Node) -> bool:
	return enabled and interactor is Node2D and FarmManager.is_cell_valid(_cell_from_world_position((interactor as Node2D).global_position))

func interact(interactor: Node) -> void:
	if not interactor is Node2D:
		return
	_player = interactor as Node2D
	_target_cell = _cell_from_world_position(_player.global_position)
	var result := FarmManager.interact_with_cell(_target_cell)
	EventBus.interaction_message.emit(str(result.get("message", "")))
	_refresh_all()

func _on_tool_changed(_tool_id: String, _crop_id: String) -> void:
	_update_highlight()

func _on_plot_changed(_cell_key: String) -> void:
	_refresh_all()

func _refresh_all() -> void:
	_refresh_logical_grid()
	_refresh_dual_grid()
	_refresh_crop_visuals()
	_update_highlight()

func _refresh_logical_grid() -> void:
	logical_grid.clear()
	for y in range(field_height):
		for x in range(field_width):
			var cell := Vector2i(x, y)
			if FarmManager.is_cell_unlocked(cell) and FarmManager.is_tilled(cell):
				logical_grid.set_cell(cell, 0, Vector2i(3, 3))

func _refresh_dual_grid() -> void:
	display_grid.clear()
	for y in range(field_height + 1):
		for x in range(field_width + 1):
			var dual_cell := Vector2i(x, y)
			var mask := _dual_mask(dual_cell)
			if mask == 0:
				continue
			var atlas := Vector2i(mask % 4, mask / 4)
			display_grid.set_cell(dual_cell, 0, atlas)

func _dual_mask(dual_cell: Vector2i) -> int:
	var mask := 0
	if _soil_at(dual_cell + Vector2i(-1, -1)):
		mask |= 1
	if _soil_at(dual_cell + Vector2i(0, -1)):
		mask |= 2
	if _soil_at(dual_cell + Vector2i(-1, 0)):
		mask |= 4
	if _soil_at(dual_cell):
		mask |= 8
	return mask

func _soil_at(cell: Vector2i) -> bool:
	return FarmManager.is_cell_unlocked(cell) and FarmManager.is_tilled(cell)

func _cell_from_world_position(world_pos: Vector2) -> Vector2i:
	var local := to_local(world_pos)
	return Vector2i(floori(local.x / float(tile_size)), floori(local.y / float(tile_size)))

func _cell_center(cell: Vector2i) -> Vector2:
	return Vector2((cell.x + 0.5) * tile_size, (cell.y + 0.5) * tile_size)

func _update_highlight() -> void:
	if not FarmManager.is_cell_valid(_target_cell):
		highlight.visible = false
		return
	highlight.visible = true
	highlight.position = _cell_center(_target_cell)
	var unlocked := FarmManager.is_cell_unlocked(_target_cell)
	highlight.color = Color(1.0, 0.92, 0.45, 0.22) if unlocked else Color(0.8, 0.25, 0.25, 0.25)

func _refresh_crop_visuals() -> void:
	for y in range(field_height):
		for x in range(field_width):
			var cell := Vector2i(x, y)
			var key := "%d,%d" % [x, y]
			var plot := FarmManager.get_plot(cell)
			var crop_id := str(plot.get("crop_id", ""))
			if crop_id.is_empty():
				if _crop_nodes.has(key):
					(_crop_nodes[key] as Node).queue_free()
					_crop_nodes.erase(key)
				continue
			var visual: Node2D = _crop_nodes.get(key) as Node2D
			if visual == null:
				visual = Node2D.new()
				visual.set_script(preload("res://scripts/farm/placeholder_crop_visual.gd"))
				crop_visuals.add_child(visual)
				_crop_nodes[key] = visual
			visual.position = _cell_center(cell)
			visual.call("configure", crop_id, FarmManager.get_growth_stage(cell), bool(plot.get("ready", false)))

func _build_runtime_tileset() -> void:
	if placeholder_texture == null:
		return
	var tile_set := TileSet.new()
	tile_set.tile_size = Vector2i(tile_size, tile_size)
	var atlas_source := TileSetAtlasSource.new()
	atlas_source.texture = placeholder_texture
	atlas_source.texture_region_size = Vector2i(tile_size, tile_size)
	for y in range(4):
		for x in range(4):
			atlas_source.create_tile(Vector2i(x, y))
	tile_set.add_source(atlas_source, 0)
	logical_grid.tile_set = tile_set
	display_grid.tile_set = tile_set
	display_grid.position = Vector2(-tile_size * 0.5, -tile_size * 0.5)
