extends Interactable

func _ready() -> void:
	interaction_prompt = "Expand Farm"
	if not FarmManager.can_expand():
		visible = false
		monitorable = false

func can_interact(_interactor: Node) -> bool:
	return enabled and FarmManager.can_expand()

func interact(_interactor: Node) -> void:
	var result := FarmManager.expand_farm()
	EventBus.interaction_message.emit(str(result.get("message", "")))
	if bool(result.get("success", false)):
		visible = false
		monitorable = false
