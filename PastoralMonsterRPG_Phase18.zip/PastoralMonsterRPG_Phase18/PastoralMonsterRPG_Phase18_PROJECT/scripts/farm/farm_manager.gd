extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

const FIELD_WIDTH := 6
const FIELD_HEIGHT := 4
const STARTER_WIDTH := 4
const STARTER_HEIGHT := 3
const EXPANSION_COST := 150

var current_tool: StringName = &"hoe"
var selected_crop_id: String = "crop.sunroot"

func _ready() -> void:
	ensure_farm_state()
	EventBus.game_loaded.connect(ensure_farm_state)
	EventBus.game_started.connect(ensure_farm_state)
	EventBus.game_minutes_advanced.connect(_on_game_minutes_advanced)
	EventBus.weather_changed.connect(_on_weather_changed)

func ensure_farm_state() -> void:
	if not GameState.farm_state.has("plots"):
		GameState.farm_state["plots"] = {}
	if not GameState.farm_state.has("expanded"):
		GameState.farm_state["expanded"] = false
	if not GameState.farm_state.has("processing"):
		GameState.farm_state["processing"] = {}
	_migrate_phase9_timers()

func set_tool(tool_id: StringName) -> void:
	if tool_id not in [&"hoe", &"plant", &"water", &"harvest"]:
		return
	current_tool = tool_id
	EventBus.farm_tool_changed.emit(str(current_tool), selected_crop_id)

func set_selected_crop(crop_id: String) -> void:
	if DataRegistry.get_crop(crop_id) == null:
		return
	selected_crop_id = crop_id
	EventBus.farm_tool_changed.emit(str(current_tool), selected_crop_id)

func get_available_crop_ids() -> Array[String]:
	var result: Array[String] = []
	for definition in DataRegistry.get_category("crops"):
		if definition is CropData:
			result.append(definition.id)
	result.sort()
	return result

func is_cell_valid(cell: Vector2i) -> bool:
	return cell.x >= 0 and cell.y >= 0 and cell.x < FIELD_WIDTH and cell.y < FIELD_HEIGHT

func is_cell_unlocked(cell: Vector2i) -> bool:
	if not is_cell_valid(cell):
		return false
	if bool(GameState.farm_state.get("expanded", false)):
		return true
	return cell.x < STARTER_WIDTH and cell.y < STARTER_HEIGHT

func get_plot(cell: Vector2i) -> Dictionary:
	ensure_farm_state()
	var plots: Dictionary = GameState.farm_state["plots"]
	return (plots.get(_cell_key(cell), {}) as Dictionary).duplicate(true)

func is_tilled(cell: Vector2i) -> bool:
	return bool(get_plot(cell).get("tilled", false))

func interact_with_cell(cell: Vector2i) -> Dictionary:
	match current_tool:
		&"hoe":
			return till(cell)
		&"plant":
			return plant(cell, selected_crop_id)
		&"water":
			return water(cell)
		&"harvest":
			return harvest(cell)
	return _result(false, "Unknown farm tool.")

func till(cell: Vector2i) -> Dictionary:
	if not is_cell_unlocked(cell):
		return _result(false, "That farm plot is still locked.")
	var plot := get_plot(cell)
	if bool(plot.get("tilled", false)):
		return _result(false, "This soil is already tilled.")
	plot["tilled"] = true
	_write_plot(cell, plot)
	EventBus.farm_plot_changed.emit(_cell_key(cell))
	return _result(true, "Tilled the soil.")

func plant(cell: Vector2i, crop_id: String) -> Dictionary:
	if not is_cell_unlocked(cell):
		return _result(false, "That farm plot is still locked.")
	var crop := DataRegistry.get_crop(crop_id)
	if crop == null:
		return _result(false, "Missing crop data: %s" % crop_id)
	if not crop.season_ids.is_empty() and TimeWeatherManager.get_season_id() not in crop.season_ids:
		return _result(false, "%s is not planted in %s." % [crop.display_name, TimeWeatherManager.get_season_id().capitalize()])
	var plot := get_plot(cell)
	if not bool(plot.get("tilled", false)):
		return _result(false, "Till the soil first.")
	if not str(plot.get("crop_id", "")).is_empty():
		return _result(false, "Something is already growing here.")
	if not InventoryManager.consume_item(crop.seed_item_id, 1):
		var seed := DataRegistry.get_item(crop.seed_item_id)
		return _result(false, "You need %s." % (seed.display_name if seed else crop.seed_item_id))
	plot["crop_id"] = crop_id
	plot["remaining_minutes"] = float(crop.growth_minutes)
	plot["watered"] = not crop.watering_required or TimeWeatherManager.get_weather_id() == "rain"
	plot["ready"] = false
	_write_plot(cell, plot)
	EventBus.crop_planted.emit(_cell_key(cell), crop_id)
	EventBus.farm_plot_changed.emit(_cell_key(cell))
	return _result(true, "Planted %s." % crop.display_name)

func water(cell: Vector2i) -> Dictionary:
	var plot := get_plot(cell)
	var crop_id := str(plot.get("crop_id", ""))
	if crop_id.is_empty():
		return _result(false, "There is no crop here to water.")
	if bool(plot.get("ready", false)):
		return _result(false, "This crop is ready to harvest.")
	if bool(plot.get("watered", false)):
		return _result(false, "This crop is already watered.")
	plot["watered"] = true
	_write_plot(cell, plot)
	EventBus.crop_watered.emit(_cell_key(cell), crop_id)
	EventBus.farm_plot_changed.emit(_cell_key(cell))
	return _result(true, "Watered the crop. Growth has started.")

func harvest(cell: Vector2i) -> Dictionary:
	var plot := get_plot(cell)
	var crop_id := str(plot.get("crop_id", ""))
	if crop_id.is_empty():
		return _result(false, "There is nothing to harvest.")
	if not bool(plot.get("ready", false)):
		var remain := ceili(float(plot.get("remaining_minutes", 0.0)))
		return _result(false, "Not ready yet (%d game minutes remaining)." % maxi(0, remain))
	var crop := DataRegistry.get_crop(crop_id)
	if crop == null:
		return _result(false, "Missing crop data.")
	if InventoryManager.get_space_for(crop.harvest_item_id) < crop.base_yield:
		return _result(false, "Your inventory does not have enough room for the harvest.")
	var accepted := InventoryManager.add_item(crop.harvest_item_id, crop.base_yield)
	InventoryManager.add_item(crop.seed_item_id, 1)
	plot.erase("crop_id")
	plot.erase("remaining_minutes")
	plot.erase("watered")
	plot.erase("ready")
	plot.erase("last_update_unix")
	_write_plot(cell, plot)
	EventBus.crop_harvested.emit(_cell_key(cell), crop_id, accepted)
	EventBus.farm_plot_changed.emit(_cell_key(cell))
	return _result(true, "Harvested %d × %s and recovered 1 seed." % [accepted, crop.display_name])

func get_growth_stage(cell: Vector2i) -> int:
	var plot := get_plot(cell)
	var crop_id := str(plot.get("crop_id", ""))
	if crop_id.is_empty():
		return -1
	var crop := DataRegistry.get_crop(crop_id)
	if crop == null:
		return -1
	if bool(plot.get("ready", false)):
		return maxi(0, crop.growth_stage_count - 1)
	var total := maxf(1.0, float(crop.growth_minutes))
	var remaining := clampf(float(plot.get("remaining_minutes", total)), 0.0, total)
	var progress := 1.0 - (remaining / total)
	return clampi(int(floor(progress * crop.growth_stage_count)), 0, crop.growth_stage_count - 1)

func get_plot_status(cell: Vector2i) -> String:
	if not is_cell_unlocked(cell):
		return "Locked"
	var plot := get_plot(cell)
	if not bool(plot.get("tilled", false)):
		return "Grass"
	var crop_id := str(plot.get("crop_id", ""))
	if crop_id.is_empty():
		return "Tilled soil"
	var crop := DataRegistry.get_crop(crop_id)
	var crop_name := crop.display_name if crop else crop_id
	if bool(plot.get("ready", false)):
		return "%s — Ready" % crop_name
	if not bool(plot.get("watered", false)):
		return "%s — Needs water" % crop_name
	return "%s — %d min" % [crop_name, ceili(float(plot.get("remaining_minutes", 0.0)))]

func update_all_plots() -> void:
	for y in range(FIELD_HEIGHT):
		for x in range(FIELD_WIDTH):
			var cell := Vector2i(x, y)
			if is_cell_unlocked(cell):
				EventBus.farm_plot_changed.emit(_cell_key(cell))

func can_expand() -> bool:
	return not bool(GameState.farm_state.get("expanded", false))

func expand_farm() -> Dictionary:
	if not can_expand():
		return _result(false, "The starter field is already fully expanded.")
	if not InventoryManager.spend_currency(EXPANSION_COST):
		return _result(false, "You need %d coins to expand the field." % EXPANSION_COST)
	GameState.farm_state["expanded"] = true
	EventBus.farm_expanded.emit()
	return _result(true, "Farm expanded! All %d plots are now available." % (FIELD_WIDTH * FIELD_HEIGHT))

func interact_processing(recipe_id: String) -> Dictionary:
	ensure_farm_state()
	var job: Dictionary = GameState.farm_state.get("processing", {})
	if not job.is_empty():
		var remaining := maxf(0.0, float(job.get("remaining_minutes", 0.0)))
		if remaining > 0.0:
			return _result(false, "Processing is still underway (%d game minutes remaining)." % ceili(remaining))
		var output_id := str(job.get("output_item_id", ""))
		var output_amount := int(job.get("output_amount", 1))
		if InventoryManager.get_space_for(output_id) < output_amount:
			return _result(false, "Make inventory room before collecting the finished food.")
		var accepted := InventoryManager.add_item(output_id, output_amount)
		GameState.farm_state["processing"] = {}
		EventBus.processing_collected.emit(str(job.get("recipe_id", "")), output_id, accepted)
		var output := DataRegistry.get_item(output_id)
		return _result(true, "Collected %d × %s." % [accepted, output.display_name if output else output_id])

	var recipe := DataRegistry.get_recipe(recipe_id)
	if recipe == null:
		return _result(false, "Missing recipe data.")
	for ingredient_id in recipe.ingredients.keys():
		var needed := int(recipe.ingredients[ingredient_id])
		if not InventoryManager.has_item(str(ingredient_id), needed):
			return _result(false, "You do not have the ingredients for %s." % recipe.display_name)
	for ingredient_id in recipe.ingredients.keys():
		InventoryManager.remove_item(str(ingredient_id), int(recipe.ingredients[ingredient_id]))
	var duration_minutes := maxf(1.0, float(recipe.processing_minutes))
	GameState.farm_state["processing"] = {
		"recipe_id": recipe_id,
		"output_item_id": recipe.output_item_id,
		"output_amount": recipe.output_amount,
		"remaining_minutes": duration_minutes
	}
	EventBus.processing_started.emit(recipe_id, duration_minutes)
	return _result(true, "Started %s. It will finish in %d game minutes." % [recipe.display_name, ceili(duration_minutes)])

func _on_game_minutes_advanced(minutes: int) -> void:
	if minutes <= 0:
		return
	ensure_farm_state()
	var plots: Dictionary = GameState.farm_state["plots"]
	for key in plots.keys():
		var plot: Dictionary = (plots[key] as Dictionary).duplicate(true)
		var crop_id := str(plot.get("crop_id", ""))
		if crop_id.is_empty() or bool(plot.get("ready", false)) or not bool(plot.get("watered", false)):
			continue
		var remaining := maxf(0.0, float(plot.get("remaining_minutes", 0.0)) - float(minutes))
		plot["remaining_minutes"] = remaining
		if remaining <= 0.0:
			plot["ready"] = true
			EventBus.crop_ready.emit(str(key), crop_id)
		plots[key] = plot
		EventBus.farm_plot_changed.emit(str(key))
	GameState.farm_state["plots"] = plots

	var job: Dictionary = GameState.farm_state.get("processing", {})
	if not job.is_empty():
		job["remaining_minutes"] = maxf(0.0, float(job.get("remaining_minutes", 0.0)) - float(minutes))
		GameState.farm_state["processing"] = job

func _on_weather_changed(weather_id: String) -> void:
	if weather_id != "rain":
		return
	ensure_farm_state()
	var plots: Dictionary = GameState.farm_state["plots"]
	for key in plots.keys():
		var plot: Dictionary = (plots[key] as Dictionary).duplicate(true)
		var crop_id := str(plot.get("crop_id", ""))
		if crop_id.is_empty() or bool(plot.get("ready", false)) or bool(plot.get("watered", false)):
			continue
		plot["watered"] = true
		plots[key] = plot
		EventBus.crop_watered.emit(str(key), crop_id)
		EventBus.farm_plot_changed.emit(str(key))
	GameState.farm_state["plots"] = plots
	EventBus.interaction_message.emit("The rain watered your planted crops.")

func _migrate_phase9_timers() -> void:
	var plots: Dictionary = GameState.farm_state.get("plots", {})
	for key in plots.keys():
		var plot: Dictionary = (plots[key] as Dictionary).duplicate(true)
		plot.erase("last_update_unix")
		plots[key] = plot
	GameState.farm_state["plots"] = plots
	var job: Dictionary = GameState.farm_state.get("processing", {})
	if not job.is_empty() and job.has("ready_at_unix") and not job.has("remaining_minutes"):
		job.erase("ready_at_unix")
		job["remaining_minutes"] = 1.0
		GameState.farm_state["processing"] = job

func _write_plot(cell: Vector2i, plot: Dictionary) -> void:
	ensure_farm_state()
	var plots: Dictionary = GameState.farm_state["plots"]
	plots[_cell_key(cell)] = plot
	GameState.farm_state["plots"] = plots

func _cell_key(cell: Vector2i) -> String:
	return "%d,%d" % [cell.x, cell.y]

func _result(success: bool, message: String) -> Dictionary:
	return {"success": success, "message": message}
