extends Node2D

var crop_id: String = ""
var stage: int = 0
var is_harvest_ready: bool = false

func configure(new_crop_id: String, new_stage: int, is_ready: bool) -> void:
	if crop_id == new_crop_id and stage == new_stage and is_harvest_ready == is_ready:
		return
	crop_id = new_crop_id
	stage = maxi(0, new_stage)
	is_harvest_ready = is_ready
	queue_redraw()

func _draw() -> void:
	var base := _crop_color()
	var scale_factor := 0.45 + float(stage) * 0.18
	if is_harvest_ready:
		scale_factor += 0.12
	# Stem.
	draw_line(Vector2(0, 13), Vector2(0, -13 * scale_factor), Color(0.18, 0.42, 0.2), 5.0)
	# Leaves / fruit placeholder.
	var radius := 7.0 + 4.0 * scale_factor
	draw_circle(Vector2(-7, -5 * scale_factor), radius, base)
	draw_circle(Vector2(7, -7 * scale_factor), radius, base.lightened(0.08))
	if is_harvest_ready:
		draw_circle(Vector2(0, -16), 5.0, Color(1.0, 0.82, 0.3))

func _crop_color() -> Color:
	match crop_id:
		"crop.stonebean":
			return Color(0.76, 0.38, 0.31)
		"crop.dewleaf":
			return Color(0.31, 0.62, 0.52)
		_:
			return Color(0.43, 0.63, 0.31)
