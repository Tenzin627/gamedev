extends Interactable

@export var recipe_id: String = "recipe.root_mash"

func _ready() -> void:
	interaction_prompt = "Cook / Collect"

func interact(_interactor: Node) -> void:
	var result := FarmManager.interact_processing(recipe_id)
	EventBus.interaction_message.emit(str(result.get("message", "")))
