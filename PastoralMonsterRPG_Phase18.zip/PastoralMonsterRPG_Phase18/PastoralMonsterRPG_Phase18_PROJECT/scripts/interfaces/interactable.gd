extends Area2D
class_name Interactable

signal interaction_started(interactor: Node)
signal interaction_finished(interactor: Node)

@export var interaction_prompt: String = "Interact"
@export var enabled: bool = true

func can_interact(_interactor: Node) -> bool:
	return enabled

func interact(interactor: Node) -> void:
	if not can_interact(interactor):
		return
	interaction_started.emit(interactor)
	interaction_finished.emit(interactor)
