extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")
const STARTING_CURRENCY := 250

func _ready() -> void:
	ensure_development_inventory()
	EventBus.game_loaded.connect(_on_game_loaded)
	EventBus.game_started.connect(ensure_development_inventory)

func _on_game_loaded() -> void:
	_normalize_inventory()
	EventBus.inventory_changed.emit()
	EventBus.currency_changed.emit(GameState.currency)

func ensure_development_inventory() -> void:
	if GameState.currency <= 0:
		GameState.currency = STARTING_CURRENCY
		EventBus.currency_changed.emit(GameState.currency)
	if not GameState.inventory.has("item.gya_basic"):
		add_item("item.gya_basic", 10)
	if not GameState.inventory.has("item.sunroot_seed"):
		add_item("item.sunroot_seed", 5)
	if not GameState.inventory.has("item.herbal_wrap"):
		add_item("item.herbal_wrap", 2)
	if not GameState.inventory.has("item.dewleaf_seed"):
		add_item("item.dewleaf_seed", 4)
	if not GameState.inventory.has("item.dewleaf_seed"):
		add_item("item.dewleaf_seed", 3)
	if not GameState.inventory.has("item.root_mash"):
		add_item("item.root_mash", 2)
	if not GameState.inventory.has("item.dewleaf"):
		add_item("item.dewleaf", 3)
	if not GameState.inventory.has("item.dewleaf"):
		add_item("item.dewleaf", 3)

func get_count(item_id: String) -> int:
	return maxi(0, int(GameState.inventory.get(item_id, 0)))

func has_item(item_id: String, amount: int = 1) -> bool:
	return get_count(item_id) >= maxi(1, amount)

func get_all_items() -> Dictionary:
	return GameState.inventory.duplicate(true)

func get_sorted_item_ids() -> Array[String]:
	var ids: Array[String] = []
	for key in GameState.inventory.keys():
		if get_count(str(key)) > 0:
			ids.append(str(key))
	ids.sort_custom(_sort_item_ids)
	return ids

func _sort_item_ids(a: String, b: String) -> bool:
	var item_a := DataRegistry.get_item(a)
	var item_b := DataRegistry.get_item(b)
	var category_a := str(item_a.category) if item_a else "zzz"
	var category_b := str(item_b.category) if item_b else "zzz"
	if category_a == category_b:
		var name_a := item_a.display_name if item_a else a
		var name_b := item_b.display_name if item_b else b
		return name_a.naturalnocasecmp_to(name_b) < 0
	return category_a.naturalnocasecmp_to(category_b) < 0

func get_space_for(item_id: String) -> int:
	var item := DataRegistry.get_item(item_id)
	if item == null:
		return 0
	return maxi(0, item.stack_limit - get_count(item_id))

func add_item(item_id: String, amount: int = 1) -> int:
	if amount <= 0:
		return 0
	var item := DataRegistry.get_item(item_id)
	if item == null:
		DevLog.warn("INVENTORY", "Cannot add missing item: %s" % item_id)
		return 0
	var accepted := mini(amount, get_space_for(item_id))
	if accepted <= 0:
		return 0
	GameState.inventory[item_id] = get_count(item_id) + accepted
	EventBus.item_added.emit(item_id, accepted)
	EventBus.inventory_changed.emit()
	return accepted

func remove_item(item_id: String, amount: int = 1) -> int:
	if amount <= 0:
		return 0
	var removed := mini(amount, get_count(item_id))
	if removed <= 0:
		return 0
	var remaining := get_count(item_id) - removed
	if remaining <= 0:
		GameState.inventory.erase(item_id)
	else:
		GameState.inventory[item_id] = remaining
	EventBus.item_removed.emit(item_id, removed)
	EventBus.inventory_changed.emit()
	return removed

func consume_item(item_id: String, amount: int = 1) -> bool:
	var safe_amount := maxi(1, amount)
	return remove_item(item_id, safe_amount) == safe_amount

func add_currency(amount: int) -> int:
	if amount <= 0:
		return GameState.currency
	GameState.currency += amount
	EventBus.currency_changed.emit(GameState.currency)
	return GameState.currency

func spend_currency(amount: int) -> bool:
	var safe_amount := maxi(0, amount)
	if safe_amount > GameState.currency:
		return false
	GameState.currency -= safe_amount
	EventBus.currency_changed.emit(GameState.currency)
	return true

func buy_item(item_id: String, amount: int = 1) -> Dictionary:
	var result := {"success": false, "reason": "invalid", "item_id": item_id, "amount": 0, "cost": 0}
	var item := DataRegistry.get_item(item_id)
	if item == null or amount <= 0:
		return result
	var buy_amount := mini(amount, get_space_for(item_id))
	if buy_amount <= 0:
		result.reason = "stack_full"
		return result
	var cost := maxi(0, item.base_value) * buy_amount
	if not spend_currency(cost):
		result.reason = "not_enough_currency"
		return result
	var accepted := add_item(item_id, buy_amount)
	if accepted != buy_amount:
		add_currency(cost)
		result.reason = "inventory_changed"
		return result
	result.success = true
	result.reason = "bought"
	result.amount = accepted
	result.cost = cost
	return result

func sell_item(item_id: String, amount: int = 1) -> Dictionary:
	var result := {"success": false, "reason": "invalid", "item_id": item_id, "amount": 0, "earned": 0}
	var item := DataRegistry.get_item(item_id)
	if item == null or amount <= 0:
		return result
	var sell_amount := mini(amount, get_count(item_id))
	if sell_amount <= 0:
		result.reason = "none_owned"
		return result
	var removed := remove_item(item_id, sell_amount)
	var earned := maxi(1, int(round(float(item.base_value) * 0.5))) * removed
	add_currency(earned)
	result.success = true
	result.reason = "sold"
	result.amount = removed
	result.earned = earned
	return result

func use_item(item_id: String) -> Dictionary:
	var result := {"success": false, "reason": "invalid", "message": "This item cannot be used here."}
	var item := DataRegistry.get_item(item_id)
	if item == null or not has_item(item_id):
		return result
	if not item.usable:
		result.reason = "not_usable"
		result.message = "%s is not directly usable." % item.display_name
		return result

	match item.use_effect_id:
		"effect.heal_party_small":
			var target := _first_injured_party_monster()
			if target == null:
				result.reason = "no_target"
				result.message = "Your party is already healthy."
				return result
			if not consume_item(item_id, 1):
				return result
			var healed := MonsterManager.heal_monster(target.instance_id, 20)
			result.success = healed > 0
			result.reason = "used"
			result.message = "%s recovered %d HP." % [target.get_display_name(), healed]
		"effect.capture_attempt":
			result.reason = "battle_only"
			result.message = "Gya can be used during an eligible wild battle."
		"effect.feed_monster":
			result.reason = "monster_target_required"
			result.message = "Choose a monster in the Feeding & Development screen (Ctrl+D)."
		_:
			result.reason = "unimplemented_effect"
			result.message = "This item's effect is not implemented yet."

	EventBus.item_used.emit(item_id, result)
	return result

func _first_injured_party_monster() -> MonsterInstance:
	for monster in MonsterManager.get_party():
		if monster.current_hp > 0 and monster.current_hp < monster.get_max_hp():
			return monster
	return null

func _normalize_inventory() -> void:
	var normalized := {}
	for key in GameState.inventory.keys():
		var item_id := str(key)
		var item := DataRegistry.get_item(item_id)
		if item == null:
			DevLog.warn("INVENTORY", "Removed unknown saved item: %s" % item_id)
			continue
		var count := clampi(int(GameState.inventory[key]), 0, item.stack_limit)
		if count > 0:
			normalized[item_id] = count
	GameState.inventory = normalized
