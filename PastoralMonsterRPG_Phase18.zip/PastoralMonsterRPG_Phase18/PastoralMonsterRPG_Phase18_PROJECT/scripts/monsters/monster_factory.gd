extends RefCounted
class_name MonsterFactory

const IdUtils = preload("res://scripts/utilities/id_utils.gd")

static func create(species_id: String, level: int = 1, trait_id: String = "", capture_data: Dictionary = {}) -> MonsterInstance:
	var species := DataRegistry.get_monster(species_id)
	if species == null:
		push_error("MonsterFactory: unknown species '%s'." % species_id)
		return null

	var monster := MonsterInstance.new()
	monster.instance_id = IdUtils.make_runtime_id("monster")
	monster.species_id = species_id
	monster.level = clampi(level, 1, MonsterInstance.MAX_LEVEL)
	monster.experience = 0
	monster.trait_id = _choose_trait(species, trait_id)
	monster.capture_data = capture_data.duplicate(true)
	monster.development = {
		"gentle": 0,
		"resilient": 0,
		"swift": 0,
		"bold": 0
	}

	var gated_moves: Array[String] = []
	for rule in species.move_unlock_rules:
		var gated_id := str(rule.get("move_id", ""))
		if not gated_id.is_empty() and gated_id not in gated_moves:
			gated_moves.append(gated_id)

	for move_id in species.move_ids:
		if move_id in gated_moves:
			continue
		if DataRegistry.get_move(move_id) != null:
			monster.unlock_move(move_id)
			if monster.equipped_move_ids.size() < MonsterInstance.MAX_MOVE_SLOTS:
				monster.equip_move(move_id)

	monster.heal_full()
	return monster

static func _choose_trait(species: MonsterSpeciesData, requested_trait_id: String) -> String:
	if not requested_trait_id.is_empty() and requested_trait_id in species.trait_ids:
		return requested_trait_id
	if species.trait_ids.is_empty():
		return ""
	return species.trait_ids[randi() % species.trait_ids.size()]
