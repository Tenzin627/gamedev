extends Resource
class_name MonsterInstance

const MAX_LEVEL := 100
const MAX_MOVE_SLOTS := 4

@export var instance_id: String = ""
@export var species_id: String = ""
@export var nickname: String = ""
@export_range(1, MAX_LEVEL, 1) var level: int = 1
@export var experience: int = 0
@export var current_hp: int = 1
@export var trait_id: String = ""
@export var equipped_move_ids: Array[String] = []
@export var unlocked_move_ids: Array[String] = []
@export var development: Dictionary = {}
@export var capture_data: Dictionary = {}
@export var favorite_food_memory: Dictionary = {}
@export var evolution_history: Array[Dictionary] = []

func get_species() -> MonsterSpeciesData:
	return DataRegistry.get_monster(species_id)

func get_display_name() -> String:
	if not nickname.strip_edges().is_empty():
		return nickname
	var species := get_species()
	return species.display_name if species != null else species_id

func get_max_hp() -> int:
	return get_stat("hp")

func get_stat(stat_name: String) -> int:
	var species := get_species()
	if species == null:
		return 1
	var base_value := int(species.base_stats.get(stat_name, 1))
	return calculate_stat(base_value, level, stat_name == "hp")

static func calculate_stat(base_value: int, at_level: int, is_hp: bool = false) -> int:
	# Transparent Phase 4 growth formula. It is intentionally easy to rebalance later.
	# Every level adds 5% of the species base stat, rounded down; HP also gains +1/level.
	var safe_level := clampi(at_level, 1, MAX_LEVEL)
	var growth := int(floor(float(base_value) * 0.05 * float(safe_level - 1)))
	if is_hp:
		growth += safe_level - 1
	return maxi(1, base_value + growth)

func get_all_stats() -> Dictionary:
	return {
		"hp": get_stat("hp"),
		"attack": get_stat("attack"),
		"defense": get_stat("defense"),
		"speed": get_stat("speed")
	}

func is_fainted() -> bool:
	return current_hp <= 0

func heal(amount: int) -> int:
	if amount <= 0:
		return 0
	var before := current_hp
	current_hp = mini(get_max_hp(), current_hp + amount)
	return current_hp - before

func heal_full() -> void:
	current_hp = get_max_hp()

func take_damage(amount: int) -> int:
	if amount <= 0:
		return 0
	var before := current_hp
	current_hp = maxi(0, current_hp - amount)
	return before - current_hp

func experience_for_next_level() -> int:
	if level >= MAX_LEVEL:
		return 0
	# Experience stored here is progress within the current level.
	return 40 + (level * level * 10)

func add_experience(amount: int) -> Array[int]:
	var gained_levels: Array[int] = []
	if amount <= 0 or level >= MAX_LEVEL:
		return gained_levels

	experience += amount
	while level < MAX_LEVEL:
		var required := experience_for_next_level()
		if required <= 0 or experience < required:
			break
		experience -= required
		var previous_max_hp := get_max_hp()
		level += 1
		var hp_gain := get_max_hp() - previous_max_hp
		current_hp += hp_gain
		gained_levels.append(level)

	if level >= MAX_LEVEL:
		experience = 0
	return gained_levels

func has_move(move_id: String) -> bool:
	return move_id in equipped_move_ids

func knows_move(move_id: String) -> bool:
	return move_id in unlocked_move_ids

func unlock_move(move_id: String) -> bool:
	if move_id.is_empty() or DataRegistry.get_move(move_id) == null:
		return false
	if move_id not in unlocked_move_ids:
		unlocked_move_ids.append(move_id)
		return true
	return false

func equip_move(move_id: String, slot: int = -1) -> bool:
	if not knows_move(move_id):
		return false
	if slot < 0:
		if move_id in equipped_move_ids:
			return true
		if equipped_move_ids.size() >= MAX_MOVE_SLOTS:
			return false
		equipped_move_ids.append(move_id)
		return true
	if slot >= MAX_MOVE_SLOTS:
		return false
	while equipped_move_ids.size() <= slot:
		equipped_move_ids.append("")
	equipped_move_ids[slot] = move_id
	_cleanup_move_slots()
	return true

func unequip_move(slot: int) -> bool:
	if slot < 0 or slot >= equipped_move_ids.size():
		return false
	equipped_move_ids.remove_at(slot)
	return true

func set_nickname(value: String) -> void:
	nickname = value.strip_edges().left(24)

func to_dict() -> Dictionary:
	return {
		"instance_id": instance_id,
		"species_id": species_id,
		"nickname": nickname,
		"level": level,
		"experience": experience,
		"current_hp": current_hp,
		"trait_id": trait_id,
		"equipped_move_ids": equipped_move_ids.duplicate(),
		"unlocked_move_ids": unlocked_move_ids.duplicate(),
		"development": development.duplicate(true),
		"capture_data": capture_data.duplicate(true),
		"favorite_food_memory": favorite_food_memory.duplicate(true),
		"evolution_history": evolution_history.duplicate(true)
	}

static func from_dict(data: Dictionary) -> MonsterInstance:
	var result := MonsterInstance.new()
	result.instance_id = str(data.get("instance_id", ""))
	result.species_id = str(data.get("species_id", ""))
	result.nickname = str(data.get("nickname", ""))
	result.level = clampi(int(data.get("level", 1)), 1, MAX_LEVEL)
	result.experience = maxi(0, int(data.get("experience", 0)))
	result.current_hp = maxi(0, int(data.get("current_hp", 1)))
	result.trait_id = str(data.get("trait_id", ""))
	result.equipped_move_ids = _string_array(data.get("equipped_move_ids", []))
	result.unlocked_move_ids = _string_array(data.get("unlocked_move_ids", []))
	result.development = _dict_copy(data.get("development", {}))
	result.capture_data = _dict_copy(data.get("capture_data", {}))
	result.favorite_food_memory = _dict_copy(data.get("favorite_food_memory", {}))
	result.evolution_history = _dictionary_array(data.get("evolution_history", []))
	result._cleanup_move_slots()
	var species := result.get_species()
	if species != null:
		result.current_hp = mini(result.current_hp, result.get_max_hp())
	return result

static func _string_array(value: Variant) -> Array[String]:
	var result: Array[String] = []
	if value is Array:
		for entry in value:
			result.append(str(entry))
	return result

static func _dict_copy(value: Variant) -> Dictionary:
	return value.duplicate(true) if value is Dictionary else {}

static func _dictionary_array(value: Variant) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if value is Array:
		for entry in value:
			if entry is Dictionary:
				result.append(entry.duplicate(true))
	return result

func _cleanup_move_slots() -> void:
	var clean: Array[String] = []
	for move_id in equipped_move_ids:
		if not move_id.is_empty() and move_id not in clean:
			clean.append(move_id)
		if clean.size() >= MAX_MOVE_SLOTS:
			break
	equipped_move_ids = clean
