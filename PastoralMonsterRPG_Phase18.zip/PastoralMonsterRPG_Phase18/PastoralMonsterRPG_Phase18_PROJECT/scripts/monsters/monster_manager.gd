extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

const MAX_PARTY_SIZE := 4

var party: Array[MonsterInstance] = []
var farm_storage: Array[MonsterInstance] = []

func _ready() -> void:
	load_from_game_state()
	EventBus.game_loaded.connect(load_from_game_state)

func create_monster(species_id: String, level: int = 1, trait_id: String = "", destination: String = "auto") -> MonsterInstance:
	var monster := MonsterFactory.create(species_id, level, trait_id)
	if monster == null:
		return null
	add_monster(monster, destination)
	return monster

func add_monster(monster: MonsterInstance, destination: String = "auto") -> String:
	if monster == null:
		return "failed"
	if find_monster(monster.instance_id) != null:
		DevLog.warn("MONSTER", "Ignored duplicate monster instance %s." % monster.instance_id)
		return "duplicate"

	var resolved := destination
	if destination == "auto":
		resolved = "party" if party.size() < MAX_PARTY_SIZE else "farm"

	if resolved == "party" and party.size() < MAX_PARTY_SIZE:
		party.append(monster)
		_sync_state()
		EventBus.monster_added.emit(monster.instance_id, "party")
		EventBus.monster_party_changed.emit()
		return "party"

	farm_storage.append(monster)
	_sync_state()
	EventBus.monster_added.emit(monster.instance_id, "farm")
	EventBus.monster_storage_changed.emit()
	return "farm"

func move_to_party(instance_id: String) -> bool:
	if party.size() >= MAX_PARTY_SIZE:
		return false
	var index := _index_of(farm_storage, instance_id)
	if index < 0:
		return false
	var monster := farm_storage[index]
	farm_storage.remove_at(index)
	party.append(monster)
	_sync_state()
	EventBus.monster_party_changed.emit()
	EventBus.monster_storage_changed.emit()
	return true

func move_to_farm(instance_id: String) -> bool:
	var index := _index_of(party, instance_id)
	if index < 0:
		return false
	var monster := party[index]
	party.remove_at(index)
	farm_storage.append(monster)
	_sync_state()
	EventBus.monster_party_changed.emit()
	EventBus.monster_storage_changed.emit()
	return true

func swap_party_slots(from_index: int, to_index: int) -> bool:
	if from_index < 0 or from_index >= party.size() or to_index < 0 or to_index >= party.size():
		return false
	var temp := party[from_index]
	party[from_index] = party[to_index]
	party[to_index] = temp
	_sync_state()
	EventBus.monster_party_changed.emit()
	return true

func remove_monster(instance_id: String) -> MonsterInstance:
	var index := _index_of(party, instance_id)
	if index >= 0:
		var removed := party[index]
		party.remove_at(index)
		_sync_state()
		EventBus.monster_party_changed.emit()
		return removed
	index = _index_of(farm_storage, instance_id)
	if index >= 0:
		var removed := farm_storage[index]
		farm_storage.remove_at(index)
		_sync_state()
		EventBus.monster_storage_changed.emit()
		return removed
	return null

func find_monster(instance_id: String) -> MonsterInstance:
	for monster in party:
		if monster.instance_id == instance_id:
			return monster
	for monster in farm_storage:
		if monster.instance_id == instance_id:
			return monster
	return null

func get_party() -> Array[MonsterInstance]:
	return party.duplicate()

func get_farm_storage() -> Array[MonsterInstance]:
	return farm_storage.duplicate()

func add_experience(instance_id: String, amount: int) -> Array[int]:
	var monster := find_monster(instance_id)
	if monster == null:
		return []
	var levels := monster.add_experience(amount)
	for new_level in levels:
		EventBus.monster_leveled_up.emit(instance_id, new_level)
	_sync_state()
	return levels

func damage_monster(instance_id: String, amount: int) -> int:
	var monster := find_monster(instance_id)
	if monster == null:
		return 0
	var changed := monster.take_damage(amount)
	_sync_state()
	EventBus.monster_hp_changed.emit(instance_id, monster.current_hp, monster.get_max_hp())
	return changed

func heal_monster(instance_id: String, amount: int) -> int:
	var monster := find_monster(instance_id)
	if monster == null:
		return 0
	var changed := monster.heal(amount)
	_sync_state()
	EventBus.monster_hp_changed.emit(instance_id, monster.current_hp, monster.get_max_hp())
	return changed

func heal_all() -> void:
	for monster in party:
		monster.heal_full()
	for monster in farm_storage:
		monster.heal_full()
	_sync_state()
	EventBus.monster_roster_healed.emit()

func sync_to_game_state() -> void:
	_sync_state()

func clear_all() -> void:
	party.clear()
	farm_storage.clear()
	_sync_state()
	EventBus.monster_party_changed.emit()
	EventBus.monster_storage_changed.emit()

func load_from_game_state() -> void:
	party.clear()
	farm_storage.clear()
	for value in GameState.party:
		if value is Dictionary:
			var monster := MonsterInstance.from_dict(value)
			if _is_valid_instance(monster):
				party.append(monster)
	for value in GameState.monster_storage:
		if value is Dictionary:
			var monster := MonsterInstance.from_dict(value)
			if _is_valid_instance(monster):
				farm_storage.append(monster)
	_trim_overflow_to_farm()
	_sync_state()
	EventBus.monster_party_changed.emit()
	EventBus.monster_storage_changed.emit()

func seed_phase4_demo_roster() -> void:
	clear_all()
	create_monster("monster.spriggle", 5, "trait.helping_leaf", "party")
	create_monster("monster.pebblit", 8, "", "party")
	create_monster("monster.bloomtail", 10, "", "farm")
	DevLog.info("MONSTER", "Created Phase 4 demo roster.")

func _sync_state() -> void:
	GameState.party = _serialize(party)
	GameState.monster_storage = _serialize(farm_storage)

func _serialize(collection: Array[MonsterInstance]) -> Array:
	var result: Array = []
	for monster in collection:
		result.append(monster.to_dict())
	return result

func _index_of(collection: Array[MonsterInstance], instance_id: String) -> int:
	for i in range(collection.size()):
		if collection[i].instance_id == instance_id:
			return i
	return -1

func _is_valid_instance(monster: MonsterInstance) -> bool:
	return monster != null and not monster.instance_id.is_empty() and DataRegistry.get_monster(monster.species_id) != null

func _trim_overflow_to_farm() -> void:
	while party.size() > MAX_PARTY_SIZE:
		farm_storage.push_front(party.pop_back())
