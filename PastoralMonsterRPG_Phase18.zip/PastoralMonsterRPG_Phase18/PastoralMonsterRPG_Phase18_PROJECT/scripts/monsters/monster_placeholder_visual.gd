extends Node2D
class_name MonsterPlaceholderVisual

@export var body_radius := 42.0
@export var leaf_size := Vector2(18.0, 28.0)

func _draw() -> void:
	# Neutral placeholder only. Replace with your production monster SpriteFrames later.
	draw_circle(Vector2.ZERO, body_radius, Color(0.63, 0.72, 0.43))
	draw_circle(Vector2(-16, -8), 4.0, Color(0.12, 0.15, 0.10))
	draw_circle(Vector2(16, -8), 4.0, Color(0.12, 0.15, 0.10))
	draw_arc(Vector2(0, 7), 10.0, 0.2, PI - 0.2, 16, Color(0.18, 0.20, 0.14), 2.0)
	var leaf := PackedVector2Array([Vector2(-11, -42), Vector2(-4, -70), Vector2(4, -45)])
	draw_colored_polygon(leaf, Color(0.34, 0.56, 0.28))
	var leaf2 := PackedVector2Array([Vector2(5, -43), Vector2(18, -65), Vector2(15, -39)])
	draw_colored_polygon(leaf2, Color(0.39, 0.61, 0.31))
