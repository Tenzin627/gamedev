extends Interactable
class_name NPCActor

@export var npc_id: String = "npc.village_elder"
@export var dialogue_id_override: String = ""
@export var available_periods: Array[String] = []

@onready var name_label: Label = get_node_or_null("NameLabel") as Label
@onready var placeholder_visual: Polygon2D = get_node_or_null("Visual") as Polygon2D

func _ready() -> void:
	_refresh_from_data()
	EventBus.time_period_changed.connect(_on_time_period_changed)
	_refresh_availability()

func can_interact(interactor: Node) -> bool:
	return super.can_interact(interactor) and _is_available()

func interact(_interactor: Node) -> void:
	var npc_data := DataRegistry.get_npc(npc_id)
	if npc_data == null:
		EventBus.interaction_message.emit("Missing NPC data: %s" % npc_id)
		return
	var dialogue_id := dialogue_id_override if not dialogue_id_override.is_empty() else npc_data.default_dialogue_id
	if dialogue_id.is_empty():
		EventBus.interaction_message.emit("%s has nothing to say yet." % npc_data.display_name)
		return
	DialogueManager.start_dialogue(dialogue_id, {
		"npc_id": npc_id,
		"speaker_name": npc_data.display_name,
		"actor_path": str(get_path())
	})

func _refresh_from_data() -> void:
	var npc_data := DataRegistry.get_npc(npc_id)
	if npc_data == null:
		interaction_prompt = "Talk"
		if name_label != null:
			name_label.text = "Missing NPC"
		return
	interaction_prompt = "Talk to %s" % npc_data.display_name
	if name_label != null:
		name_label.text = npc_data.display_name

func _is_available() -> bool:
	return available_periods.is_empty() or available_periods.has(TimeWeatherManager.get_time_period())

func _refresh_availability() -> void:
	enabled = _is_available()
	visible = enabled

func _on_time_period_changed(_period_id: String) -> void:
	_refresh_availability()
