extends Node

signal tag_awarded(tag_key: String, source: String)
signal tag_revoked(tag_key: String)
signal progress_changed(progress_id: String, current: int, required: int)

const FARMER_TAG := "farmer"
const TAMER_TAG := "tamer"
const EXPLORER_TAG := "explorer"

const PROGRESS_FARMER := "farmer_harvests"
const PROGRESS_TAMER := "tamer_captures"
const PROGRESS_EXPLORER := "explorer_maps"
const PROGRESS_FIELDHAND := "fieldhand_harvests"
const PROGRESS_FORAGER := "forager_discoveries"

var _known_map_ids: Dictionary = {}

func _ready() -> void:
	_normalize_profile()
	_connect_events()
	call_deferred("refresh_milestones")

func _connect_events() -> void:
	if not EventBus.crop_harvested.is_connected(_on_crop_harvested):
		EventBus.crop_harvested.connect(_on_crop_harvested)
	if not EventBus.monster_captured.is_connected(_on_monster_captured):
		EventBus.monster_captured.connect(_on_monster_captured)
	if not EventBus.map_entered.is_connected(_on_map_entered):
		EventBus.map_entered.connect(_on_map_entered)
	if not EventBus.resource_gathered.is_connected(_on_resource_gathered):
		EventBus.resource_gathered.connect(_on_resource_gathered)

func has_tag(tag_key: String) -> bool:
	return get_tags().has(tag_key)

func get_tags() -> Array[String]:
	var result: Array[String] = []
	var value: Variant = GameState.player_profile.get("profile_tags", [])
	if value is Array:
		for entry in value:
			var key := str(entry)
			if not key.is_empty() and not result.has(key):
				result.append(key)
	return result

func award_tag(tag_key: String, source: String = "system", context: Dictionary = {}) -> bool:
	if tag_key.is_empty():
		return false
	var tags := get_tags()
	if tags.has(tag_key):
		return false
	tags.append(tag_key)
	GameState.player_profile["profile_tags"] = tags
	var history := get_history()
	history.append({
		"tag": tag_key,
		"source": source,
		"day": int(GameState.game_time.get("day", 1)),
		"season": str(GameState.game_time.get("season", "spring")),
		"context": context.duplicate(true)
	})
	GameState.player_profile["profile_tag_history"] = history
	EventBus.profile_tag_changed.emit(tag_key, true)
	tag_awarded.emit(tag_key, source)
	var definition := get_definition_for_key(tag_key)
	var display_name := definition.display_name if definition != null else tag_key.capitalize()
	EventBus.interaction_message.emit("Profile Tag earned: %s" % display_name)
	return true

func revoke_tag(tag_key: String) -> bool:
	var tags := get_tags()
	if not tags.has(tag_key):
		return false
	tags.erase(tag_key)
	GameState.player_profile["profile_tags"] = tags
	EventBus.profile_tag_changed.emit(tag_key, false)
	tag_revoked.emit(tag_key)
	return true

func get_history() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var value: Variant = GameState.player_profile.get("profile_tag_history", [])
	if value is Array:
		for entry in value:
			if entry is Dictionary:
				result.append((entry as Dictionary).duplicate(true))
	return result

func get_definition_for_key(tag_key: String) -> ProfileTagData:
	for value in DataRegistry.get_category("profile_tags"):
		var definition := value as ProfileTagData
		if definition != null and definition.tag_key == tag_key:
			return definition
	return null

func get_all_definitions() -> Array[ProfileTagData]:
	var result: Array[ProfileTagData] = []
	for value in DataRegistry.get_category("profile_tags"):
		var definition := value as ProfileTagData
		if definition != null and definition.enabled:
			result.append(definition)
	result.sort_custom(func(a, b): return (a as ProfileTagData).sort_order < (b as ProfileTagData).sort_order)
	return result

func add_progress(progress_id: String, amount: int = 1) -> int:
	if progress_id.is_empty() or amount <= 0:
		return get_progress(progress_id)
	var progress := _get_progress_dictionary()
	var current := maxi(0, int(progress.get(progress_id, 0)) + amount)
	progress[progress_id] = current
	GameState.player_profile["profile_tag_progress"] = progress
	var required := get_required_for_progress(progress_id)
	progress_changed.emit(progress_id, current, required)
	EventBus.profile_tag_progress_changed.emit(progress_id, current, required)
	refresh_milestones()
	return current

func get_progress(progress_id: String) -> int:
	return int(_get_progress_dictionary().get(progress_id, 0))

func get_required_for_progress(progress_id: String) -> int:
	for definition in get_all_definitions():
		if str(definition.milestone_type) == progress_id:
			return maxi(0, definition.milestone_threshold)
	return 0

func get_progress_for_tag(tag_key: String) -> Dictionary:
	var definition := get_definition_for_key(tag_key)
	if definition == null or str(definition.milestone_type).is_empty():
		return {"current": 0, "required": 0, "complete": has_tag(tag_key)}
	var progress_id := str(definition.milestone_type)
	var current := get_progress(progress_id)
	var required := maxi(0, definition.milestone_threshold)
	return {"current": current, "required": required, "complete": has_tag(tag_key) or (required > 0 and current >= required)}

func refresh_milestones() -> void:
	_normalize_profile()
	_sync_explorer_progress()
	for definition in get_all_definitions():
		if definition.tag_key.is_empty() or has_tag(definition.tag_key):
			continue
		var progress_id := str(definition.milestone_type)
		if progress_id.is_empty() or definition.milestone_threshold <= 0:
			continue
		if get_progress(progress_id) >= definition.milestone_threshold:
			award_tag(definition.tag_key, "milestone", {"progress_id": progress_id})

func meets_all(required_tags: Array[String]) -> bool:
	for tag_key in required_tags:
		if not has_tag(tag_key):
			return false
	return true

func meets_any(required_tags: Array[String]) -> bool:
	if required_tags.is_empty():
		return true
	for tag_key in required_tags:
		if has_tag(tag_key):
			return true
	return false

func _on_crop_harvested(_cell_key: String, _crop_id: String, amount: int) -> void:
	add_progress(PROGRESS_FARMER, maxi(1, amount))
	add_progress(PROGRESS_FIELDHAND, maxi(1, amount))

func _on_resource_gathered(_resource_id: String, amount: int) -> void:
	add_progress(PROGRESS_FORAGER, maxi(1, amount))

func _on_monster_captured(_monster_instance_id: String) -> void:
	add_progress(PROGRESS_TAMER, 1)

func _on_map_entered(map_id: String, _display_name: String) -> void:
	if not map_id.is_empty():
		_known_map_ids[map_id] = true
	_sync_explorer_progress()
	refresh_milestones()

func _sync_explorer_progress() -> void:
	for map_id in GameState.map_discovery.keys():
		_known_map_ids[str(map_id)] = true
	if not GameState.current_map_id.is_empty():
		_known_map_ids[GameState.current_map_id] = true
	var progress := _get_progress_dictionary()
	var current := _known_map_ids.size()
	if int(progress.get(PROGRESS_EXPLORER, 0)) != current:
		progress[PROGRESS_EXPLORER] = current
		GameState.player_profile["profile_tag_progress"] = progress
		var required := get_required_for_progress(PROGRESS_EXPLORER)
		progress_changed.emit(PROGRESS_EXPLORER, current, required)
		EventBus.profile_tag_progress_changed.emit(PROGRESS_EXPLORER, current, required)

func _normalize_profile() -> void:
	GameState.player_profile["profile_tags"] = get_tags()
	var history_value: Variant = GameState.player_profile.get("profile_tag_history", [])
	if not (history_value is Array):
		GameState.player_profile["profile_tag_history"] = []
	var progress_value: Variant = GameState.player_profile.get("profile_tag_progress", {})
	if not (progress_value is Dictionary):
		GameState.player_profile["profile_tag_progress"] = {}

func _get_progress_dictionary() -> Dictionary:
	var value: Variant = GameState.player_profile.get("profile_tag_progress", {})
	return value.duplicate(true) if value is Dictionary else {}
