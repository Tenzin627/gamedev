extends Node

const STATE_AVAILABLE := "available"
const STATE_ACTIVE := "active"
const STATE_UPDATED := "updated"
const STATE_RESOLVED := "resolved"
const STATE_FAILED := "failed"
const STATE_ALTERNATE := "alternate_outcome"

signal quest_started(quest_id: String)
signal quest_progressed(quest_id: String, objective_id: String)
signal quest_completed(quest_id: String, outcome_id: String)

func _ready() -> void:
	_connect_events()
	call_deferred("refresh_availability")

func _connect_events() -> void:
	EventBus.dialogue_finished.connect(_on_dialogue_finished)
	EventBus.item_added.connect(_on_item_added)
	EventBus.resource_gathered.connect(_on_resource_gathered)
	EventBus.monster_captured.connect(_on_monster_captured)
	EventBus.battle_finished.connect(_on_battle_finished)
	EventBus.crop_harvested.connect(_on_crop_harvested)
	EventBus.map_entered.connect(_on_map_entered)
	EventBus.waystone_discovered.connect(_on_waystone_discovered)
	EventBus.profile_tag_changed.connect(_on_profile_tag_changed)
	EventBus.world_state_changed.connect(_on_world_state_changed)

func refresh_availability() -> void:
	for definition_value in DataRegistry.get_category("quests"):
		var quest := definition_value as QuestData
		if quest == null:
			continue
		var existing: Variant = GameState.quest_state.get(quest.id, null)
		if existing != null and not existing is Dictionary:
			GameState.quest_state.erase(quest.id)
		if not GameState.quest_state.has(quest.id) and _prerequisites_met(quest):
			GameState.quest_state[quest.id] = _new_state(quest, STATE_AVAILABLE)
		if get_state_id(quest.id) == STATE_AVAILABLE and quest.auto_start and _prerequisites_met(quest):
			start_quest(quest.id)
	EventBus.quest_list_changed.emit()

func start_quest(quest_id: String) -> bool:
	var quest := DataRegistry.get_quest(quest_id)
	if quest == null or not _prerequisites_met(quest):
		return false
	var state := _get_or_create_state(quest)
	var current := str(state.get("state", STATE_AVAILABLE))
	if current in [STATE_ACTIVE, STATE_UPDATED, STATE_RESOLVED, STATE_ALTERNATE]:
		return current in [STATE_ACTIVE, STATE_UPDATED]
	state["state"] = STATE_ACTIVE
	state["started_day"] = int(GameState.game_time.get("day", 1))
	GameState.quest_state[quest_id] = state
	_sync_inventory_objectives(quest, state)
	quest_started.emit(quest_id)
	EventBus.quest_started.emit(quest_id)
	EventBus.quest_updated.emit(quest_id)
	EventBus.quest_list_changed.emit()
	_check_completion(quest, state)
	return true

func abandon_quest(quest_id: String) -> bool:
	var state := get_state(quest_id)
	if state.is_empty() or str(state.get("state", "")) not in [STATE_ACTIVE, STATE_UPDATED]:
		return false
	state["state"] = STATE_AVAILABLE
	state["progress"] = {}
	GameState.quest_state[quest_id] = state
	EventBus.quest_updated.emit(quest_id)
	EventBus.quest_list_changed.emit()
	return true

func get_state(quest_id: String) -> Dictionary:
	var value: Variant = GameState.quest_state.get(quest_id, {})
	return value if value is Dictionary else {}

func get_state_id(quest_id: String) -> String:
	return str(get_state(quest_id).get("state", ""))

func is_active(quest_id: String) -> bool:
	return get_state_id(quest_id) in [STATE_ACTIVE, STATE_UPDATED]

func get_available_quests() -> Array[QuestData]:
	var result: Array[QuestData] = []
	for value in DataRegistry.get_category("quests"):
		var quest := value as QuestData
		if quest != null and get_state_id(quest.id) == STATE_AVAILABLE:
			result.append(quest)
	return result

func get_active_quests() -> Array[QuestData]:
	var result: Array[QuestData] = []
	for value in DataRegistry.get_category("quests"):
		var quest := value as QuestData
		if quest != null and is_active(quest.id):
			result.append(quest)
	return result

func get_completed_quests() -> Array[QuestData]:
	var result: Array[QuestData] = []
	for value in DataRegistry.get_category("quests"):
		var quest := value as QuestData
		if quest != null and get_state_id(quest.id) in [STATE_RESOLVED, STATE_ALTERNATE]:
			result.append(quest)
	return result

func get_objective_progress(quest_id: String, objective_id: String) -> int:
	var state := get_state(quest_id)
	var progress: Dictionary = state.get("progress", {}) if state.get("progress", {}) is Dictionary else {}
	return int(progress.get(objective_id, 0))

func get_objective_text(quest: QuestData, objective: Dictionary) -> String:
	var label := str(objective.get("text", ""))
	if label.is_empty():
		label = str(objective.get("id", "Objective"))
	var required := maxi(1, int(objective.get("amount", 1)))
	var current := get_objective_progress(quest.id, str(objective.get("id", "")))
	if bool(objective.get("binary", false)) or required == 1:
		return "%s %s" % ["[x]" if current >= required else "[ ]", label]
	return "%s  %d/%d" % [label, mini(current, required), required]

func complete_quest(quest_id: String, outcome_id: String = "default") -> bool:
	var quest := DataRegistry.get_quest(quest_id)
	if quest == null:
		return false
	var state := get_state(quest_id)
	if state.is_empty() or str(state.get("state", "")) not in [STATE_ACTIVE, STATE_UPDATED]:
		return false
	var alternate := outcome_id != "default"
	state["state"] = STATE_ALTERNATE if alternate else STATE_RESOLVED
	state["outcome"] = outcome_id
	state["resolved_day"] = int(GameState.game_time.get("day", 1))
	GameState.quest_state[quest_id] = state
	_apply_rewards(quest, outcome_id)
	quest_completed.emit(quest_id, outcome_id)
	EventBus.quest_resolved.emit(quest_id, outcome_id)
	EventBus.quest_updated.emit(quest_id)
	refresh_availability()
	return true

func fail_quest(quest_id: String) -> void:
	var state := get_state(quest_id)
	if state.is_empty():
		return
	state["state"] = STATE_FAILED
	GameState.quest_state[quest_id] = state
	EventBus.quest_updated.emit(quest_id)
	EventBus.quest_list_changed.emit()

func _new_state(quest: QuestData, state_id: String) -> Dictionary:
	var progress := {}
	for objective_value in quest.objectives:
		if objective_value is Dictionary:
			var objective: Dictionary = objective_value
			progress[str(objective.get("id", ""))] = 0
	return {"state": state_id, "progress": progress, "outcome": "", "started_day": 0, "resolved_day": 0}

func _get_or_create_state(quest: QuestData) -> Dictionary:
	var state := get_state(quest.id)
	if state.is_empty():
		state = _new_state(quest, STATE_AVAILABLE)
	return state

func _prerequisites_met(quest: QuestData) -> bool:
	for prerequisite_id in quest.prerequisite_ids:
		if get_state_id(prerequisite_id) not in [STATE_RESOLVED, STATE_ALTERNATE]:
			return false
	for tag in quest.profile_tag_requirements:
		if not DialogueManager.has_profile_tag(tag):
			return false
	for state_id in quest.world_state_requirements.keys():
		if WorldStateManager.get_value(state_id, null) != quest.world_state_requirements[state_id]:
			return false
	return true

func _increment_matching(event_type: String, target: String = "", amount: int = 1, extra: Dictionary = {}) -> void:
	for quest in get_active_quests():
		var state := get_state(quest.id)
		var changed := false
		for objective_value in quest.objectives:
			if not objective_value is Dictionary:
				continue
			var objective: Dictionary = objective_value
			if str(objective.get("type", "")) != event_type:
				continue
			if not _objective_target_matches(objective, target, extra):
				continue
			var objective_id := str(objective.get("id", ""))
			var required := maxi(1, int(objective.get("amount", 1)))
			var progress: Dictionary = state.get("progress", {}) if state.get("progress", {}) is Dictionary else {}
			var old_value := int(progress.get(objective_id, 0))
			var new_value := mini(required, old_value + amount)
			if new_value != old_value:
				progress[objective_id] = new_value
				state["progress"] = progress
				state["state"] = STATE_UPDATED
				changed = true
				quest_progressed.emit(quest.id, objective_id)
				EventBus.quest_objective_updated.emit(quest.id, objective_id, new_value, required)
		if changed:
			GameState.quest_state[quest.id] = state
			EventBus.quest_updated.emit(quest.id)
			EventBus.quest_list_changed.emit()
			_check_completion(quest, state)

func _objective_target_matches(objective: Dictionary, target: String, extra: Dictionary) -> bool:
	var expected := str(objective.get("target", ""))
	if not expected.is_empty() and expected != target:
		return false
	var raw_conditions: Variant = objective.get("conditions", {})
	if raw_conditions is Dictionary:
		var conditions: Dictionary = raw_conditions
		for key in conditions.keys():
			if extra.get(key, null) != conditions.get(key, null):
				return false
	return true

func _check_completion(quest: QuestData, state: Dictionary) -> void:
	var progress: Dictionary = state.get("progress", {}) if state.get("progress", {}) is Dictionary else {}
	for objective_value in quest.objectives:
		if not objective_value is Dictionary:
			continue
		var objective: Dictionary = objective_value
		if bool(objective.get("optional", false)):
			continue
		var required := maxi(1, int(objective.get("amount", 1)))
		if int(progress.get(str(objective.get("id", "")), 0)) < required:
			return
	var outcome := _resolve_outcome(quest)
	complete_quest(quest.id, outcome)

func _resolve_outcome(quest: QuestData) -> String:
	for branch_value in quest.outcomes:
		if not branch_value is Dictionary:
			continue
		var branch: Dictionary = branch_value
		var conditions: Array = branch.get("conditions", []) as Array
		if conditions is Array and DialogueManager.conditions_met(conditions):
			return str(branch.get("id", "default"))
	return "default"

func _apply_rewards(quest: QuestData, outcome_id: String) -> void:
	var rewards: Array = quest.rewards
	for branch_value in quest.outcomes:
		if branch_value is Dictionary and str((branch_value as Dictionary).get("id", "")) == outcome_id:
			var branch_rewards: Array = (branch_value as Dictionary).get("rewards", []) as Array
			if branch_rewards is Array:
				rewards = rewards + branch_rewards
	for reward_value in rewards:
		if not reward_value is Dictionary:
			continue
		var reward: Dictionary = reward_value
		match str(reward.get("type", "")):
			"item":
				InventoryManager.add_item(str(reward.get("id", "")), int(reward.get("amount", 1)))
			"currency":
				InventoryManager.add_currency(int(reward.get("amount", 0)))
			"profile_tag":
				DialogueManager.add_profile_tag(str(reward.get("id", "")))
			"world_state":
				var state_id := str(reward.get("id", ""))
				var value: Variant = reward.get("value", true)
				WorldStateManager.set_value(state_id, value, "quest_reward")
	EventBus.interaction_message.emit("Quest complete: %s" % quest.display_name)

func _sync_inventory_objectives(quest: QuestData, state: Dictionary) -> void:
	var progress: Dictionary = state.get("progress", {}) if state.get("progress", {}) is Dictionary else {}
	for objective_value in quest.objectives:
		if objective_value is Dictionary:
			var objective: Dictionary = objective_value
			if str(objective.get("type", "")) == "item_collect":
				var objective_id := str(objective.get("id", ""))
				var required := maxi(1, int(objective.get("amount", 1)))
				progress[objective_id] = mini(required, InventoryManager.get_count(str(objective.get("target", ""))))
	state["progress"] = progress
	GameState.quest_state[quest.id] = state

func _on_dialogue_finished(dialogue_id: String) -> void:
	_increment_matching("dialogue", dialogue_id, 1)

func _on_item_added(item_id: String, amount: int) -> void:
	_increment_matching("item_collect", item_id, amount)

func _on_resource_gathered(item_id: String, amount: int) -> void:
	_increment_matching("gather", item_id, amount)

func _on_monster_captured(monster_instance_id: String) -> void:
	var monster := MonsterManager.find_monster(monster_instance_id)
	if monster != null:
		_increment_matching("capture", monster.species_id, 1)

func _on_battle_finished(result: Dictionary) -> void:
	if str(result.get("outcome", "")) == "victory":
		_increment_matching("battle_win", str(result.get("enemy_species_id", "")), 1)

func _on_crop_harvested(_cell_key: String, crop_id: String, amount: int) -> void:
	_increment_matching("harvest", crop_id, amount)

func _on_map_entered(map_id: String, _display_name: String) -> void:
	_increment_matching("map_enter", map_id, 1)

func _on_waystone_discovered(waystone_id: String) -> void:
	_increment_matching("waystone", waystone_id, 1)

func _on_profile_tag_changed(tag_id: String, added: bool) -> void:
	if added:
		_increment_matching("profile_tag", tag_id, 1)
	refresh_availability()

func _on_world_state_changed(state_id: String, value: Variant) -> void:
	_increment_matching("world_state", state_id, 1, {"value": value})
	refresh_availability()
