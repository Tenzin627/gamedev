extends GameDataDefinition
class_name CropData

@export_range(1, 999999, 1) var growth_minutes: int = 60
@export_range(1, 99, 1) var base_yield: int = 1
@export var season_ids: Array[String] = []
@export var seed_item_id: String = ""
@export var harvest_item_id: String = ""
@export var watering_required: bool = true
@export var growth_stage_count: int = 4
