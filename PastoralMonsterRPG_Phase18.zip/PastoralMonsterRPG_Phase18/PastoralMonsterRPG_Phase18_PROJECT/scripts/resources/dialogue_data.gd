extends GameDataDefinition
class_name DialogueData

@export var start_node_id: String = "start"
@export var start_rules: Array[Dictionary] = []
@export var nodes: Array[Dictionary] = []

func get_node_data(node_id: String) -> Dictionary:
	for node_data in nodes:
		if str(node_data.get("id", "")) == node_id:
			return node_data
	return {}

func get_node_ids() -> Array[String]:
	var result: Array[String] = []
	for node_data in nodes:
		var node_id := str(node_data.get("id", ""))
		if not node_id.is_empty():
			result.append(node_id)
	return result
