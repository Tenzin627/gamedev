extends GameDataDefinition
class_name EncounterData

@export var region_id: String = ""
@export var entries: Array[Dictionary] = []
@export var conditions: Dictionary = {}
