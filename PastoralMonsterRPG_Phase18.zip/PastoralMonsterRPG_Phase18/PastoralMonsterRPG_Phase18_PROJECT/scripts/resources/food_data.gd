extends GameDataDefinition
class_name FoodData

@export var item_id: String = ""
@export var development_properties: Dictionary = {}
@export var reaction_tags: Array[String] = []
@export var recovery_amount: int = 0
