extends Resource
class_name GameDataDefinition

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var tags: Array[String] = []
@export var enabled: bool = true
