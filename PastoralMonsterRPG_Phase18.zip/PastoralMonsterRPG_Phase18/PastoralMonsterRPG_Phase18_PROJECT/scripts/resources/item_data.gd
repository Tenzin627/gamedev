extends GameDataDefinition
class_name ItemData

@export var category: StringName
@export_range(1, 9999, 1) var stack_limit: int = 99
@export var base_value: int = 0
@export var usable: bool = false
@export var use_effect_id: String = ""
@export var icon: Texture2D
