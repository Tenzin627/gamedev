extends GameDataDefinition
class_name MonsterSpeciesData

@export var archetype: StringName
@export var habitat_tags: Array[String] = []
@export var base_stats: Dictionary = {
	"hp": 10,
	"attack": 5,
	"defense": 5,
	"speed": 5
}
@export var move_ids: Array[String] = []
@export var move_unlock_rules: Array[Dictionary] = []
@export var trait_ids: Array[String] = []
@export var evolution_species_ids: Array[String] = []
@export var evolution_rules: Array[Dictionary] = []
@export var favorite_food_tags: Array[String] = []
@export var disliked_food_tags: Array[String] = []
@export var visual_data: Dictionary = {}
