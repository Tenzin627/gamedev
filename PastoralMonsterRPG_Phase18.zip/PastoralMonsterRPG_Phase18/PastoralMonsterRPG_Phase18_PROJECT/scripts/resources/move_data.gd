extends GameDataDefinition
class_name MoveData

@export var element: StringName = &"neutral"
@export var power: int = 0
@export var accuracy: float = 1.0
@export var cooldown_turns: int = 0
@export var priority: int = 0
@export var effect_id: String = ""
@export var effect_parameters: Dictionary = {}
