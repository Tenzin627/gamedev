extends GameDataDefinition
class_name NPCData

@export var role: StringName
@export var profile_tags: Array[String] = []
@export var default_dialogue_id: String = ""
@export var home_map_id: String = ""
@export var partner_monster_id: String = ""
