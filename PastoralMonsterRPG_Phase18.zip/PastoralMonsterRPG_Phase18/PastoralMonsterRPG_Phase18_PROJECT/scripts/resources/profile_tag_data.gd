extends GameDataDefinition
class_name ProfileTagData

@export var tag_key: String = ""
@export var category: StringName = &"identity"
@export var short_label: String = ""
@export_multiline var unlock_hint: String = ""
@export var milestone_type: StringName = &""
@export var milestone_threshold: int = 0
@export var sort_order: int = 0
