extends GameDataDefinition
class_name QuestData

@export var quest_type: StringName = &"side"
@export var prerequisite_ids: Array[String] = []
@export var objectives: Array[Dictionary] = []
@export var rewards: Array[Dictionary] = []
@export var outcomes: Array[Dictionary] = []
@export var profile_tag_requirements: Array[String] = []
@export var world_state_requirements: Dictionary = {}
@export var repeatable: bool = false
@export var missable: bool = false
@export var auto_start: bool = false
