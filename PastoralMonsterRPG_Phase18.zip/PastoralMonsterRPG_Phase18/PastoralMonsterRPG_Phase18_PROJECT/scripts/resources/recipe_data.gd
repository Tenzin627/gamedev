extends GameDataDefinition
class_name RecipeData

@export var ingredients: Dictionary = {}
@export var output_item_id: String = ""
@export_range(1, 99, 1) var output_amount: int = 1
@export var processing_minutes: int = 0
@export var station_id: StringName = &"kitchen"
