extends GameDataDefinition
class_name TrainerData

@export var npc_id: String = ""
@export var difficulty: StringName = &"beginner"
@export var team: Array[Dictionary] = []
@export_multiline var purpose: String = ""
@export var optional: bool = false
