extends GameDataDefinition
class_name TraitData

@export var trigger_id: String = ""
@export var effect_id: String = ""
@export var parameters: Dictionary = {}
