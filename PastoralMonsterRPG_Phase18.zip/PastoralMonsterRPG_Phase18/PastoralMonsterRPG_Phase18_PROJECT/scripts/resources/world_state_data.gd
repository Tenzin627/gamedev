extends GameDataDefinition
class_name WorldStateData

@export var default_value: Variant = false
@export var persistent: bool = true
