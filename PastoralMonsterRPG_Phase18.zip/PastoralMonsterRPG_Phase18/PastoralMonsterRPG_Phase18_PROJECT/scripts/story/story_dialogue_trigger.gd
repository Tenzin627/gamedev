extends Interactable
class_name StoryDialogueTrigger

@export var dialogue_id: String = ""
@export var speaker_name: String = ""
@export var required_quest_id: String = ""
@export var required_world_state_id: String = ""
@export var required_world_state_value: Variant = true
@export var completed_world_state_id: String = ""
@export var hide_when_completed: bool = false

func _ready() -> void:
	EventBus.quest_updated.connect(_on_condition_changed)
	EventBus.world_state_changed.connect(_on_world_state_changed)
	_refresh_enabled()

func can_interact(interactor: Node) -> bool:
	return super.can_interact(interactor) and _conditions_met()

func interact(interactor: Node) -> void:
	if not can_interact(interactor):
		EventBus.interaction_message.emit("There is nothing more to learn here yet.")
		return
	interaction_started.emit(interactor)
	var context := {"speaker_name": speaker_name, "trigger_path": str(get_path())}
	if not DialogueManager.start_dialogue(dialogue_id, context):
		EventBus.interaction_message.emit("Story dialogue could not be started.")
	interaction_finished.emit(interactor)

func _conditions_met() -> bool:
	if not required_quest_id.is_empty() and not QuestManager.is_active(required_quest_id):
		return false
	if not required_world_state_id.is_empty():
		if WorldStateManager.get_value(required_world_state_id, null) != required_world_state_value:
			return false
	if not completed_world_state_id.is_empty() and bool(WorldStateManager.get_value(completed_world_state_id, false)):
		return false
	return true

func _refresh_enabled() -> void:
	enabled = _conditions_met()
	if hide_when_completed and not completed_world_state_id.is_empty():
		visible = not bool(WorldStateManager.get_value(completed_world_state_id, false))

func _on_condition_changed(_quest_id: String) -> void:
	_refresh_enabled()

func _on_world_state_changed(_state_id: String, _value: Variant) -> void:
	_refresh_enabled()
