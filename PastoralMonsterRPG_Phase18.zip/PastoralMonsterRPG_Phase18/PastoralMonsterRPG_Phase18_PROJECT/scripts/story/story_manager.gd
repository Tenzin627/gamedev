extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

const HOME_VILLAGE := "map.home_village"
const GOLDEN_FOREST_EDGE := "map.golden_forest_edge"
const OPENING_DIALOGUE := "dialogue.story.childhood_spirit_opening"
const GOLDEN_HOOK_DIALOGUE := "dialogue.story.golden_forest_hook"
const VILLAGE_ELDER_DIALOGUE := "dialogue.village_elder.default"

var _pending_opening := false
var _pending_hook := false

func _ready() -> void:
	EventBus.map_entered.connect(_on_map_entered)
	EventBus.dialogue_finished.connect(_on_dialogue_finished)
	EventBus.game_loaded.connect(_on_game_loaded)
	EventBus.game_started.connect(_on_game_started)
	call_deferred("_refresh_story")

func _on_game_loaded() -> void:
	call_deferred("_refresh_story")

func _on_game_started() -> void:
	call_deferred("_refresh_story")

func _refresh_story() -> void:
	QuestManager.refresh_availability()

func _on_map_entered(map_id: String, _display_name: String) -> void:
	if map_id == HOME_VILLAGE and not bool(WorldStateManager.get_value("world.story.opening_seen", false)):
		_pending_opening = true
		call_deferred("_try_opening_dialogue")
	elif map_id == GOLDEN_FOREST_EDGE and not bool(WorldStateManager.get_value("world.story.golden_forest_hook_seen", false)):
		_pending_hook = true
		call_deferred("_try_hook_dialogue")

func _try_opening_dialogue() -> void:
	if not _pending_opening or DialogueManager.is_active():
		return
	_pending_opening = false
	if DialogueManager.start_dialogue(OPENING_DIALOGUE, {"speaker_name": "Childhood Spirit"}):
		DevLog.info("STORY", "Opening Childhood Spirit dialogue started.")

func _try_hook_dialogue() -> void:
	if not _pending_hook or DialogueManager.is_active():
		return
	_pending_hook = false
	if DialogueManager.start_dialogue(GOLDEN_HOOK_DIALOGUE, {"speaker_name": "Childhood Spirit"}):
		DevLog.info("STORY", "Golden Forest hook dialogue started.")

func _on_dialogue_finished(dialogue_id: String) -> void:
	if dialogue_id == OPENING_DIALOGUE:
		WorldStateManager.set_value("world.story.opening_seen", true, "story")
	elif dialogue_id == GOLDEN_HOOK_DIALOGUE:
		WorldStateManager.set_value("world.story.golden_forest_hook_seen", true, "story")

	# Compatibility/progression safeguard: speaking with the Village Elder always
	# opens the eastern wilderness path. This supports the Phase 17 story flow
	# as well as older saves or the legacy First Steps test quest.
	if dialogue_id == VILLAGE_ELDER_DIALOGUE:
		WorldStateManager.set_value("world.home_wilderness_open", true, "village_elder_dialogue")
