extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

const MINUTES_PER_DAY := 1440
const DAYS_PER_SEASON := 28
const SEASONS: Array[String] = ["spring", "summer", "autumn", "winter"]
const WEATHER_IDS: Array[String] = ["clear", "cloudy", "rain", "fog"]

# Development-friendly default: one real second advances two game minutes.
# Set this to 1.0 for one real second per game minute, or expose it in settings later.
@export var real_seconds_per_game_minute: float = 0.5

var time_scale: float = 1.0
var _minute_accumulator: float = 0.0
var _last_hour: int = -1
var _last_period: String = ""

func _ready() -> void:
	ensure_time_state()
	EventBus.game_loaded.connect(_on_game_loaded)
	EventBus.game_started.connect(_on_game_started)
	_last_hour = get_hour()
	_last_period = get_time_period()
	_sync_weather_mirror()

func _process(delta: float) -> void:
	if BattleManager.is_battle_active():
		return
	if real_seconds_per_game_minute <= 0.0 or time_scale <= 0.0:
		return
	_minute_accumulator += (delta * time_scale) / real_seconds_per_game_minute
	var whole_minutes := int(floor(_minute_accumulator))
	if whole_minutes > 0:
		_minute_accumulator -= float(whole_minutes)
		advance_minutes(whole_minutes)

func ensure_time_state() -> void:
	if GameState.game_time.is_empty():
		GameState.game_time = {}
	if not GameState.game_time.has("day"):
		GameState.game_time["day"] = 1
	if not GameState.game_time.has("minute_of_day"):
		GameState.game_time["minute_of_day"] = 480
	if not GameState.game_time.has("season"):
		GameState.game_time["season"] = "spring"
	if not GameState.game_time.has("season_day"):
		GameState.game_time["season_day"] = 1
	if not GameState.game_time.has("weather"):
		GameState.game_time["weather"] = "clear"
	_recalculate_season_fields(false)
	_sync_weather_mirror()

func reset_to_default() -> void:
	GameState.game_time = {
		"day": 1,
		"minute_of_day": 480,
		"season": "spring",
		"season_day": 1,
		"weather": "clear"
	}
	_minute_accumulator = 0.0
	_last_hour = get_hour()
	_last_period = get_time_period()
	_sync_weather_mirror()
	_emit_full_state()

func advance_minutes(minutes: int) -> void:
	if minutes <= 0:
		return
	ensure_time_state()
	var remaining := minutes
	while remaining > 0:
		var current_minute := int(GameState.game_time.get("minute_of_day", 480))
		var until_midnight := MINUTES_PER_DAY - current_minute
		var step := mini(remaining, until_midnight)
		GameState.game_time["minute_of_day"] = current_minute + step
		remaining -= step
		EventBus.game_minutes_advanced.emit(step)
		_emit_hour_and_period_changes()
		if int(GameState.game_time["minute_of_day"]) >= MINUTES_PER_DAY:
			GameState.game_time["minute_of_day"] = 0
			_advance_day()
			_emit_hour_and_period_changes()
	EventBus.time_changed.emit(get_day(), get_minute_of_day())

func advance_hours(hours: int) -> void:
	advance_minutes(maxi(0, hours) * 60)

func advance_day() -> void:
	var until_midnight := MINUTES_PER_DAY - get_minute_of_day()
	advance_minutes(until_midnight if until_midnight > 0 else MINUTES_PER_DAY)

func advance_to_next_season() -> void:
	var season_day := get_season_day()
	var days_to_advance := DAYS_PER_SEASON - season_day + 1
	for _index in range(days_to_advance):
		advance_day()

func set_time(hour: int, minute: int = 0) -> void:
	ensure_time_state()
	var clamped_hour := clampi(hour, 0, 23)
	var clamped_minute := clampi(minute, 0, 59)
	GameState.game_time["minute_of_day"] = clamped_hour * 60 + clamped_minute
	_last_hour = get_hour()
	_last_period = get_time_period()
	EventBus.time_changed.emit(get_day(), get_minute_of_day())
	EventBus.hour_changed.emit(_last_hour)
	EventBus.time_period_changed.emit(_last_period)

func set_weather(weather_id: String, announce: bool = true) -> void:
	if weather_id not in WEATHER_IDS:
		return
	ensure_time_state()
	var previous := get_weather_id()
	GameState.game_time["weather"] = weather_id
	_sync_weather_mirror()
	if previous != weather_id:
		EventBus.weather_changed.emit(weather_id)
		if announce:
			EventBus.interaction_message.emit("Weather changed: %s." % weather_id.capitalize())

func cycle_weather_debug() -> void:
	var current_index := WEATHER_IDS.find(get_weather_id())
	var next_index := (current_index + 1) % WEATHER_IDS.size()
	set_weather(WEATHER_IDS[next_index])

func set_time_scale(multiplier: float) -> void:
	time_scale = clampf(multiplier, 0.0, 120.0)
	EventBus.time_scale_changed.emit(time_scale)

func toggle_debug_speed() -> void:
	set_time_scale(10.0 if is_equal_approx(time_scale, 1.0) else 1.0)

func get_day() -> int:
	return maxi(1, int(GameState.game_time.get("day", 1)))

func get_minute_of_day() -> int:
	return clampi(int(GameState.game_time.get("minute_of_day", 480)), 0, MINUTES_PER_DAY - 1)

func get_hour() -> int:
	return int(get_minute_of_day() / 60)

func get_minute() -> int:
	return get_minute_of_day() % 60

func get_season_id() -> String:
	return String(GameState.game_time.get("season", "spring"))

func get_season_day() -> int:
	return clampi(int(GameState.game_time.get("season_day", 1)), 1, DAYS_PER_SEASON)

func get_weather_id() -> String:
	return String(GameState.game_time.get("weather", "clear"))

func get_time_period() -> String:
	var minute := get_minute_of_day()
	if minute >= 300 and minute < 420:
		return "dawn"
	if minute >= 420 and minute < 1080:
		return "day"
	if minute >= 1080 and minute < 1200:
		return "dusk"
	return "night"

func get_encounter_time_tag() -> String:
	var minute := get_minute_of_day()
	return "day" if minute >= 360 and minute < 1200 else "night"

func format_time_24h() -> String:
	return "%02d:%02d" % [get_hour(), get_minute()]

func get_display_date() -> String:
	return "%s %d, Day %d" % [get_season_id().capitalize(), get_season_day(), get_day()]

func get_context() -> Dictionary:
	return {
		"time": get_encounter_time_tag(),
		"time_period": get_time_period(),
		"season": get_season_id(),
		"weather": get_weather_id(),
		"day": get_day(),
		"season_day": get_season_day(),
		"minute_of_day": get_minute_of_day(),
		"map_id": GameState.current_map_id
	}

func _advance_day() -> void:
	GameState.game_time["day"] = get_day() + 1
	_recalculate_season_fields(true)
	_roll_daily_weather()
	EventBus.day_changed.emit(get_day())
	DevLog.info("TIME", "Day %d began: %s %d, %s." % [get_day(), get_season_id(), get_season_day(), get_weather_id()])

func _recalculate_season_fields(emit_change: bool) -> void:
	var day_zero := maxi(0, get_day() - 1)
	var season_index := int(floor(float(day_zero) / float(DAYS_PER_SEASON))) % SEASONS.size()
	var new_season := SEASONS[season_index]
	var new_season_day := (day_zero % DAYS_PER_SEASON) + 1
	var previous := String(GameState.game_time.get("season", "spring"))
	GameState.game_time["season"] = new_season
	GameState.game_time["season_day"] = new_season_day
	if emit_change and previous != new_season:
		EventBus.season_changed.emit(new_season, new_season_day)

func _roll_daily_weather() -> void:
	var roll := randf()
	var season := get_season_id()
	var weather := "clear"
	match season:
		"spring":
			weather = _weighted_weather(roll, 0.50, 0.25, 0.20, 0.05)
		"summer":
			weather = _weighted_weather(roll, 0.65, 0.20, 0.12, 0.03)
		"autumn":
			weather = _weighted_weather(roll, 0.45, 0.30, 0.15, 0.10)
		"winter":
			weather = _weighted_weather(roll, 0.40, 0.35, 0.10, 0.15)
	set_weather(weather, false)

func _weighted_weather(roll: float, clear_weight: float, cloudy_weight: float, rain_weight: float, _fog_weight: float) -> String:
	if roll < clear_weight:
		return "clear"
	if roll < clear_weight + cloudy_weight:
		return "cloudy"
	if roll < clear_weight + cloudy_weight + rain_weight:
		return "rain"
	return "fog"

func _emit_hour_and_period_changes() -> void:
	var current_hour := get_hour()
	if current_hour != _last_hour:
		_last_hour = current_hour
		EventBus.hour_changed.emit(current_hour)
	var current_period := get_time_period()
	if current_period != _last_period:
		_last_period = current_period
		EventBus.time_period_changed.emit(current_period)

func _sync_weather_mirror() -> void:
	GameState.world_state["weather"] = get_weather_id()

func _emit_full_state() -> void:
	EventBus.time_changed.emit(get_day(), get_minute_of_day())
	EventBus.hour_changed.emit(get_hour())
	EventBus.time_period_changed.emit(get_time_period())
	EventBus.season_changed.emit(get_season_id(), get_season_day())
	EventBus.weather_changed.emit(get_weather_id())

func _on_game_loaded() -> void:
	ensure_time_state()
	_last_hour = get_hour()
	_last_period = get_time_period()
	_emit_full_state()

func _on_game_started() -> void:
	ensure_time_state()
	_emit_full_state()
