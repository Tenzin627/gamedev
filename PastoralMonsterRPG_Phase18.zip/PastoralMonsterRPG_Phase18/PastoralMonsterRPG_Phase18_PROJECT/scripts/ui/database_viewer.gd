extends PanelContainer

@onready var summary_label: Label = %SummaryLabel
@onready var category_list: ItemList = %CategoryList
@onready var definition_list: ItemList = %DefinitionList
@onready var details_label: RichTextLabel = %DetailsLabel
@onready var validation_label: RichTextLabel = %ValidationLabel

var _categories: Array[String] = []
var _current_definitions: Array = []

func _ready() -> void:
	category_list.item_selected.connect(_on_category_selected)
	definition_list.item_selected.connect(_on_definition_selected)
	%ReloadButton.pressed.connect(_on_reload_pressed)
	DataRegistry.data_loaded.connect(_refresh)
	_refresh(DataRegistry.get_last_report().get("count", 0))

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("debug_database"):
		visible = not visible
		if visible:
			_refresh(DataRegistry.get_last_report().get("count", 0))
		get_viewport().set_input_as_handled()

func _refresh(_count: int = 0) -> void:
	var counts := DataRegistry.get_category_counts()
	var total := 0
	for value in counts.values():
		total += int(value)
	summary_label.text = "Phase 3 Data Registry — %d definitions" % total

	_categories.clear()
	for category in DataRegistry.CATEGORY_PATHS.keys():
		_categories.append(str(category))
	_categories.sort()
	category_list.clear()
	for category in _categories:
		category_list.add_item("%s (%d)" % [category.capitalize(), int(counts.get(category, 0))])

	if not _categories.is_empty():
		category_list.select(0)
		_show_category(_categories[0])
	_show_validation()

func _on_category_selected(index: int) -> void:
	if index >= 0 and index < _categories.size():
		_show_category(_categories[index])

func _show_category(category: String) -> void:
	_current_definitions = DataRegistry.get_category(category)
	_current_definitions.sort_custom(func(a, b): return str(a.id) < str(b.id))
	definition_list.clear()
	for definition in _current_definitions:
		definition_list.add_item("%s  —  %s" % [definition.id, definition.display_name])
	if not _current_definitions.is_empty():
		definition_list.select(0)
		_show_definition(_current_definitions[0])
	else:
		details_label.text = "[i]No definitions in this category.[/i]"

func _on_definition_selected(index: int) -> void:
	if index >= 0 and index < _current_definitions.size():
		_show_definition(_current_definitions[index])

func _show_definition(definition: GameDataDefinition) -> void:
	var lines: Array[String] = []
	lines.append("[b]%s[/b]" % definition.display_name)
	lines.append("[code]%s[/code]" % definition.id)
	lines.append("")
	lines.append(definition.description)
	lines.append("")
	lines.append("[b]Resource[/b]: %s" % definition.resource_path)
	if not definition.tags.is_empty():
		lines.append("[b]Tags[/b]: %s" % ", ".join(definition.tags))
	details_label.text = "\n".join(lines)

func _show_validation() -> void:
	var report := DataRegistry.get_last_report()
	var errors: Array = report.get("errors", [])
	var warnings: Array = report.get("warnings", [])
	var lines: Array[String] = []
	if errors.is_empty() and warnings.is_empty():
		lines.append("[color=green][b]VALID[/b][/color] — all registered data passed validation.")
	else:
		if not errors.is_empty():
			lines.append("[color=red][b]%d ERROR(S)[/b][/color]" % errors.size())
			for error in errors:
				lines.append("• %s" % error)
		if not warnings.is_empty():
			lines.append("[color=yellow][b]%d WARNING(S)[/b][/color]" % warnings.size())
			for warning in warnings:
				lines.append("• %s" % warning)
	validation_label.text = "\n".join(lines)

func _on_reload_pressed() -> void:
	DataRegistry.reload_all()
