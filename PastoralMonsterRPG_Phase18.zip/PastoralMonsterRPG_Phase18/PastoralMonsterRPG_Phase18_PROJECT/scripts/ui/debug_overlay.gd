extends MarginContainer

@onready var fps_label: Label = %FPSLabel
@onready var scene_label: Label = %SceneLabel
@onready var position_label: Label = %PositionLabel
@onready var version_label: Label = %VersionLabel
@onready var time_scale_label: Label = %TimeScaleLabel

var _accumulator: float = 0.0

func _ready() -> void:
	version_label.text = "Version: %s" % Game.GAME_VERSION

func _process(delta: float) -> void:
	_accumulator += delta
	if _accumulator < 0.2:
		return
	_accumulator = 0.0
	_refresh()

func _refresh() -> void:
	fps_label.text = "FPS: %d" % Engine.get_frames_per_second()
	var scene_path := SceneManager.get_current_scene_path()
	scene_label.text = "Scene: %s" % (scene_path if not scene_path.is_empty() else "<none>")
	time_scale_label.text = "Time Scale: %.1fx" % Engine.time_scale

	var player := get_tree().get_first_node_in_group("player")
	if player is Node2D:
		position_label.text = "Player: (%.1f, %.1f)" % [player.global_position.x, player.global_position.y]
	else:
		position_label.text = "Player: <not spawned>"
