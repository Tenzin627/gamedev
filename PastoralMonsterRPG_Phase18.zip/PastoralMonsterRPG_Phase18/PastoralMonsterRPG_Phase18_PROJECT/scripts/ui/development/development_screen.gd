extends Control

var _monster_ids: Array[String] = []
var _food_item_ids: Array[String] = []
var _selected_move_ids: Array[String] = []

var _monster_option: OptionButton
var _food_option: OptionButton
var _move_option: OptionButton
var _slot_option: OptionButton
var _details: RichTextLabel
var _status: Label
var _feed_button: Button
var _equip_button: Button

func _ready() -> void:
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build_ui()
	EventBus.inventory_changed.connect(_refresh_if_visible)
	EventBus.monster_party_changed.connect(_refresh_if_visible)
	EventBus.monster_storage_changed.connect(_refresh_if_visible)
	EventBus.monster_fed.connect(_on_monster_fed)

func open() -> void:
	visible = true
	_refresh_all()
	if _monster_option != null:
		_monster_option.grab_focus()

func close() -> void:
	visible = false

func toggle() -> void:
	if visible: close()
	else: open()

func _unhandled_input(event: InputEvent) -> void:
	if not visible:
		return
	if event.is_action_pressed("cancel"):
		close()
		get_viewport().set_input_as_handled()

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.color = Color(0.03, 0.04, 0.03, 0.78)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(shade)

	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-450, -330)
	panel.size = Vector2(900, 660)
	add_child(panel)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	panel.add_child(root)

	var title := Label.new()
	title.text = "Monster Feeding & Development"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 26)
	root.add_child(title)

	var row := HBoxContainer.new()
	root.add_child(row)
	var monster_label := Label.new(); monster_label.text = "Monster:"; row.add_child(monster_label)
	_monster_option = OptionButton.new(); _monster_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL; row.add_child(_monster_option)
	_monster_option.item_selected.connect(_on_selection_changed)

	var food_row := HBoxContainer.new(); root.add_child(food_row)
	var food_label := Label.new(); food_label.text = "Food:"; food_row.add_child(food_label)
	_food_option = OptionButton.new(); _food_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL; food_row.add_child(_food_option)
	_food_option.item_selected.connect(_on_food_changed)
	_feed_button = Button.new(); _feed_button.text = "Feed"; food_row.add_child(_feed_button)
	_feed_button.pressed.connect(_on_feed_pressed)

	_details = RichTextLabel.new()
	_details.bbcode_enabled = true
	_details.fit_content = false
	_details.custom_minimum_size = Vector2(0, 390)
	_details.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(_details)

	var move_row := HBoxContainer.new(); root.add_child(move_row)
	var move_label := Label.new(); move_label.text = "Move:"; move_row.add_child(move_label)
	_move_option = OptionButton.new(); _move_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL; move_row.add_child(_move_option)
	_slot_option = OptionButton.new(); move_row.add_child(_slot_option)
	_slot_option.add_item("Auto")
	for i in range(MonsterInstance.MAX_MOVE_SLOTS): _slot_option.add_item("Slot %d" % (i + 1))
	_equip_button = Button.new(); _equip_button.text = "Equip"; move_row.add_child(_equip_button)
	_equip_button.pressed.connect(_on_equip_pressed)

	_status = Label.new()
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.custom_minimum_size = Vector2(0, 42)
	root.add_child(_status)

	var close_button := Button.new(); close_button.text = "Close (Esc)"; root.add_child(close_button)
	close_button.pressed.connect(close)

func _refresh_all() -> void:
	_refresh_monsters()
	_refresh_foods()
	_refresh_details()

func _refresh_monsters() -> void:
	if _monster_option == null: return
	var previous := _current_monster_id()
	_monster_option.clear(); _monster_ids.clear()
	for monster in MonsterManager.get_party(): _add_monster_option(monster, "Party")
	for monster in MonsterManager.get_farm_storage(): _add_monster_option(monster, "Farm")
	if not previous.is_empty() and previous in _monster_ids:
		_monster_option.select(_monster_ids.find(previous))

func _add_monster_option(monster: MonsterInstance, location: String) -> void:
	_monster_ids.append(monster.instance_id)
	_monster_option.add_item("%s — Lv.%d (%s)" % [monster.get_display_name(), monster.level, location])

func _refresh_foods() -> void:
	if _food_option == null: return
	var previous := _current_food_item_id()
	_food_option.clear(); _food_item_ids.clear()
	for item_id in DevelopmentManager.get_available_food_item_ids():
		var item := DataRegistry.get_item(item_id)
		var food := DevelopmentManager.get_food_for_item(item_id)
		if item == null or food == null: continue
		_food_item_ids.append(item_id)
		_food_option.add_item("%s ×%d" % [item.display_name, InventoryManager.get_count(item_id)])
	if not previous.is_empty() and previous in _food_item_ids:
		_food_option.select(_food_item_ids.find(previous))
	_feed_button.disabled = _food_item_ids.is_empty() or _monster_ids.is_empty()

func _refresh_details() -> void:
	if _details == null: return
	var monster := MonsterManager.find_monster(_current_monster_id())
	if monster == null:
		_details.text = "[center]No monster available.[/center]"
		_refresh_moves(null)
		return
	var species := monster.get_species()
	var dominant := DevelopmentManager.get_dominant_tendency(monster)
	var lines: Array[String] = []
	lines.append("[font_size=24][b]%s[/b][/font_size]  Lv.%d" % [monster.get_display_name(), monster.level])
	lines.append("Species: %s" % (species.display_name if species else monster.species_id))
	lines.append("HP: %d / %d" % [monster.current_hp, monster.get_max_hp()])
	lines.append("")
	lines.append("[b]Development Tendencies[/b]")
	var tendencies: Array[String] = []
	for key in monster.development.keys(): tendencies.append(str(key))
	tendencies.sort()
	for tendency in tendencies:
		lines.append("• %s: %d" % [tendency.capitalize(), int(monster.development[tendency])])
	lines.append("Dominant: %s%s" % [str(dominant.get("tendency", "")).capitalize(), " (tie)" if bool(dominant.get("tied", false)) else ""])
	lines.append("")
	lines.append("[b]Food Reaction[/b]")
	var food := DevelopmentManager.get_food_for_item(_current_food_item_id())
	if food != null:
		lines.append("Selected food: %s — %s" % [food.display_name, DevelopmentManager.get_food_reaction(monster, food).capitalize()])
		var props: Array[String] = []
		for key in food.development_properties.keys(): props.append("%s +%d" % [str(key).capitalize(), int(food.development_properties[key])])
		lines.append("Base development: %s" % ", ".join(props))
	else:
		lines.append("No feedable food in inventory.")
	lines.append("")
	lines.append("[b]Development Move Progress[/b]")
	var progress := DevelopmentManager.get_move_progress(monster)
	if progress.is_empty(): lines.append("No development-gated moves for this species.")
	for entry in progress:
		var move := DataRegistry.get_move(str(entry.get("move_id", "")))
		var name := move.display_name if move else str(entry.get("move_id", ""))
		var state := "UNLOCKED" if bool(entry.get("unlocked", false)) else "%d / %d %s" % [int(entry.get("current", 0)), int(entry.get("threshold", 0)), str(entry.get("tendency", "")).capitalize()]
		lines.append("• %s — %s" % [name, state])
	_details.text = "\n".join(lines)
	_refresh_moves(monster)

func _refresh_moves(monster: MonsterInstance) -> void:
	_move_option.clear(); _selected_move_ids.clear()
	if monster == null:
		_equip_button.disabled = true
		return
	for move_id in monster.unlocked_move_ids:
		var move := DataRegistry.get_move(move_id)
		if move == null: continue
		_selected_move_ids.append(move_id)
		var equipped := " [Equipped]" if move_id in monster.equipped_move_ids else ""
		_move_option.add_item(move.display_name + equipped)
	_equip_button.disabled = _selected_move_ids.is_empty()

func _current_monster_id() -> String:
	if _monster_option == null or _monster_option.selected < 0 or _monster_option.selected >= _monster_ids.size(): return ""
	return _monster_ids[_monster_option.selected]

func _current_food_item_id() -> String:
	if _food_option == null or _food_option.selected < 0 or _food_option.selected >= _food_item_ids.size(): return ""
	return _food_item_ids[_food_option.selected]

func _on_selection_changed(_index: int) -> void: _refresh_details()
func _on_food_changed(_index: int) -> void: _refresh_details()

func _on_feed_pressed() -> void:
	var result := DevelopmentManager.feed_monster(_current_monster_id(), _current_food_item_id())
	_status.text = str(result.get("message", ""))
	_refresh_all()

func _on_equip_pressed() -> void:
	if _move_option.selected < 0 or _move_option.selected >= _selected_move_ids.size(): return
	var slot := _slot_option.selected - 1
	var result := DevelopmentManager.equip_unlocked_move(_current_monster_id(), _selected_move_ids[_move_option.selected], slot)
	_status.text = str(result.get("message", ""))
	_refresh_details()

func _refresh_if_visible() -> void:
	if visible: _refresh_all()

func _on_monster_fed(_instance_id: String, _food_id: String, _reaction: String, _gained: Dictionary) -> void:
	if visible: _refresh_all()
