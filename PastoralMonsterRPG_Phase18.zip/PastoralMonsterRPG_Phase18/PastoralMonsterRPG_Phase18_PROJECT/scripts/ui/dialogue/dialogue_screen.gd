extends Control
class_name DialogueScreen

var _manager: Node = null
var _speaker_label: Label
var _text_label: RichTextLabel
var _continue_label: Label
var _choices_box: VBoxContainer
var _choice_buttons: Array[Button] = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_ui()
	visible = false

func bind_manager(manager: Node) -> void:
	_manager = manager

func show_dialogue_node(speaker: String, text: String, choices: Array[Dictionary]) -> void:
	if not is_instance_valid(_speaker_label):
		return
	_speaker_label.text = speaker
	_text_label.text = text
	_clear_choices()
	for index in range(choices.size()):
		var choice: Dictionary = choices[index]
		var button := Button.new()
		button.text = str(choice.get("text", "..."))
		button.custom_minimum_size = Vector2(0, 48)
		button.focus_mode = Control.FOCUS_ALL
		button.pressed.connect(_on_choice_pressed.bind(index))
		_choices_box.add_child(button)
		_choice_buttons.append(button)
	_continue_label.visible = choices.is_empty()
	if not _choice_buttons.is_empty():
		_choice_buttons[0].grab_focus()

func _unhandled_input(event: InputEvent) -> void:
	if not visible or _manager == null:
		return
	if event.is_action_pressed("cancel"):
		_manager.close_dialogue()
		get_viewport().set_input_as_handled()
	elif _choice_buttons.is_empty() and (event.is_action_pressed("interact") or event.is_action_pressed("confirm")):
		_manager.advance()
		get_viewport().set_input_as_handled()

func _on_choice_pressed(index: int) -> void:
	if _manager != null:
		_manager.choose(index)

func _clear_choices() -> void:
	_choice_buttons.clear()
	for child in _choices_box.get_children():
		child.queue_free()

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var shade := ColorRect.new()
	shade.color = Color(0.03, 0.04, 0.025, 0.24)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)

	var panel := PanelContainer.new()
	panel.name = "DialoguePanel"
	panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	panel.offset_left = -660
	panel.offset_right = 660
	panel.offset_top = -350
	panel.offset_bottom = -42
	add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 30)
	margin.add_theme_constant_override("margin_right", 30)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 24)
	panel.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	margin.add_child(vbox)

	_speaker_label = Label.new()
	_speaker_label.add_theme_font_size_override("font_size", 26)
	vbox.add_child(_speaker_label)

	_text_label = RichTextLabel.new()
	_text_label.bbcode_enabled = false
	_text_label.fit_content = true
	_text_label.custom_minimum_size = Vector2(0, 88)
	_text_label.add_theme_font_size_override("normal_font_size", 21)
	vbox.add_child(_text_label)

	_choices_box = VBoxContainer.new()
	_choices_box.add_theme_constant_override("separation", 8)
	vbox.add_child(_choices_box)

	_continue_label = Label.new()
	_continue_label.text = "[E / A] Continue     [Esc / B] Close"
	_continue_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_continue_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(_continue_label)
