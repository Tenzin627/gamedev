extends Control

var _monster_ids: Array[String] = []
var _candidate_ids: Array[String] = []
var _monster_option: OptionButton
var _candidate_option: OptionButton
var _details: RichTextLabel
var _status_label: Label
var _evolve_button: Button
var _presentation: ColorRect
var _presentation_text: Label
var _presentation_tween: Tween

func _ready() -> void:
	visible = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build_ui()
	EventBus.monster_party_changed.connect(_refresh_if_visible)
	EventBus.monster_storage_changed.connect(_refresh_if_visible)
	EventBus.monster_fed.connect(_on_monster_fed)
	EventBus.monster_leveled_up.connect(_on_monster_leveled)

func toggle() -> void:
	if visible: close()
	else: open()

func open() -> void:
	visible = true
	_refresh_all()
	if _monster_option != null: _monster_option.grab_focus()

func close() -> void:
	if _presentation != null and _presentation.visible:
		_finish_presentation()
	visible = false

func _unhandled_input(event: InputEvent) -> void:
	if not visible: return
	if _presentation != null and _presentation.visible and (event.is_action_pressed("confirm") or event.is_action_pressed("cancel") or event.is_action_pressed("interact")):
		_finish_presentation()
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("cancel"):
		close()
		get_viewport().set_input_as_handled()

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new(); shade.color = Color(0.025, 0.03, 0.025, 0.82); shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(shade)
	var panel := PanelContainer.new(); panel.set_anchors_preset(Control.PRESET_CENTER); panel.position = Vector2(-440, -315); panel.size = Vector2(880, 630); add_child(panel)
	var root := VBoxContainer.new(); root.add_theme_constant_override("separation", 10); panel.add_child(root)
	var title := Label.new(); title.text = "Monster Evolution"; title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size", 28); root.add_child(title)
	var monster_row := HBoxContainer.new(); root.add_child(monster_row)
	var monster_label := Label.new(); monster_label.text = "Monster:"; monster_row.add_child(monster_label)
	_monster_option = OptionButton.new(); _monster_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL; monster_row.add_child(_monster_option); _monster_option.item_selected.connect(_on_monster_changed)
	_details = RichTextLabel.new(); _details.bbcode_enabled = true; _details.custom_minimum_size = Vector2(0, 400); _details.size_flags_vertical = Control.SIZE_EXPAND_FILL; root.add_child(_details)
	var choice_row := HBoxContainer.new(); root.add_child(choice_row)
	var path_label := Label.new(); path_label.text = "Path:"; choice_row.add_child(path_label)
	_candidate_option = OptionButton.new(); _candidate_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL; choice_row.add_child(_candidate_option)
	_evolve_button = Button.new(); _evolve_button.text = "Evolve"; choice_row.add_child(_evolve_button); _evolve_button.pressed.connect(_on_evolve_pressed)
	_status_label = Label.new(); _status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; _status_label.custom_minimum_size = Vector2(0, 42); root.add_child(_status_label)
	var debug_row := HBoxContainer.new(); root.add_child(debug_row)
	var debug_label := Label.new(); debug_label.text = "Dev Test:"; debug_row.add_child(debug_label)
	var insight_button := Button.new(); insight_button.text = "Ready Insight"; debug_row.add_child(insight_button); insight_button.pressed.connect(func(): _prepare_debug_path("insight"))
	var resilience_button := Button.new(); resilience_button.text = "Ready Resilience"; debug_row.add_child(resilience_button); resilience_button.pressed.connect(func(): _prepare_debug_path("resilience"))
	var tie_button := Button.new(); tie_button.text = "Ready Tie"; debug_row.add_child(tie_button); tie_button.pressed.connect(func(): _prepare_debug_path("tie"))
	var close_button := Button.new(); close_button.text = "Close (Esc)"; close_button.pressed.connect(close); root.add_child(close_button)

	_presentation = ColorRect.new(); _presentation.color = Color(0.96, 0.91, 0.64, 0.0); _presentation.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); _presentation.visible = false; _presentation.mouse_filter = Control.MOUSE_FILTER_STOP; add_child(_presentation)
	_presentation_text = Label.new(); _presentation_text.set_anchors_preset(Control.PRESET_CENTER); _presentation_text.position = Vector2(-360, -70); _presentation_text.size = Vector2(720, 140); _presentation_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; _presentation_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; _presentation_text.add_theme_font_size_override("font_size", 34); _presentation.add_child(_presentation_text)

func _refresh_all() -> void:
	_refresh_monsters()
	_refresh_details()

func _refresh_monsters() -> void:
	var previous := _current_monster_id()
	_monster_option.clear(); _monster_ids.clear()
	for monster in MonsterManager.get_party(): _add_monster(monster, "Party")
	for monster in MonsterManager.get_farm_storage(): _add_monster(monster, "Farm")
	if not previous.is_empty() and previous in _monster_ids: _monster_option.select(_monster_ids.find(previous))

func _add_monster(monster: MonsterInstance, location: String) -> void:
	_monster_ids.append(monster.instance_id)
	_monster_option.add_item("%s — Lv.%d (%s)" % [monster.get_display_name(), monster.level, location])

func _refresh_details() -> void:
	_candidate_option.clear(); _candidate_ids.clear()
	var monster := MonsterManager.find_monster(_current_monster_id())
	if monster == null:
		_details.text = "[center]No monster available.[/center]"
		_evolve_button.disabled = true
		return
	var species := monster.get_species()
	var status := EvolutionManager.get_evolution_status(monster)
	var lines: Array[String] = []
	lines.append("[font_size=26][b]%s[/b][/font_size]  Lv.%d" % [monster.get_display_name(), monster.level])
	lines.append("Species: %s" % (species.display_name if species else monster.species_id))
	lines.append("HP: %d / %d" % [monster.current_hp, monster.get_max_hp()])
	lines.append("")
	lines.append("[b]Evolution Requirements[/b]")
	var candidates: Array = status.get("candidates", [])
	if candidates.is_empty():
		lines.append("This species has no further evolution in the current data set.")
	for entry in candidates:
		var ready_text := "READY" if bool(entry.get("level_ready", false)) and bool(entry.get("development_ready", false)) else "Not Ready"
		lines.append("• %s — Lv.%d+, %s %d/%d — %s" % [str(entry.get("target_name", "?")), int(entry.get("min_level", 1)), str(entry.get("tendency", "")).capitalize(), int(entry.get("current", 0)), int(entry.get("threshold", 0)), ready_text])
	lines.append("")
	lines.append("[b]Resolution[/b]")
	lines.append(str(status.get("message", "")))
	if not monster.evolution_history.is_empty():
		lines.append("")
		lines.append("[b]Evolution History[/b]")
		for entry in monster.evolution_history:
			var from_data := DataRegistry.get_monster(str(entry.get("from_species_id", "")))
			var to_data := DataRegistry.get_monster(str(entry.get("to_species_id", "")))
			lines.append("• %s → %s at Lv.%d" % [from_data.display_name if from_data else str(entry.get("from_species_id", "?")), to_data.display_name if to_data else str(entry.get("to_species_id", "?")), int(entry.get("level", 1))])
	_details.text = "\n".join(lines)

	var qualified: Array = status.get("qualified", [])
	if bool(status.get("requires_choice", false)):
		for entry in qualified:
			_candidate_ids.append(str(entry.get("target_id", "")))
			_candidate_option.add_item("%s (%s %d)" % [str(entry.get("target_name", "?")), str(entry.get("tendency", "")).capitalize(), int(entry.get("current", 0))])
	else:
		var target_id := EvolutionManager.get_resolved_target(monster)
		if not target_id.is_empty():
			var target := DataRegistry.get_monster(target_id)
			_candidate_ids.append(target_id)
			_candidate_option.add_item(target.display_name if target else target_id)
	_candidate_option.disabled = _candidate_ids.size() <= 1
	_evolve_button.disabled = not bool(status.get("can_evolve", false)) or _candidate_ids.is_empty()

func _current_monster_id() -> String:
	if _monster_option == null or _monster_option.selected < 0 or _monster_option.selected >= _monster_ids.size(): return ""
	return _monster_ids[_monster_option.selected]

func _current_target_id() -> String:
	if _candidate_option == null or _candidate_option.selected < 0 or _candidate_option.selected >= _candidate_ids.size(): return ""
	return _candidate_ids[_candidate_option.selected]

func _on_monster_changed(_index: int) -> void:
	_status_label.text = ""
	_refresh_details()

func _on_evolve_pressed() -> void:
	var result := EvolutionManager.evolve_monster(_current_monster_id(), _current_target_id())
	_status_label.text = str(result.get("message", ""))
	if bool(result.get("success", false)):
		_play_presentation(str(result.get("old_name", "Monster")), str(result.get("new_name", "Evolution")))
	_refresh_all()

func _play_presentation(old_name: String, new_name: String) -> void:
	if _presentation_tween != null and _presentation_tween.is_valid(): _presentation_tween.kill()
	_presentation.visible = true
	_presentation.color = Color(0.96, 0.91, 0.64, 0.0)
	_presentation_text.modulate = Color(1, 1, 1, 0)
	_presentation_text.text = "%s is evolving...\n\n%s!\n\n[Confirm / Interact to skip]" % [old_name, new_name]
	_presentation_tween = create_tween()
	_presentation_tween.set_parallel(true)
	_presentation_tween.tween_property(_presentation, "color", Color(0.96, 0.91, 0.64, 0.94), 0.55)
	_presentation_tween.tween_property(_presentation_text, "modulate", Color.WHITE, 0.75)

func _finish_presentation() -> void:
	if _presentation_tween != null and _presentation_tween.is_valid(): _presentation_tween.kill()
	_presentation.visible = false

func _refresh_if_visible() -> void:
	if visible: _refresh_all()
func _on_monster_fed(_a: String, _b: String, _c: String, _d: Dictionary) -> void: _refresh_if_visible()
func _on_monster_leveled(_a: String, _b: int) -> void: _refresh_if_visible()

func _prepare_debug_path(path_id: String) -> void:
	var monster := MonsterManager.find_monster(_current_monster_id())
	if monster == null:
		return
	monster.level = maxi(monster.level, 16)
	for tendency in ["vigor", "resilience", "insight"]:
		if not monster.development.has(tendency):
			monster.development[tendency] = 0
	match path_id:
		"insight":
			monster.development["insight"] = 24
			monster.development["resilience"] = 10
		"resilience":
			monster.development["resilience"] = 24
			monster.development["insight"] = 10
		"tie":
			monster.development["insight"] = 22
			monster.development["resilience"] = 22

	monster.current_hp = mini(monster.current_hp, monster.get_max_hp())
	MonsterManager.sync_to_game_state()
	_status_label.text = "Development test values prepared."
	_refresh_all()
