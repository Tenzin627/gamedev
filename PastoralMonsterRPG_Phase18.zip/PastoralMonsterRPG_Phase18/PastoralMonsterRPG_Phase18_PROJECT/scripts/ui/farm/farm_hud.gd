extends CanvasLayer

@onready var tool_label: Label = get_node_or_null("Panel/Margin/VBox/ToolLabel") as Label
@onready var crop_label: Label = get_node_or_null("Panel/Margin/VBox/CropLabel") as Label
@onready var status_label: Label = get_node_or_null("Panel/Margin/VBox/StatusLabel") as Label
@onready var seed_label: Label = get_node_or_null("Panel/Margin/VBox/SeedLabel") as Label
@onready var crop_option: OptionButton = get_node_or_null("Panel/Margin/VBox/CropOption") as OptionButton
@onready var hoe_button: Button = get_node_or_null("Panel/Margin/VBox/Tools/Hoe") as Button
@onready var plant_button: Button = get_node_or_null("Panel/Margin/VBox/Tools/Plant") as Button
@onready var water_button: Button = get_node_or_null("Panel/Margin/VBox/Tools/Water") as Button
@onready var harvest_button: Button = get_node_or_null("Panel/Margin/VBox/Tools/Harvest") as Button

func _ready() -> void:
	if hoe_button != null:
		hoe_button.pressed.connect(func(): FarmManager.set_tool(&"hoe"))
	if plant_button != null:
		plant_button.pressed.connect(func(): FarmManager.set_tool(&"plant"))
	if water_button != null:
		water_button.pressed.connect(func(): FarmManager.set_tool(&"water"))
	if harvest_button != null:
		harvest_button.pressed.connect(func(): FarmManager.set_tool(&"harvest"))
	if crop_option != null:
		crop_option.item_selected.connect(_on_crop_selected)

	EventBus.farm_tool_changed.connect(_refresh)
	EventBus.inventory_changed.connect(_refresh)
	EventBus.farm_plot_changed.connect(func(_key: String): _refresh())

	_populate_crops()
	_refresh()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("farm_hoe"):
		FarmManager.set_tool(&"hoe")
	elif event.is_action_pressed("farm_plant"):
		FarmManager.set_tool(&"plant")
	elif event.is_action_pressed("farm_water"):
		FarmManager.set_tool(&"water")
	elif event.is_action_pressed("farm_harvest"):
		FarmManager.set_tool(&"harvest")
	else:
		return
	get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
	if status_label == null:
		return
	var grid := get_tree().get_first_node_in_group("farm_grid") as DualGridFarm
	if grid != null:
		status_label.text = "Target: %s" % FarmManager.get_plot_status(grid._target_cell)

func _populate_crops() -> void:
	if crop_option == null:
		return
	crop_option.clear()
	for crop_id in FarmManager.get_available_crop_ids():
		var crop := DataRegistry.get_crop(crop_id)
		crop_option.add_item(crop.display_name if crop else crop_id)
		crop_option.set_item_metadata(crop_option.item_count - 1, crop_id)
		if crop_id == FarmManager.selected_crop_id:
			crop_option.select(crop_option.item_count - 1)

func _on_crop_selected(index: int) -> void:
	if crop_option == null:
		return
	FarmManager.set_selected_crop(str(crop_option.get_item_metadata(index)))

func _refresh(_a = null, _b = null) -> void:
	var crop := DataRegistry.get_crop(FarmManager.selected_crop_id)
	if tool_label != null:
		tool_label.text = "Tool: %s" % str(FarmManager.current_tool).capitalize()
	if crop_label != null:
		crop_label.text = "Crop: %s" % (crop.display_name if crop else FarmManager.selected_crop_id)
	if seed_label != null:
		if crop != null:
			var seeds := InventoryManager.get_count(crop.seed_item_id)
			seed_label.text = "Seeds: %d   |   Growth: %d min   |   Yield: %d" % [seeds, crop.growth_minutes, crop.base_yield]
		else:
			seed_label.text = "Seeds: --"
