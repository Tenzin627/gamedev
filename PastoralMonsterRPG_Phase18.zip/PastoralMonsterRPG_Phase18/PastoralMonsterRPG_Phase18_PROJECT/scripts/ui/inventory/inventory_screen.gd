extends Control
class_name InventoryScreen

var _selected_item_id := ""
var _list: ItemList
var _currency_label: Label
var _details: Label
var _use_button: Button
var _status: Label

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_ui()
	visible = false
	EventBus.inventory_changed.connect(_refresh)
	EventBus.currency_changed.connect(_on_currency_changed)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("inventory") and not BattleManager.is_battle_active():
		visible = not visible
		if visible:
			_refresh()
		get_viewport().set_input_as_handled()
	elif visible and event.is_action_pressed("cancel"):
		visible = false
		get_viewport().set_input_as_handled()

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.05, 0.06, 0.04, 0.82)
	add_child(shade)

	var panel := PanelContainer.new()
	panel.position = Vector2(260, 130)
	panel.size = Vector2(1400, 820)
	add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	panel.add_child(root)

	var header := HBoxContainer.new(); root.add_child(header)
	var title := Label.new(); title.text = "Inventory"; title.add_theme_font_size_override("font_size", 34); title.size_flags_horizontal = Control.SIZE_EXPAND_FILL; header.add_child(title)
	_currency_label = Label.new(); _currency_label.add_theme_font_size_override("font_size", 26); header.add_child(_currency_label)
	var hint := Label.new(); hint.text = "I / Cancel: Close"; root.add_child(hint)

	var body := HSplitContainer.new(); body.size_flags_vertical = Control.SIZE_EXPAND_FILL; root.add_child(body)
	_list = ItemList.new(); _list.custom_minimum_size = Vector2(560, 600); _list.size_flags_vertical = Control.SIZE_EXPAND_FILL; _list.item_selected.connect(_on_item_selected); body.add_child(_list)
	var right := VBoxContainer.new(); right.custom_minimum_size = Vector2(650, 600); body.add_child(right)
	_details = Label.new(); _details.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; _details.size_flags_vertical = Control.SIZE_EXPAND_FILL; _details.add_theme_font_size_override("font_size", 22); right.add_child(_details)
	_use_button = Button.new(); _use_button.text = "Use"; _use_button.pressed.connect(_on_use_pressed); right.add_child(_use_button)
	_status = Label.new(); _status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; root.add_child(_status)

func _refresh() -> void:
	if _list == null:
		return
	_currency_label.text = "Coins: %d" % GameState.currency
	_list.clear()
	var ids := InventoryManager.get_sorted_item_ids()
	for item_id in ids:
		var item := DataRegistry.get_item(item_id)
		if item == null:
			continue
		_list.add_item("%s   ×%d" % [item.display_name, InventoryManager.get_count(item_id)])
		var index := _list.item_count - 1
		_list.set_item_metadata(index, item_id)
	if ids.is_empty():
		_selected_item_id = ""
		_show_selected()
		return
	var select_index := 0
	for i in range(_list.item_count):
		if str(_list.get_item_metadata(i)) == _selected_item_id:
			select_index = i
			break
	_list.select(select_index)
	_selected_item_id = str(_list.get_item_metadata(select_index))
	_show_selected()

func _on_currency_changed(_new_amount: int) -> void:
	if visible:
		_refresh()

func _on_item_selected(index: int) -> void:
	_selected_item_id = str(_list.get_item_metadata(index))
	_status.text = ""
	_show_selected()

func _show_selected() -> void:
	var item := DataRegistry.get_item(_selected_item_id)
	if item == null:
		_details.text = "No item selected."
		_use_button.disabled = true
		return
	_details.text = "%s\n\nCategory: %s\nOwned: %d / %d\nValue: %d coins\n\n%s" % [item.display_name, str(item.category), InventoryManager.get_count(item.id), item.stack_limit, item.base_value, item.description]
	_use_button.disabled = not item.usable

func _on_use_pressed() -> void:
	if _selected_item_id.is_empty():
		return
	var result := InventoryManager.use_item(_selected_item_id)
	_status.text = str(result.get("message", ""))
	_refresh()
