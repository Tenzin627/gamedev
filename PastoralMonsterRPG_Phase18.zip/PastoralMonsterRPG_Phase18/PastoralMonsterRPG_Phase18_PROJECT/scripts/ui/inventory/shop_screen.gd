extends Control
class_name ShopScreen

var _stock_ids: Array[String] = []
var _shop_name := "Shop"
var _list: ItemList
var _title_label: Label
var _currency_label: Label
var _details: Label
var _status: Label

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_ui()
	visible = false
	EventBus.shop_requested.connect(open_shop)
	EventBus.currency_changed.connect(_refresh)
	EventBus.inventory_changed.connect(_refresh)

func open_shop(shop_name: String, stock_ids: Array[String]) -> void:
	if BattleManager.is_battle_active():
		return
	_shop_name = shop_name
	_stock_ids = stock_ids.duplicate()
	visible = true
	_refresh()

func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("cancel"):
		visible = false
		get_viewport().set_input_as_handled()

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new(); shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); shade.color = Color(0.04,0.04,0.03,0.84); add_child(shade)
	var panel := PanelContainer.new(); panel.position = Vector2(330,150); panel.size = Vector2(1260,780); add_child(panel)
	var root := VBoxContainer.new(); panel.add_child(root)
	var header := HBoxContainer.new(); root.add_child(header)
	_title_label = Label.new(); _title_label.name = "Title"; _title_label.add_theme_font_size_override("font_size", 32); _title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; header.add_child(_title_label)
	_currency_label=Label.new(); _currency_label.add_theme_font_size_override("font_size",24); header.add_child(_currency_label)
	var hint:=Label.new(); hint.text="Buy at full value • Sell from Inventory later if desired • Cancel: Close"; root.add_child(hint)
	var body:=HSplitContainer.new(); body.size_flags_vertical=Control.SIZE_EXPAND_FILL; root.add_child(body)
	_list=ItemList.new(); _list.custom_minimum_size=Vector2(530,560); _list.item_selected.connect(_on_selected); body.add_child(_list)
	var right:=VBoxContainer.new(); right.custom_minimum_size=Vector2(580,560); body.add_child(right)
	_details=Label.new(); _details.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; _details.size_flags_vertical=Control.SIZE_EXPAND_FILL; _details.add_theme_font_size_override("font_size",21); right.add_child(_details)
	var buy:=Button.new(); buy.text="Buy 1"; buy.pressed.connect(_buy_selected); right.add_child(buy)
	_status=Label.new(); _status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; root.add_child(_status)

func _refresh(_unused: Variant = null) -> void:
	if not visible or _list == null:
		return
	if is_instance_valid(_title_label):
		_title_label.text = _shop_name
	if is_instance_valid(_currency_label):
		_currency_label.text = "Coins: %d" % GameState.currency
	_list.clear()
	for item_id in _stock_ids:
		var item:=DataRegistry.get_item(item_id)
		if item == null: continue
		_list.add_item("%s   %d coins   (Owned %d)" % [item.display_name,item.base_value,InventoryManager.get_count(item.id)])
		var idx := _list.item_count - 1
		_list.set_item_metadata(idx,item.id)
	if _list.item_count > 0:
		_list.select(0); _show_item(str(_list.get_item_metadata(0)))
	else:
		if is_instance_valid(_details):
			_details.text = "No stock."

func _on_selected(index:int)->void:
	if is_instance_valid(_status):
		_status.text = ""
	_show_item(str(_list.get_item_metadata(index)))

func _show_item(item_id:String)->void:
	var item:=DataRegistry.get_item(item_id)
	if item == null: return
	if is_instance_valid(_details):
		_details.text = "%s\n\nPrice: %d coins\nOwned: %d / %d\nCategory: %s\n\n%s" % [item.display_name, item.base_value, InventoryManager.get_count(item.id), item.stack_limit, str(item.category), item.description]

func _buy_selected()->void:
	var selected:=_list.get_selected_items()
	if selected.is_empty(): return
	var item_id:=str(_list.get_item_metadata(selected[0]))
	var result:=InventoryManager.buy_item(item_id,1)
	if is_instance_valid(_status):
		match str(result.get("reason", "")):
			"bought": _status.text = "Purchased 1 item."
			"not_enough_currency": _status.text = "Not enough coins."
			"stack_full": _status.text = "That item stack is full."
			_: _status.text = "Purchase failed."
	_refresh()
