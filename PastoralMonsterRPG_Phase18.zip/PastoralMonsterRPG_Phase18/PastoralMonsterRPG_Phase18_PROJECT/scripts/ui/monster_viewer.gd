extends Control

var selected_instance_id := ""

@onready var panel: PanelContainer = $Panel
@onready var party_list: ItemList = $Panel/Margin/VBox/Body/Left/PartyList
@onready var farm_list: ItemList = $Panel/Margin/VBox/Body/Left/FarmList
@onready var title_label: Label = $Panel/Margin/VBox/Body/Right/Title
@onready var species_label: Label = $Panel/Margin/VBox/Body/Right/Species
@onready var level_label: Label = $Panel/Margin/VBox/Body/Right/Level
@onready var hp_label: Label = $Panel/Margin/VBox/Body/Right/HP
@onready var exp_label: Label = $Panel/Margin/VBox/Body/Right/EXP
@onready var stats_label: Label = $Panel/Margin/VBox/Body/Right/Stats
@onready var trait_label: Label = $Panel/Margin/VBox/Body/Right/Trait
@onready var moves_label: Label = $Panel/Margin/VBox/Body/Right/Moves
@onready var id_label: Label = $Panel/Margin/VBox/Body/Right/InstanceID
@onready var status_label: Label = $Panel/Margin/VBox/Status

func _ready() -> void:
	visible = false
	party_list.item_selected.connect(_on_party_selected)
	farm_list.item_selected.connect(_on_farm_selected)
	$Panel/Margin/VBox/Header/Close.pressed.connect(_hide)
	$Panel/Margin/VBox/Actions/Seed.pressed.connect(_seed)
	$Panel/Margin/VBox/Actions/AddEXP.pressed.connect(_add_exp)
	$Panel/Margin/VBox/Actions/Damage.pressed.connect(_damage)
	$Panel/Margin/VBox/Actions/Heal.pressed.connect(_heal)
	$Panel/Margin/VBox/Actions/Move.pressed.connect(_move)
	$Panel/Margin/VBox/Actions/HealAll.pressed.connect(_heal_all)
	EventBus.monster_party_changed.connect(_refresh)
	EventBus.monster_storage_changed.connect(_refresh)
	EventBus.monster_hp_changed.connect(_on_hp_changed)
	EventBus.monster_leveled_up.connect(_on_level_up)
	_refresh()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.ctrl_pressed and event.keycode == KEY_M:
		visible = not visible
		if visible:
			_refresh()
			party_list.grab_focus()
		get_viewport().set_input_as_handled()
	elif visible and event.is_action_pressed("cancel"):
		_hide()
		get_viewport().set_input_as_handled()

func _hide() -> void:
	visible = false

func _refresh() -> void:
	if not is_node_ready():
		return
	party_list.clear()
	farm_list.clear()
	for monster in MonsterManager.get_party():
		party_list.add_item("Lv.%d  %s  %d/%d HP" % [monster.level, monster.get_display_name(), monster.current_hp, monster.get_max_hp()])
		party_list.set_item_metadata(party_list.get_item_count() - 1, monster.instance_id)
	for monster in MonsterManager.get_farm_storage():
		farm_list.add_item("Lv.%d  %s  %d/%d HP" % [monster.level, monster.get_display_name(), monster.current_hp, monster.get_max_hp()])
		farm_list.set_item_metadata(farm_list.get_item_count() - 1, monster.instance_id)
	if not selected_instance_id.is_empty() and MonsterManager.find_monster(selected_instance_id) == null:
		selected_instance_id = ""
	if selected_instance_id.is_empty():
		var party := MonsterManager.get_party()
		if not party.is_empty():
			selected_instance_id = party[0].instance_id
		else:
			var farm := MonsterManager.get_farm_storage()
			if not farm.is_empty():
				selected_instance_id = farm[0].instance_id
	_refresh_details()

func _refresh_details() -> void:
	var monster := MonsterManager.find_monster(selected_instance_id)
	if monster == null:
		title_label.text = "No Monster Selected"
		species_label.text = ""
		level_label.text = ""
		hp_label.text = ""
		exp_label.text = ""
		stats_label.text = ""
		trait_label.text = ""
		moves_label.text = ""
		id_label.text = ""
		return
	var species := monster.get_species()
	var trait_data := DataRegistry.get_trait(monster.trait_id)
	title_label.text = monster.get_display_name()
	species_label.text = "Species: %s (%s)" % [species.display_name if species else monster.species_id, monster.species_id]
	level_label.text = "Level: %d" % monster.level
	hp_label.text = "HP: %d / %d%s" % [monster.current_hp, monster.get_max_hp(), "  [FAINTED]" if monster.is_fainted() else ""]
	var needed := monster.experience_for_next_level()
	exp_label.text = "EXP: MAX" if needed <= 0 else "EXP: %d / %d" % [monster.experience, needed]
	var stats := monster.get_all_stats()
	stats_label.text = "Stats  HP %d   ATK %d   DEF %d   SPD %d" % [stats.hp, stats.attack, stats.defense, stats.speed]
	trait_label.text = "Trait: %s (%s)" % [trait_data.display_name if trait_data else "None", monster.trait_id]
	var move_lines: Array[String] = []
	for i in range(monster.equipped_move_ids.size()):
		var move_id := monster.equipped_move_ids[i]
		var move := DataRegistry.get_move(move_id)
		move_lines.append("%d. %s" % [i + 1, move.display_name if move else move_id])
	moves_label.text = "Moves:\n" + "\n".join(move_lines)
	id_label.text = "Runtime ID: %s" % monster.instance_id

func _on_party_selected(index: int) -> void:
	selected_instance_id = str(party_list.get_item_metadata(index))
	farm_list.deselect_all()
	_refresh_details()

func _on_farm_selected(index: int) -> void:
	selected_instance_id = str(farm_list.get_item_metadata(index))
	party_list.deselect_all()
	_refresh_details()

func _seed() -> void:
	MonsterManager.seed_phase4_demo_roster()
	status_label.text = "Created demo roster."
	_refresh()

func _add_exp() -> void:
	if selected_instance_id.is_empty(): return
	var levels := MonsterManager.add_experience(selected_instance_id, 100)
	status_label.text = "+100 EXP" + (" | Level up!" if not levels.is_empty() else "")
	_refresh()

func _damage() -> void:
	if selected_instance_id.is_empty(): return
	MonsterManager.damage_monster(selected_instance_id, 10)
	status_label.text = "Applied 10 test damage."
	_refresh()

func _heal() -> void:
	if selected_instance_id.is_empty(): return
	MonsterManager.heal_monster(selected_instance_id, 10)
	status_label.text = "Healed 10 HP."
	_refresh()

func _move() -> void:
	if selected_instance_id.is_empty(): return
	var in_party := false
	for monster in MonsterManager.get_party():
		if monster.instance_id == selected_instance_id:
			in_party = true
			break
	var ok := MonsterManager.move_to_farm(selected_instance_id) if in_party else MonsterManager.move_to_party(selected_instance_id)
	status_label.text = "Moved monster." if ok else "Could not move monster (party may be full)."
	_refresh()

func _heal_all() -> void:
	MonsterManager.heal_all()
	status_label.text = "All monsters fully healed."
	_refresh()

func _on_hp_changed(_id: String, _current: int, _max: int) -> void:
	_refresh()

func _on_level_up(instance_id: String, new_level: int) -> void:
	if instance_id == selected_instance_id:
		status_label.text = "Level up → %d" % new_level
	_refresh()
