extends Control
class_name ProfileScreen

var _built := false
var _tag_list: ItemList
var _details: RichTextLabel
var _summary: Label
var _history: RichTextLabel
var _selected_tag_key := ""

func _ready() -> void:
	visible = false
	_build_ui()
	EventBus.profile_tag_changed.connect(func(_tag: String, _added: bool): _refresh())
	EventBus.profile_tag_progress_changed.connect(func(_id: String, _current: int, _required: int): _refresh())

func toggle() -> void:
	visible = not visible
	if visible:
		_refresh()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.ctrl_pressed and event.keycode == KEY_P:
		toggle()
		get_viewport().set_input_as_handled()
	elif visible and event.is_action_pressed("cancel"):
		visible = false
		get_viewport().set_input_as_handled()

func _build_ui() -> void:
	if _built:
		return
	_built = true
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var panel := PanelContainer.new()
	panel.position = Vector2(180, 80)
	panel.size = Vector2(1560, 920)
	add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	panel.add_child(root)
	var title := Label.new()
	title.text = "Player Profile"
	title.add_theme_font_size_override("font_size", 32)
	root.add_child(title)
	_summary = Label.new()
	root.add_child(_summary)
	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)
	_tag_list = ItemList.new()
	_tag_list.custom_minimum_size = Vector2(500, 650)
	_tag_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tag_list.item_selected.connect(_on_tag_selected)
	body.add_child(_tag_list)
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(right)
	_details = RichTextLabel.new()
	_details.bbcode_enabled = true
	_details.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(_details)
	var history_title := Label.new()
	history_title.text = "Tag History"
	history_title.add_theme_font_size_override("font_size", 22)
	right.add_child(history_title)
	_history = RichTextLabel.new()
	_history.bbcode_enabled = true
	_history.custom_minimum_size = Vector2(0, 220)
	right.add_child(_history)
	var close := Button.new()
	close.text = "Close"
	close.pressed.connect(func(): visible = false)
	root.add_child(close)

func _refresh() -> void:
	if not _built:
		return
	var owned := ProfileTagManager.get_tags()
	_summary.text = "Identity Tags: %d  •  Tags are cumulative; they do not lock you into a class." % owned.size()
	_tag_list.clear()
	for definition in ProfileTagManager.get_all_definitions():
		var unlocked := ProfileTagManager.has_tag(definition.tag_key)
		var prefix := "✓ " if unlocked else "○ "
		var index := _tag_list.add_item(prefix + definition.display_name)
		_tag_list.set_item_metadata(index, definition.tag_key)
	if _tag_list.item_count > 0:
		var target_index := 0
		if not _selected_tag_key.is_empty():
			for index in range(_tag_list.item_count):
				if str(_tag_list.get_item_metadata(index)) == _selected_tag_key:
					target_index = index
					break
		_tag_list.select(target_index)
		_on_tag_selected(target_index)
	_refresh_history()

func _on_tag_selected(index: int) -> void:
	if index < 0 or index >= _tag_list.item_count:
		return
	_selected_tag_key = str(_tag_list.get_item_metadata(index))
	var definition := ProfileTagManager.get_definition_for_key(_selected_tag_key)
	if definition == null:
		_details.text = "Unknown tag."
		return
	var unlocked := ProfileTagManager.has_tag(definition.tag_key)
	var progress := ProfileTagManager.get_progress_for_tag(definition.tag_key)
	var text := "[font_size=28][b]%s[/b][/font_size]\n" % definition.display_name
	text += "%s\n\n" % definition.description
	text += "[b]Status:[/b] %s\n" % ("Earned" if unlocked else "Not earned")
	text += "[b]Category:[/b] %s\n" % str(definition.category).capitalize()
	if not str(definition.milestone_type).is_empty() and int(progress.get("required", 0)) > 0:
		text += "[b]Milestone:[/b] %d / %d\n" % [int(progress.get("current", 0)), int(progress.get("required", 0))]
	if not definition.unlock_hint.is_empty():
		text += "\n[b]How it develops[/b]\n%s\n" % definition.unlock_hint
	text += "\nThis tag can unlock dialogue, quest solutions, rewards, and world outcomes."
	_details.text = text

func _refresh_history() -> void:
	var lines := ""
	var history := ProfileTagManager.get_history()
	for index in range(history.size() - 1, -1, -1):
		var entry: Dictionary = history[index]
		var key := str(entry.get("tag", ""))
		var definition := ProfileTagManager.get_definition_for_key(key)
		var name_text := definition.display_name if definition != null else key.capitalize()
		lines += "• [b]%s[/b] — %s, day %d (%s)\n" % [name_text, str(entry.get("source", "system")).capitalize(), int(entry.get("day", 1)), str(entry.get("season", "spring")).capitalize()]
	if lines.is_empty():
		lines = "No Profile Tags earned yet."
	_history.text = lines
