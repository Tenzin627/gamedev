extends Control
class_name QuestJournal

var _built := false
var _tabs: TabContainer
var _available_list: ItemList
var _active_list: ItemList
var _completed_list: ItemList
var _details: RichTextLabel
var _action_button: Button
var _selected_quest_id := ""

func _ready() -> void:
	visible = false
	_build_ui()
	EventBus.quest_list_changed.connect(_refresh)
	EventBus.quest_updated.connect(func(_id: String): _refresh())

func toggle() -> void:
	visible = not visible
	if visible:
		_refresh()
		if _available_list.item_count > 0 and _selected_quest_id.is_empty():
			_available_list.select(0)
			_on_selected(_available_list, 0)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("journal"):
		toggle()
		get_viewport().set_input_as_handled()
	elif visible and event.is_action_pressed("cancel"):
		visible = false
		get_viewport().set_input_as_handled()

func _build_ui() -> void:
	if _built: return
	_built = true
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new(); dim.color = Color(0,0,0,0.55); dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(dim)
	var panel := PanelContainer.new(); panel.position = Vector2(170,90); panel.size = Vector2(1580,900); add_child(panel)
	var root := VBoxContainer.new(); root.add_theme_constant_override("separation", 12); panel.add_child(root)
	var title := Label.new(); title.text = "Quest Journal"; title.add_theme_font_size_override("font_size", 30); root.add_child(title)
	var body := HBoxContainer.new(); body.size_flags_vertical = Control.SIZE_EXPAND_FILL; root.add_child(body)
	_tabs = TabContainer.new(); _tabs.custom_minimum_size = Vector2(680,700); body.add_child(_tabs)
	_available_list = _make_list("Available"); _active_list = _make_list("Active"); _completed_list = _make_list("Completed")
	_tabs.add_child(_available_list); _tabs.add_child(_active_list); _tabs.add_child(_completed_list)
	_available_list.item_selected.connect(_on_available_selected)
	_active_list.item_selected.connect(_on_active_selected)
	_completed_list.item_selected.connect(_on_completed_selected)
	var right := VBoxContainer.new(); right.size_flags_horizontal = Control.SIZE_EXPAND_FILL; body.add_child(right)
	_details = RichTextLabel.new(); _details.bbcode_enabled = true; _details.fit_content = false; _details.size_flags_vertical = Control.SIZE_EXPAND_FILL; right.add_child(_details)
	_action_button = Button.new(); _action_button.text = "Start Quest"; _action_button.pressed.connect(_on_action); right.add_child(_action_button)
	var close := Button.new(); close.text = "Close"; close.pressed.connect(func(): visible = false); root.add_child(close)

func _make_list(name_text: String) -> ItemList:
	var list := ItemList.new(); list.name = name_text; list.size_flags_vertical = Control.SIZE_EXPAND_FILL; list.select_mode = ItemList.SELECT_SINGLE; return list

func _refresh() -> void:
	if not _built: return
	_fill(_available_list, QuestManager.get_available_quests())
	_fill(_active_list, QuestManager.get_active_quests())
	_fill(_completed_list, QuestManager.get_completed_quests())
	if not _selected_quest_id.is_empty(): _show_quest(_selected_quest_id)

func _fill(list: ItemList, quests: Array) -> void:
	list.clear()
	for quest_value in quests:
		var quest := quest_value as QuestData
		if quest == null: continue
		var idx := list.add_item(quest.display_name)
		list.set_item_metadata(idx, quest.id)

func _on_available_selected(index: int) -> void:
	_on_selected(_available_list, index)

func _on_active_selected(index: int) -> void:
	_on_selected(_active_list, index)

func _on_completed_selected(index: int) -> void:
	_on_selected(_completed_list, index)

func _on_selected(list: ItemList, index: int) -> void:
	if index < 0 or index >= list.item_count: return
	_selected_quest_id = str(list.get_item_metadata(index)); _show_quest(_selected_quest_id)

func _show_quest(quest_id: String) -> void:
	var quest := DataRegistry.get_quest(quest_id)
	if quest == null: return
	var state_id := QuestManager.get_state_id(quest_id)
	var text := "[font_size=26][b]%s[/b][/font_size]\n%s\n\n[b]Status:[/b] %s\n\n[b]Objectives[/b]\n" % [quest.display_name, quest.description, state_id.capitalize()]
	for objective_value in quest.objectives:
		if objective_value is Dictionary:
			text += QuestManager.get_objective_text(quest, objective_value) + "\n"
	text += "\n[b]Rewards[/b]\n"
	for reward_value in quest.rewards:
		if reward_value is Dictionary:
			var reward: Dictionary = reward_value
			text += "• %s x%s\n" % [str(reward.get("id", reward.get("type", "reward"))), str(reward.get("amount", 1))]
	_details.text = text
	_action_button.visible = state_id == QuestManager.STATE_AVAILABLE
	_action_button.text = "Start Quest"

func _on_action() -> void:
	if _selected_quest_id.is_empty(): return
	QuestManager.start_quest(_selected_quest_id)
	_refresh()
