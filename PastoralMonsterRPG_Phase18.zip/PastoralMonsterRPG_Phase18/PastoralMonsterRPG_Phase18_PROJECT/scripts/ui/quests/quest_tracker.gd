extends PanelContainer
class_name QuestTracker

var _label: Label

func _ready() -> void:
	position = Vector2(22, 170)
	custom_minimum_size = Vector2(380, 100)
	_label = Label.new(); _label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; add_child(_label)
	EventBus.quest_list_changed.connect(_refresh)
	EventBus.quest_updated.connect(func(_id: String): _refresh())
	_refresh()

func _refresh() -> void:
	var active := QuestManager.get_active_quests()
	visible = not active.is_empty()
	if active.is_empty(): return
	var quest := active[0] as QuestData
	var lines: Array[String] = [quest.display_name]
	for objective_value in quest.objectives:
		if objective_value is Dictionary and not bool((objective_value as Dictionary).get("optional", false)):
			lines.append(QuestManager.get_objective_text(quest, objective_value as Dictionary))
	_label.text = "\n".join(lines)
