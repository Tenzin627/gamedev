extends Control
class_name TimeWeatherHUD

var _date_label: Label
var _time_label: Label
var _weather_label: Label
var _period_label: Label
var _speed_label: Label

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build_ui()
	_connect_events()
	_refresh()

func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	panel.name = "TimeWeatherPanel"
	panel.position = Vector2(1540, 28)
	panel.custom_minimum_size = Vector2(335, 142)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 14)
	margin.add_theme_constant_override("margin_right", 14)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 10)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	margin.add_child(box)

	_date_label = Label.new()
	_date_label.add_theme_font_size_override("font_size", 18)
	box.add_child(_date_label)

	_time_label = Label.new()
	_time_label.add_theme_font_size_override("font_size", 30)
	box.add_child(_time_label)

	_weather_label = Label.new()
	box.add_child(_weather_label)

	_period_label = Label.new()
	box.add_child(_period_label)

	_speed_label = Label.new()
	_speed_label.add_theme_font_size_override("font_size", 12)
	box.add_child(_speed_label)

func _connect_events() -> void:
	EventBus.time_changed.connect(_on_time_changed)
	EventBus.day_changed.connect(_on_day_changed)
	EventBus.season_changed.connect(_on_season_changed)
	EventBus.weather_changed.connect(_on_weather_changed)
	EventBus.time_period_changed.connect(_on_period_changed)
	EventBus.time_scale_changed.connect(_on_time_scale_changed)

func _refresh() -> void:
	if is_instance_valid(_date_label):
		_date_label.text = TimeWeatherManager.get_display_date()
	if is_instance_valid(_time_label):
		_time_label.text = TimeWeatherManager.format_time_24h()
	if is_instance_valid(_weather_label):
		_weather_label.text = "Weather: %s" % TimeWeatherManager.get_weather_id().capitalize()
	if is_instance_valid(_period_label):
		_period_label.text = "Period: %s" % TimeWeatherManager.get_time_period().capitalize()
	if is_instance_valid(_speed_label):
		_speed_label.text = "Phase 10 | Time ×%.0f" % TimeWeatherManager.time_scale

func _on_time_changed(_day: int, _minute_of_day: int) -> void:
	_refresh()

func _on_day_changed(_day: int) -> void:
	_refresh()

func _on_season_changed(_season_id: String, _season_day: int) -> void:
	_refresh()

func _on_weather_changed(_weather_id: String) -> void:
	_refresh()

func _on_period_changed(_period_id: String) -> void:
	_refresh()

func _on_time_scale_changed(_scale: float) -> void:
	_refresh()
