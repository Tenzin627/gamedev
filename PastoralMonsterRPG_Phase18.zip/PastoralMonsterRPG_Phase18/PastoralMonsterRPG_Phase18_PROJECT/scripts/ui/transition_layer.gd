extends CanvasLayer

@onready var overlay: ColorRect = $Overlay

func _ready() -> void:
	overlay.visible = false
	overlay.modulate.a = 0.0

func fade_out(duration: float = 0.2) -> void:
	await fade_to(1.0, duration)

func fade_in(duration: float = 0.2) -> void:
	await fade_to(0.0, duration)

func fade_to(target_alpha: float, duration: float = 0.2) -> void:
	overlay.visible = true
	var tween := create_tween()
	tween.set_trans(Tween.TRANS_QUAD)
	tween.set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(overlay, "modulate:a", clampf(target_alpha, 0.0, 1.0), maxf(duration, 0.0))
	await tween.finished
	if target_alpha <= 0.001:
		overlay.visible = false
