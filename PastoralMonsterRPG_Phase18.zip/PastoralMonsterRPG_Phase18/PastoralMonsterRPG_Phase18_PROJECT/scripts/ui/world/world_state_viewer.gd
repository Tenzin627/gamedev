extends Control

var _list: ItemList
var _details: RichTextLabel
var _status: Label
var _ids: Array[String] = []

func _ready() -> void:
	visible = false
	_build_ui()
	EventBus.world_state_changed.connect(_on_world_state_changed)

func toggle() -> void:
	visible = not visible
	if visible:
		_refresh()

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var shade := ColorRect.new()
	shade.color = Color(0.04, 0.05, 0.04, 0.92)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(shade)

	var panel := PanelContainer.new()
	panel.position = Vector2(260, 120)
	panel.size = Vector2(1400, 820)
	add_child(panel)
	var root := VBoxContainer.new()
	panel.add_child(root)

	var title := Label.new()
	title.text = "Phase 16 — World State Viewer"
	title.add_theme_font_size_override("font_size", 30)
	root.add_child(title)

	var body := HSplitContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)
	_list = ItemList.new()
	_list.custom_minimum_size = Vector2(500, 620)
	_list.item_selected.connect(_on_selected)
	body.add_child(_list)
	_details = RichTextLabel.new()
	_details.bbcode_enabled = true
	_details.fit_content = false
	body.add_child(_details)

	var buttons := HBoxContainer.new()
	root.add_child(buttons)
	var toggle_button := Button.new()
	toggle_button.text = "Toggle Selected Bool"
	toggle_button.pressed.connect(_toggle_selected)
	buttons.add_child(toggle_button)
	var reset_button := Button.new()
	reset_button.text = "Reset Selected"
	reset_button.pressed.connect(_reset_selected)
	buttons.add_child(reset_button)
	var close_button := Button.new()
	close_button.text = "Close (Ctrl+G)"
	close_button.pressed.connect(func(): visible = false)
	buttons.add_child(close_button)

	_status = Label.new()
	root.add_child(_status)

func _refresh() -> void:
	WorldStateManager.ensure_defaults()
	_ids.clear()
	_list.clear()
	var states := WorldStateManager.get_all_states()
	var keys: Array = states.keys()
	keys.sort()
	for key_value in keys:
		var state_id := str(key_value)
		_ids.append(state_id)
		_list.add_item("%s = %s" % [state_id, str(states[state_id])])
	_status.text = "%d persistent state values | Ctrl+G closes" % _ids.size()
	if not _ids.is_empty():
		_list.select(0)
		_show_details(0)

func _on_selected(index: int) -> void:
	_show_details(index)

func _show_details(index: int) -> void:
	if index < 0 or index >= _ids.size():
		return
	var state_id := _ids[index]
	var definition := DataRegistry.get_world_state(state_id)
	var name := definition.display_name if definition != null else state_id
	var description := definition.description if definition != null else "Runtime world-state value."
	var default_text := str(definition.default_value) if definition != null else "(runtime only)"
	_details.text = "[font_size=26]%s[/font_size]\n\n[b]ID:[/b] %s\n[b]Current:[/b] %s\n[b]Default:[/b] %s\n\n%s" % [name, state_id, str(WorldStateManager.get_value(state_id)), default_text, description]

func _toggle_selected() -> void:
	var selected := _list.get_selected_items()
	if selected.is_empty():
		return
	var state_id := _ids[selected[0]]
	var value: Variant = WorldStateManager.get_value(state_id, false)
	if value is bool:
		WorldStateManager.toggle_bool(state_id, "world_state_viewer")
	else:
		_status.text = "Selected state is not Boolean."

func _reset_selected() -> void:
	var selected := _list.get_selected_items()
	if selected.is_empty():
		return
	WorldStateManager.reset_state(_ids[selected[0]], "world_state_viewer")

func _on_world_state_changed(_state_id: String, _value: Variant) -> void:
	if visible:
		_refresh()
