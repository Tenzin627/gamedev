extends RefCounted

static var enabled: bool = true

static func info(category: String, message: String) -> void:
	if enabled:
		print("[%s] %s" % [category.to_upper(), message])

static func warn(category: String, message: String) -> void:
	if enabled:
		push_warning("[%s] %s" % [category.to_upper(), message])

static func error(category: String, message: String) -> void:
	push_error("[%s] %s" % [category.to_upper(), message])
