extends RefCounted

const CONTENT_ID_PATTERN := "^[a-z0-9_]+(\\.[a-z0-9_]+)+$"

static func is_valid_content_id(value: String) -> bool:
	if value.is_empty():
		return false
	var regex := RegEx.new()
	if regex.compile(CONTENT_ID_PATTERN) != OK:
		return false
	return regex.search(value) != null

static func make_runtime_id(prefix: String = "instance") -> String:
	var unix_ms := int(Time.get_unix_time_from_system() * 1000.0)
	var ticks := Time.get_ticks_usec()
	var random_value := randi()
	return "%s_%s_%s_%s" % [prefix, unix_ms, ticks, random_value]
