extends RefCounted

const DEADZONE := 0.35

static func ensure_default_actions() -> void:
	_add_action("move_up", DEADZONE)
	_add_action("move_down", DEADZONE)
	_add_action("move_left", DEADZONE)
	_add_action("move_right", DEADZONE)
	_add_action("interact")
	_add_action("confirm")
	_add_action("cancel")
	_add_action("menu")
	_add_action("journal")
	_add_action("map")
	_add_action("party")
	_add_action("inventory")
	_add_action("pause")
	_add_action("debug_toggle")
	_add_action("debug_console")
	_add_action("debug_reload_scene")
	_add_action("debug_speed")
	_add_action("debug_database")
	_add_action("debug_battle")
	_add_action("farm_hoe")
	_add_action("farm_plant")
	_add_action("farm_water")
	_add_action("farm_harvest")

	_add_key("move_up", KEY_W)
	_add_key("move_up", KEY_UP)
	_add_key("move_down", KEY_S)
	_add_key("move_down", KEY_DOWN)
	_add_key("move_left", KEY_A)
	_add_key("move_left", KEY_LEFT)
	_add_key("move_right", KEY_D)
	_add_key("move_right", KEY_RIGHT)

	_add_key("interact", KEY_E)
	_add_key("interact", KEY_SPACE)
	_add_key("confirm", KEY_ENTER)
	_add_key("confirm", KEY_SPACE)
	_add_key("cancel", KEY_ESCAPE)
	_add_key("menu", KEY_TAB)
	_add_key("journal", KEY_J)
	_add_key("map", KEY_M)
	_add_key("party", KEY_P)
	_add_key("inventory", KEY_I)
	_add_key("pause", KEY_ESCAPE)

	_add_key("debug_toggle", KEY_F3)
	_add_key("debug_console", KEY_F4)
	_add_key("debug_reload_scene", KEY_F5)
	_add_key("debug_speed", KEY_F6)
	_add_key("debug_database", KEY_F7)
	_add_key("farm_hoe", KEY_1)
	_add_key("farm_plant", KEY_2)
	_add_key("farm_water", KEY_3)
	_add_key("farm_harvest", KEY_4)

	# Standard Godot joypad button indices.
	_add_joy_button("interact", 0) # A / Cross
	_add_joy_button("confirm", 0)
	_add_joy_button("cancel", 1) # B / Circle
	_add_joy_button("inventory", 2) # X / Square
	_add_joy_button("journal", 3) # Y / Triangle
	_add_joy_button("menu", 6) # Start / Options on common mappings
	_add_joy_button("pause", 6)

	# D-pad.
	_add_joy_button("move_up", 11)
	_add_joy_button("move_down", 12)
	_add_joy_button("move_left", 13)
	_add_joy_button("move_right", 14)

	# Left analog stick.
	_add_joy_axis("move_left", 0, -1.0)
	_add_joy_axis("move_right", 0, 1.0)
	_add_joy_axis("move_up", 1, -1.0)
	_add_joy_axis("move_down", 1, 1.0)

static func _add_action(action_name: StringName, deadzone: float = 0.5) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name, deadzone)

static func _add_key(action_name: StringName, keycode: int) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	if not InputMap.action_has_event(action_name, event):
		InputMap.action_add_event(action_name, event)

static func _add_joy_button(action_name: StringName, button_index: int) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button_index
	if not InputMap.action_has_event(action_name, event):
		InputMap.action_add_event(action_name, event)

static func _add_joy_axis(action_name: StringName, axis: int, axis_value: float) -> void:
	var event := InputEventJoypadMotion.new()
	event.axis = axis
	event.axis_value = axis_value
	if not InputMap.action_has_event(action_name, event):
		InputMap.action_add_event(action_name, event)
