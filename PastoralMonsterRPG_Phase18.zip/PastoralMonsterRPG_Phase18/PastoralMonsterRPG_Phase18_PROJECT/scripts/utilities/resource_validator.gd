extends RefCounted

const IdUtils = preload("res://scripts/utilities/id_utils.gd")

static func validate_definition(resource: Resource) -> Array[String]:
	var errors: Array[String] = []
	if resource == null:
		errors.append("Resource is null.")
		return errors

	if not _has_property(resource, "id"):
		errors.append("Resource has no 'id' property: %s" % resource.resource_path)
		return errors

	var resource_id := str(resource.get("id"))
	if resource_id.is_empty():
		errors.append("Resource ID is empty: %s" % resource.resource_path)
	elif not IdUtils.is_valid_content_id(resource_id):
		errors.append("Invalid content ID '%s'. Expected format like 'monster.spriggle'." % resource_id)

	if _has_property(resource, "display_name") and str(resource.get("display_name")).strip_edges().is_empty():
		errors.append("Display name is empty for '%s'." % resource_id)

	if resource is MonsterSpeciesData:
		for stat_name in ["hp", "attack", "defense", "speed"]:
			if not resource.base_stats.has(stat_name):
				errors.append("Monster '%s' is missing base stat '%s'." % [resource_id, stat_name])
			elif int(resource.base_stats[stat_name]) <= 0:
				errors.append("Monster '%s' base stat '%s' must be greater than 0." % [resource_id, stat_name])

	elif resource is MoveData:
		if resource.accuracy < 0.0 or resource.accuracy > 1.0:
			errors.append("Move '%s' accuracy must be between 0 and 1." % resource_id)
		if resource.cooldown_turns < 0:
			errors.append("Move '%s' cooldown cannot be negative." % resource_id)

	elif resource is ItemData:
		if resource.stack_limit <= 0:
			errors.append("Item '%s' stack limit must be at least 1." % resource_id)

	return errors

static func validate_definitions(resources: Array) -> Dictionary:
	var errors: Array[String] = []
	var ids := {}

	for item in resources:
		if not item is Resource:
			errors.append("Non-Resource value found in definition list.")
			continue

		var resource := item as Resource
		errors.append_array(validate_definition(resource))

		if _has_property(resource, "id"):
			var resource_id := str(resource.get("id"))
			if not resource_id.is_empty():
				if ids.has(resource_id):
					errors.append("Duplicate content ID '%s'." % resource_id)
				else:
					ids[resource_id] = resource.resource_path

	return {
		"ok": errors.is_empty(),
		"errors": errors,
		"count": resources.size()
	}

static func _has_property(object: Object, property_name: String) -> bool:
	for property in object.get_property_list():
		if str(property.get("name", "")) == property_name:
			return true
	return false
