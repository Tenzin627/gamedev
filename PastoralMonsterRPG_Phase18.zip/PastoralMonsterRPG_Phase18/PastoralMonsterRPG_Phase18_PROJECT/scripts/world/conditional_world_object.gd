extends Node2D
class_name ConditionalWorldObject

@export var state_id: String = ""
@export var expected_value: Variant = true
@export var invert: bool = false
@export var disable_collision_when_hidden: bool = true

func _ready() -> void:
	EventBus.world_state_changed.connect(_on_world_state_changed)
	_apply_state()

func _on_world_state_changed(changed_state_id: String, _value: Variant) -> void:
	if changed_state_id == state_id:
		_apply_state()

func _apply_state() -> void:
	var matches: bool = WorldStateManager.get_value(state_id, null) == expected_value
	if invert:
		matches = not matches
	visible = matches
	if disable_collision_when_hidden:
		_set_collisions_enabled(self, matches)

func _set_collisions_enabled(node: Node, enabled_value: bool) -> void:
	for child in node.get_children():
		if child is CollisionShape2D:
			(child as CollisionShape2D).set_deferred("disabled", not enabled_value)
		elif child is CollisionPolygon2D:
			(child as CollisionPolygon2D).set_deferred("disabled", not enabled_value)
		_set_collisions_enabled(child, enabled_value)
