extends Node2D
class_name MapBase

const DevLog = preload("res://scripts/utilities/dev_log.gd")

@export var map_id: String = "map.unknown"
@export var display_name: String = "Unknown Area"
@export var default_spawn_id: String = "default"
@export var player_scene: PackedScene = preload("res://scenes/characters/player/player.tscn")

@onready var player_container: Node2D = get_node_or_null("Entities/PlayerContainer") as Node2D
@onready var spawn_points: Node = get_node_or_null("SpawnPoints")

var player: PlayerController = null

func _ready() -> void:
	add_to_group("world_map")
	await get_tree().process_frame
	_spawn_player()
	EventBus.map_entered.emit(map_id, display_name)
	DevLog.info("WORLD", "Entered %s (%s)." % [display_name, map_id])

func _exit_tree() -> void:
	EventBus.map_exited.emit(map_id)

func _spawn_player() -> void:
	if player_scene == null:
		DevLog.error("WORLD", "%s has no player scene." % map_id)
		return
	if player_container == null:
		DevLog.error("WORLD", "%s is missing Entities/PlayerContainer." % map_id)
		return

	var spawn_id := SceneManager.consume_pending_spawn_id(default_spawn_id)
	var spawn := _find_spawn_point(spawn_id)
	if spawn == null:
		spawn = _find_spawn_point(default_spawn_id)
	if spawn == null:
		DevLog.warn("WORLD", "No spawn marker '%s' in %s; using map origin." % [spawn_id, map_id])

	player = player_scene.instantiate() as PlayerController
	player_container.add_child(player)
	player.global_position = spawn.global_position if spawn != null else global_position
	GameState.current_map_id = map_id
	GameState.current_spawn_id = spawn_id
	GameState.map_discovery[map_id] = true
	EventBus.player_spawned.emit(player)

func _find_spawn_point(spawn_id: String) -> Marker2D:
	if spawn_points == null:
		return null
	for child in spawn_points.get_children():
		if child is Marker2D and String(child.get_meta("spawn_id", child.name)) == spawn_id:
			return child as Marker2D
	return null

func get_player() -> PlayerController:
	return player
