extends Area2D
class_name MapTransition

@export_file("*.tscn") var target_scene: String
@export var target_spawn_id: String = "default"
@export var require_interact: bool = false
@export var interaction_prompt: String = "Travel"
@export_multiline var transition_message: String = ""
@export var required_world_state_id: String = ""
@export var required_world_state_value: Variant = true
@export var blocked_message: String = "The way is not open yet."

var _player_inside: PlayerController = null
var _transitioning := false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _unhandled_input(event: InputEvent) -> void:
	if require_interact and _player_inside != null and event.is_action_pressed("interact"):
		_travel()
		get_viewport().set_input_as_handled()

func _on_body_entered(body: Node) -> void:
	if body is not PlayerController:
		return
	_player_inside = body as PlayerController
	if require_interact:
		EventBus.interaction_message.emit("[E / A] %s" % interaction_prompt)
	else:
		_travel()

func _on_body_exited(body: Node) -> void:
	if body == _player_inside:
		_player_inside = null

func _travel() -> void:
	if _transitioning or target_scene.is_empty():
		return
	if not required_world_state_id.is_empty():
		if WorldStateManager.get_value(required_world_state_id, null) != required_world_state_value:
			EventBus.interaction_message.emit(blocked_message)
			return
	_transitioning = true
	if not transition_message.is_empty():
		EventBus.interaction_message.emit(transition_message)
	await SceneManager.load_world_scene(target_scene, true, target_spawn_id)
