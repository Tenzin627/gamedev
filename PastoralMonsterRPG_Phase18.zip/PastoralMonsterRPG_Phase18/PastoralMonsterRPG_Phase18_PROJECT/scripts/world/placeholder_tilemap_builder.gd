extends Node
class_name PlaceholderTilemapBuilder

## Development-only TileMapLayer content. Replace the generated TileSet/cells with your Art Bible tiles later.
@export_enum("Village", "Wilderness") var map_style: int = 0
@export var width: int = 34
@export var height: int = 22
@export var tile_size: int = 64

@onready var ground: TileMapLayer = get_node("../TileLayers/Ground") as TileMapLayer
@onready var ground_detail: TileMapLayer = get_node("../TileLayers/GroundDetail") as TileMapLayer
@onready var objects_below: TileMapLayer = get_node("../TileLayers/ObjectsBelow") as TileMapLayer
@onready var collision_layer: TileMapLayer = get_node("../TileLayers/Collision") as TileMapLayer
@onready var objects_above: TileMapLayer = get_node("../TileLayers/ObjectsAbove") as TileMapLayer

var _tile_set: TileSet
var _source_id := -1

func _ready() -> void:
	_build_tileset()
	_assign_tileset()
	paint_placeholder_map()

func _build_tileset() -> void:
	_tile_set = TileSet.new()
	_tile_set.tile_size = Vector2i(tile_size, tile_size)
	_tile_set.add_physics_layer()
	_tile_set.set_physics_layer_collision_layer(0, 1)
	_tile_set.set_physics_layer_collision_mask(0, 0)

	var atlas := TileSetAtlasSource.new()
	atlas.texture = load("res://assets/tilesets/placeholder/phase2_placeholder_tiles.png") as Texture2D
	atlas.texture_region_size = Vector2i(tile_size, tile_size)

	for x in range(6):
		var coords := Vector2i(x, 0)
		atlas.create_tile(coords)

	_source_id = _tile_set.add_source(atlas)

	# Tile 4 is the collision/hedge tile. Its physics polygon fills the tile.
	var solid_data := atlas.get_tile_data(Vector2i(4, 0), 0)
	if solid_data != null:
		solid_data.set_collision_polygons_count(0, 1)
		solid_data.set_collision_polygon_points(0, 0, PackedVector2Array([
			Vector2(-tile_size / 2.0, -tile_size / 2.0),
			Vector2(tile_size / 2.0, -tile_size / 2.0),
			Vector2(tile_size / 2.0, tile_size / 2.0),
			Vector2(-tile_size / 2.0, tile_size / 2.0)
		]))

func _assign_tileset() -> void:
	for layer in [ground, ground_detail, objects_below, collision_layer, objects_above]:
		if layer != null:
			layer.tile_set = _tile_set

func paint_placeholder_map() -> void:
	for layer in [ground, ground_detail, objects_below, collision_layer, objects_above]:
		if layer != null:
			layer.clear()

	var half_w: int = int(width / 2)
	var half_h: int = int(height / 2)
	var ground_tile := Vector2i(0 if map_style == 0 else 1, 0)
	var path_tile := Vector2i(2, 0)
	var flower_tile := Vector2i(3, 0)
	var solid_tile := Vector2i(4, 0)
	var canopy_tile := Vector2i(5, 0)

	for y in range(-half_h, half_h):
		for x in range(-half_w, half_w):
			ground.set_cell(Vector2i(x, y), _source_id, ground_tile)

	# Paint a simple east-west path plus a north-south branch.
	for x in range(-half_w + 1, half_w - 1):
		for y in range(-1, 2):
			ground.set_cell(Vector2i(x, y), _source_id, path_tile)
	for y in range(-half_h + 2, 2):
		for x in range(-1, 2):
			ground.set_cell(Vector2i(x, y), _source_id, path_tile)

	# Decorative detail cells.
	for x in range(-half_w + 3, half_w - 3, 5):
		ground_detail.set_cell(Vector2i(x, -4), _source_id, flower_tile)
	for x in range(-half_w + 5, half_w - 4, 6):
		ground_detail.set_cell(Vector2i(x, 5), _source_id, flower_tile)

	# Collision border comes from an actual TileMapLayer TileSet physics polygon.
	for x in range(-half_w, half_w):
		collision_layer.set_cell(Vector2i(x, -half_h), _source_id, solid_tile)
		collision_layer.set_cell(Vector2i(x, half_h - 1), _source_id, solid_tile)
	for y in range(-half_h + 1, half_h - 1):
		collision_layer.set_cell(Vector2i(-half_w, y), _source_id, solid_tile)
		collision_layer.set_cell(Vector2i(half_w - 1, y), _source_id, solid_tile)

	# Leave a three-tile travel opening: Village exits east, Wilderness exits west.
	var passage_x := half_w - 1 if map_style == 0 else -half_w
	for y in range(-1, 2):
		collision_layer.erase_cell(Vector2i(passage_x, y))

	# Demonstrate lower and upper visual layers around a few tree/structure positions.
	var object_cells := [Vector2i(-9, -5), Vector2i(-7, 6), Vector2i(7, -6), Vector2i(9, 5)]
	if map_style == 1:
		object_cells.append_array([Vector2i(-3, -7), Vector2i(4, 7), Vector2i(12, -3)])
	for cell in object_cells:
		objects_below.set_cell(cell, _source_id, solid_tile)
		objects_above.set_cell(cell + Vector2i(0, -1), _source_id, canopy_tile)
