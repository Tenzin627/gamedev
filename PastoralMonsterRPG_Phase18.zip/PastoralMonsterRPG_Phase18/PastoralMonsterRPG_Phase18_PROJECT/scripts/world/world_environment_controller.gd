extends CanvasModulate
class_name WorldEnvironmentController

func _ready() -> void:
	EventBus.time_period_changed.connect(_on_environment_changed)
	EventBus.weather_changed.connect(_on_environment_changed)
	_refresh()

func _on_environment_changed(_value: Variant) -> void:
	_refresh()

func _refresh() -> void:
	var period_color := _period_color(TimeWeatherManager.get_time_period())
	var weather_color := _weather_color(TimeWeatherManager.get_weather_id())
	color = Color(
		period_color.r * weather_color.r,
		period_color.g * weather_color.g,
		period_color.b * weather_color.b,
		1.0
	)

func _period_color(period_id: String) -> Color:
	match period_id:
		"dawn": return Color(1.0, 0.88, 0.76, 1.0)
		"dusk": return Color(0.90, 0.76, 0.78, 1.0)
		"night": return Color(0.50, 0.60, 0.78, 1.0)
		_: return Color.WHITE

func _weather_color(weather_id: String) -> Color:
	match weather_id:
		"cloudy": return Color(0.90, 0.92, 0.90, 1.0)
		"rain": return Color(0.78, 0.84, 0.90, 1.0)
		"fog": return Color(0.92, 0.91, 0.86, 1.0)
		_: return Color.WHITE
