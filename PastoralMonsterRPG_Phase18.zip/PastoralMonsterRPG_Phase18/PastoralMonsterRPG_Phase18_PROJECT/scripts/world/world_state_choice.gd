extends Interactable
class_name WorldStateChoice

@export var choice_state_id: String = "world.home_restoration_choice"
@export var garden_state_id: String = "world.home_garden_restored"
@export var refuge_state_id: String = "world.home_wildlife_refuge"

func _ready() -> void:
	interaction_prompt = "Make Restoration Choice"

func interact(interactor: Node) -> void:
	if not can_interact(interactor):
		return
	interaction_started.emit(interactor)
	if not str(WorldStateManager.get_value(choice_state_id, "")).is_empty():
		EventBus.interaction_message.emit("The village restoration choice has already been made.")
		interaction_finished.emit(interactor)
		return

	var outcome := _choose_outcome()
	if outcome == "wildlife":
		WorldStateManager.set_many({
			choice_state_id: "wildlife",
			garden_state_id: false,
			refuge_state_id: true
		}, "home_restoration_choice")
		EventBus.interaction_message.emit("You protected this corner as a wildlife refuge. The village will grow around it.")
	else:
		WorldStateManager.set_many({
			choice_state_id: "garden",
			garden_state_id: true,
			refuge_state_id: false
		}, "home_restoration_choice")
		EventBus.interaction_message.emit("You restored the abandoned garden. New crops and gathering space can return here.")
	interaction_finished.emit(interactor)

func _choose_outcome() -> String:
	# MVP automatic resolution demonstrates Profile Tags affecting world outcomes.
	# Tamer without Farmer protects habitat; otherwise the garden path is chosen.
	if ProfileTagManager.has_tag("tamer") and not ProfileTagManager.has_tag("farmer"):
		return "wildlife"
	return "garden"
