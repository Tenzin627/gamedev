extends Node

const DevLog = preload("res://scripts/utilities/dev_log.gd")

func _ready() -> void:
	EventBus.data_registry_loaded.connect(_on_data_registry_loaded)
	EventBus.game_loaded.connect(_on_game_loaded)
	EventBus.game_started.connect(_on_game_started)
	call_deferred("ensure_defaults")

func _on_data_registry_loaded(_definition_count: int) -> void:
	ensure_defaults()

func _on_game_loaded() -> void:
	ensure_defaults()
	_emit_all_states()

func _on_game_started() -> void:
	ensure_defaults()
	_emit_all_states()

func ensure_defaults() -> void:
	for definition_value in DataRegistry.get_category("world"):
		var definition := definition_value as WorldStateData
		if definition == null or definition.id.is_empty():
			continue
		if not GameState.world_state.has(definition.id):
			GameState.world_state[definition.id] = definition.default_value

func has_state(state_id: String) -> bool:
	return GameState.world_state.has(state_id) or DataRegistry.get_world_state(state_id) != null

func get_value(state_id: String, fallback: Variant = null) -> Variant:
	if GameState.world_state.has(state_id):
		return GameState.world_state[state_id]
	var definition := DataRegistry.get_world_state(state_id)
	if definition != null:
		return definition.default_value
	return fallback

func is_true(state_id: String) -> bool:
	return bool(get_value(state_id, false))

func set_value(state_id: String, value: Variant, source: String = "system") -> bool:
	if state_id.is_empty():
		return false
	var previous: Variant = get_value(state_id, null)
	if previous == value and GameState.world_state.has(state_id):
		return false
	GameState.world_state[state_id] = value
	_record_history(state_id, previous, value, source)
	EventBus.world_state_changed.emit(state_id, value)
	DevLog.info("WORLD", "%s = %s (%s)" % [state_id, str(value), source])
	return true

func set_many(changes: Dictionary, source: String = "system") -> int:
	var changed := 0
	for state_id_value in changes.keys():
		if set_value(str(state_id_value), changes[state_id_value], source):
			changed += 1
	return changed

func toggle_bool(state_id: String, source: String = "debug") -> bool:
	return set_value(state_id, not is_true(state_id), source)

func reset_state(state_id: String, source: String = "debug_reset") -> bool:
	var definition := DataRegistry.get_world_state(state_id)
	if definition == null:
		return false
	return set_value(state_id, definition.default_value, source)

func requirements_met(requirements: Dictionary) -> bool:
	for state_id_value in requirements.keys():
		var state_id := str(state_id_value)
		if get_value(state_id, null) != requirements[state_id_value]:
			return false
	return true

func get_all_states() -> Dictionary:
	ensure_defaults()
	return GameState.world_state.duplicate(true)

func get_history() -> Array:
	var history_value: Variant = GameState.player_profile.get("world_state_history", [])
	return (history_value as Array).duplicate(true) if history_value is Array else []

func _record_history(state_id: String, old_value: Variant, new_value: Variant, source: String) -> void:
	var history_value: Variant = GameState.player_profile.get("world_state_history", [])
	var history: Array = history_value if history_value is Array else []
	history.append({
		"id": state_id,
		"from": old_value,
		"to": new_value,
		"source": source,
		"day": int(GameState.game_time.get("day", 1)),
		"season": str(GameState.game_time.get("season", "spring")),
		"minute_of_day": int(GameState.game_time.get("minute_of_day", 480))
	})
	GameState.player_profile["world_state_history"] = history

func _emit_all_states() -> void:
	for state_id_value in GameState.world_state.keys():
		var state_id := str(state_id_value)
		EventBus.world_state_changed.emit(state_id, GameState.world_state[state_id_value])
